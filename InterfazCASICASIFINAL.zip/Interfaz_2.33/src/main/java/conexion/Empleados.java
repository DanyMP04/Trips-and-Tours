/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author MINEDUCYT
 */
public class Empleados {
    private  int id;
    private  String nombre;
    private  String apellido;
    private  String correo;
    
    public Empleados() {
    }

    public Empleados(int id, String nombre, String apellido, String correo) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
    }


    public int getId() {
        return id;
    }

    public void setId(int idautor) {
        this.id = idautor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }


        
    private static final String DB_URL = "jdbc:mysql://localhost:3306/tripsandtour";
    private static final String USER = "root";
    private static final String PASS = "Dany04022007";
    
public static Empleados buscarEmpleadoPorContrasena(String password) {
    String sql = "SELECT e.idEmployee, e.name, e.lastName, e.contact, u.nameUser, u.password " +
                 "FROM employee e " +
                 "INNER JOIN usuario u ON e.idEmployee = u.idEmployee " +
                 "WHERE u.password = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, password);

        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                int id = rs.getInt("idEmployee");
                String name = rs.getString("name");
                String lastName = rs.getString("lastName");
                String correo = rs.getString("contact");

                // Crear un objeto Empleado con los datos obtenidos
                return new Empleados(id, name, lastName, correo);
                
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return null; // Retorna null si no se encuentra el empleado
}
    
    
}
