package conexion;

import com.aspose.pdf.Document;
import com.aspose.pdf.HtmlLoadOptions;
import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMaterialLighterIJTheme;
import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;

public class pdf {
    public void convertHtmlToPdfSinOtrosDescuentos(String nombreEmpleado, String apellidoEmpleado, String idEmpleado, String periodosDePago, String FechaActual, double salarioBase, double comision, double isss, double afp, double renta, double descuentosLey, double totalPagar, String bonificacionEspecial, String nombreArchivo) {
        SwingUtilities.invokeLater(() -> {
            new Thread(() -> {
                try {
                    String htmlContent = "<!DOCTYPE html>\n"
                            + "<html lang=\"es\">\n"
                            + "<head>\n"
                            + "    <meta charset=\"UTF-8\">\n"
                            + "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
                            + "    <title>Boleta de Pago - Trips & Tours</title>\n"
                            + "    <style>\n"
                            + "        body {\n"
                            + "            font-family: Arial, sans-serif;\n"
                            + "            margin: 20px;\n"
                            + "            width: 800px;\n"
                            + "            position: relative;\n"
                            + "        }\n"
                            + "        .header {\n"
                            + "            text-align: center;\n"
                            + "            margin-bottom: 20px;\n"
                            + "        }\n"
                            + "        .header h1 {\n"
                            + "            margin: 0;\n"
                            + "        }\n"
                            + "        .details-box {\n"
                            + "            border: 1px solid #000;\n"
                            + "            padding: 10px;\n"
                            + "            margin-bottom: 20px;\n"
                            + "        }\n"
                            + "        .details-box p {\n"
                            + "            margin: 5px 0;\n"
                            + "        }\n"
                            + "        table {\n"
                            + "            width: 100%;\n"
                            + "            border-collapse: collapse;\n"
                            + "        }\n"
                            + "        table, th, td {\n"
                            + "            border: 1px solid #000;\n"
                            + "        }\n"
                            + "        th, td {\n"
                            + "            padding: 10px;\n"
                            + "            text-align: left;\n"
                            + "        }\n"
                            + "        th {\n"
                            + "            background-color: #f2f2f2;\n"
                            + "        }\n"
                            + "        .totals {\n"
                            + "            font-weight: bold;\n"
                            + "        }\n"
                            + "        .summary {\n"
                            + "            margin-top: 20px;\n"
                            + "        }\n"
                            + "        .summary p {\n"
                            + "            margin: 5px 0;\n"
                            + "        }\n"
                            + "        .signature {\n"
                            + "            margin-top: 40px;\n"
                            + "            text-align: center;\n"
                            + "        }\n"
                            + "        .signature span {\n"
                            + "            display: inline-block;\n"
                            + "            width: 200px;\n"
                            + "            border-top: 1px solid #000;\n"
                            + "        }\n"
                            + "        .logo {\n"
                            + "            position: absolute;\n"
                            + "            bottom: 0;\n"
                            + "            right: 0;\n"
                            + "            width: 100px;\n"
                            + "            height: auto;\n"
                            + "        }\n"
                            + "    </style>\n"
                            + "</head>\n"
                            + "<body>\n"
                            + "    <div class=\"header\">\n"
                            + "        <h1>Boleta de Pago</h1>\n"
                            + "        <p><strong>Empresa:</strong> Trips & Tours</p>\n"
                            + "        <p><strong>Fecha estimada de Pago:</strong> " + periodosDePago + "</p>\n"
                            + "        <p><strong>Fecha de Emisión:</strong> " + FechaActual + "</p>\n"
                            + "    </div>\n"
                            + "    <div class=\"details-box\">\n"
                            + "        <p><strong>Datos del Empleado:</strong></p>\n"
                            + "        <table style=\"width: 100%; border: none;\">\n"
                            + "            <tr>\n"
                            + "                <td><strong>Nombre:</strong></td>\n"
                            + "                <td>" + nombreEmpleado + " " + apellidoEmpleado + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td><strong>ID de Empleado:</strong></td>\n"
                            + "                <td>" + idEmpleado + "</td>\n"
                            + "            </tr>\n"
                            + "        </table>\n"
                            + "    </div>\n"
                            + "    <table>\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>CONCEPTO</th>\n"
                            + "                <th>HABERES</th>\n"
                            + "                <th>DESCUENTOS</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>\n"
                            + "            <tr>\n"
                            + "                <td>Salario Base</td>\n"
                            + "                <td>$" + String.format("%.2f", salarioBase) + "</td>\n"
                            + "                <td></td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>Comisiones</td>\n"
                            + "                <td>$" + String.format("%.2f", comision) + "</td>\n"
                            + "                <td></td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>ISSS</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", isss) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>AFP</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", afp) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>Impuesto sobre la Renta</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", renta) + "</td>\n"
                            + "            </tr>\n"
                            + "        </tbody>\n"
                            + "        <tfoot>\n"
                            + "            <tr class=\"totals\">\n"
                            + "                <td>Total</td>\n"
                            + "                <td>$" + String.format("%.2f", salarioBase + comision) + "</td>\n"
                            + "                <td>$" + String.format("%.2f", descuentosLey) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr class=\"totals\">\n"
                            + "                <td>Salario Neto</td>\n"
                            + "                <td colspan=\"2\">$" + String.format("%.2f", totalPagar) + "</td>\n"
                            + "            </tr>\n"
                            + "        </tfoot>\n"
                            + "    </table>\n"
                            + "    <div class=\"summary\">\n"
                            + "        <p><strong>Bonificación Especial:</strong> " + bonificacionEspecial + "</p>\n"
                            + "    </div>\n"
                            + "    <img src=\"file:///C:/Users/MINEDUCYT/Downloads/mural/Logo_empresa.png\" class=\"logo\" alt=\"Logo\" style=\"width: 200px; height: auto;\">\n"
                            + "</body>\n"
                            + "</html>";

                    // Crear un ByteArrayInputStream a partir del contenido HTML
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(htmlContent.getBytes(StandardCharsets.UTF_8));

                    // Opciones de carga de HTML
                    HtmlLoadOptions htmlLoadOptions = new HtmlLoadOptions();

                    // Cargar el HTML desde el InputStream
                    Document pdfDocument = new Document(inputStream, htmlLoadOptions);

                    try {
                        FlatMaterialLighterIJTheme.setup();
                        UIManager.setLookAndFeel(new FlatMaterialLighterIJTheme());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    // Crear el JFileChooser
                    JFileChooser fileChooser = new JFileChooser();
                    File carpetaPorDefecto = new File("C:\\Users\\MINEDUCYT\\Documents\\Pdf de empleados");
                    if (carpetaPorDefecto.exists() && carpetaPorDefecto.isDirectory()) {
                        fileChooser.setCurrentDirectory(carpetaPorDefecto);
                    } else {
                        // Si la carpeta no existe, usa el directorio de usuario por defecto
                        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                    }
                    fileChooser.setDialogTitle("Guardar archivo PDF");

                    // Establecer un filtro de extensión para archivos PDF
                    FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos PDF", "pdf");
                    fileChooser.setFileFilter(filter);

                    // Establecer el nombre del archivo por defecto
                    fileChooser.setSelectedFile(new java.io.File(nombreArchivo + ".pdf"));

                    // Mostrar el diálogo de guardado
                    int userSelection = fileChooser.showSaveDialog(null);

                    // Procesar la selección del usuario
                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        java.io.File fileToSave = fileChooser.getSelectedFile();
                        // Guardar el documento PDF en la ubicación seleccionada por el usuario
                        pdfDocument.save(fileToSave.getAbsolutePath());
                        System.out.println("Conversión completada. El archivo se ha guardado en: " + fileToSave.getAbsolutePath());
                    } else {
                        System.out.println("La operación de guardado fue cancelada.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        });
    }

    public void convertHtmlToPdf1(
            String nombreEmpleado, String apellidoEmpleado, String idEmpleado,
            String periodosDePago, String FechaActual, double salarioBase,
            double comision, double isss, double afp, double renta, String Concepto1,
            String NombreBanco, String CodigoOExpediente,String codigoBanco, double Credito,
            double totalHaberes, double descuentosLey, double totalPagar,
            String bonificacionEspecial, String nombreArchivo
    ) {

        SwingUtilities.invokeLater(() -> {
            new Thread(() -> {
                try {
                    String htmlContent = "<!DOCTYPE html>\n"
                            + "<html lang=\"es\">\n"
                            + "<head>\n"
                            + "    <meta charset=\"UTF-8\">\n"
                            + "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
                            + "    <title>Boleta de Pago - Trips & Tours</title>\n"
                            + "    <style>\n"
                            + "        body {\n"
                            + "            font-family: Arial, sans-serif;\n"
                            + "            margin: 20px;\n"
                            + "            width: 800px;\n"
                            + "            position: relative;\n"
                            + "        }\n"
                            + "        .header {\n"
                            + "            text-align: center;\n"
                            + "            margin-bottom: 20px;\n"
                            + "        }\n"
                            + "        .header h1 {\n"
                            + "            margin: 0;\n"
                            + "        }\n"
                            + "        .details-box {\n"
                            + "            border: 1px solid #000;\n"
                            + "            padding: 10px;\n"
                            + "            margin-bottom: 20px;\n"
                            + "        }\n"
                            + "        .details-box p {\n"
                            + "            margin: 5px 0;\n"
                            + "        }\n"
                            + "        table {\n"
                            + "            width: 100%;\n"
                            + "            border-collapse: collapse;\n"
                            + "        }\n"
                            + "        table, th, td {\n"
                            + "            border: 1px solid #000;\n"
                            + "        }\n"
                            + "        th, td {\n"
                            + "            padding: 10px;\n"
                            + "            text-align: left;\n"
                            + "        }\n"
                            + "        th {\n"
                            + "            background-color: #f2f2f2;\n"
                            + "        }\n"
                            + "        .totals {\n"
                            + "            font-weight: bold;\n"
                            + "        }\n"
                            + "        .summary {\n"
                            + "            margin-top: 20px;\n"
                            + "        }\n"
                            + "        .summary p {\n"
                            + "            margin: 5px 0;\n"
                            + "        }\n"
                            + "        .signature {\n"
                            + "            margin-top: 40px;\n"
                            + "            text-align: center;\n"
                            + "        }\n"
                            + "        .signature span {\n"
                            + "            display: inline-block;\n"
                            + "            width: 200px;\n"
                            + "            border-top: 1px solid #000;\n"
                            + "        }\n"
                            + "        .logo {\n"
                            + "            position: absolute;\n"
                            + "            bottom: 0;\n"
                            + "            right: 0;\n"
                            + "            width: 100px;\n"
                            + "            height: auto;\n"
                            + "        }\n"
                            + "    </style>\n"
                            + "</head>\n"
                            + "<body>\n"
                            + "    <div class=\"header\">\n"
                            + "        <h1>Boleta de Pago</h1>\n"
                            + "        <p><strong>Empresa:</strong> Trips & Tours</p>\n"
                            + "        <p><strong>Fecha estimada de Pago:</strong> " + periodosDePago + "</p>\n"
                            + "        <p><strong>Fecha de Emisión:</strong> " + FechaActual + "</p>\n"
                            + "    </div>\n"
                            + "    <div class=\"details-box\">\n"
                            + "        <p><strong>Datos del Empleado:</strong></p>\n"
                            + "        <table style=\"width: 100%; border: none;\">\n"
                            + "            <tr>\n"
                            + "                <td><strong>Nombre:</strong></td>\n"
                            + "                <td>" + nombreEmpleado + " " + apellidoEmpleado + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td><strong>ID de Empleado:</strong></td>\n"
                            + "                <td>" + idEmpleado + "</td>\n"
                            + "            </tr>\n"
                            + "        </table>\n"
                            + "    </div>\n"
                            + "    <table>\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>CONCEPTO</th>\n"
                            + "                <th>HABERES</th>\n"
                            + "                <th>DESCUENTOS</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>\n"
                            + "            <tr>\n"
                            + "                <td>Salario Base</td>\n"
                            + "                <td>$" + String.format("%.2f", salarioBase) + "</td>\n"
                            + "                <td></td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>Comisiones</td>\n"
                            + "                <td>$" + String.format("%.2f", comision) + "</td>\n"
                            + "                <td></td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>ISSS</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", isss) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>AFP</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", afp) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>Impuesto sobre la Renta</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", renta) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>" + Concepto1 + " de " + NombreBanco + "<br>" + CodigoOExpediente + "" + codigoBanco + "</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", Credito) + "</td>\n"
                            + "            </tr>\n"
                            + "        </tbody>\n"
                            + "        <tfoot>\n"
                            + "            <tr class=\"totals\">\n"
                            + "                <td>Total</td>\n"
                            + "                <td>$" + String.format("%.2f", salarioBase + comision) + "</td>\n"
                            + "                <td>$" + String.format("%.2f", descuentosLey) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr class=\"totals\">\n"
                            + "                <td>Salario Neto</td>\n"
                            + "                <td colspan=\"2\">$" + String.format("%.2f", totalPagar) + "</td>\n"
                            + "            </tr>\n"
                            + "        </tfoot>\n"
                            + "    </table>\n"
                            + "    <div class=\"summary\">\n"
                            + "        <p><strong>Bonificación Especial:</strong> " + bonificacionEspecial + "</p>\n"
                            + "    </div>\n"
                            + "    <img src=\"file:///C:/Users/MINEDUCYT/Downloads/mural/Logo_empresa.png\" class=\"logo\" alt=\"Logo\" style=\"width: 200px; height: auto;\">\n"
                            + "</body>\n"
                            + "</html>";

                    // Crear un ByteArrayInputStream a partir del contenido HTML
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(htmlContent.getBytes(StandardCharsets.UTF_8));

                    // Opciones de carga de HTML
                    HtmlLoadOptions htmlLoadOptions = new HtmlLoadOptions();

                    // Cargar el HTML desde el InputStream
                    Document pdfDocument = new Document(inputStream, htmlLoadOptions);

                    try {
                        FlatMaterialLighterIJTheme.setup();
                        UIManager.setLookAndFeel(new FlatMaterialLighterIJTheme());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    // Crear el JFileChooser
                    JFileChooser fileChooser = new JFileChooser();
                    File carpetaPorDefecto = new File("C:\\Users\\MINEDUCYT\\Documents\\Pdf de empleados");
                    if (carpetaPorDefecto.exists() && carpetaPorDefecto.isDirectory()) {
                        fileChooser.setCurrentDirectory(carpetaPorDefecto);
                    } else {
                        // Si la carpeta no existe, usa el directorio de usuario por defecto
                        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                    }
                    fileChooser.setDialogTitle("Guardar archivo PDF");

                    // Establecer un filtro de extensión para archivos PDF
                    FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos PDF", "pdf");
                    fileChooser.setFileFilter(filter);

                    // Establecer el nombre del archivo por defecto
                    fileChooser.setSelectedFile(new java.io.File(nombreArchivo + ".pdf"));

                    // Mostrar el diálogo de guardado
                    int userSelection = fileChooser.showSaveDialog(null);

                    // Procesar la selección del usuario
                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        java.io.File fileToSave = fileChooser.getSelectedFile();
                        // Guardar el documento PDF en la ubicación seleccionada por el usuario
                        pdfDocument.save(fileToSave.getAbsolutePath());
                        System.out.println("Conversión completada. El archivo se ha guardado en: " + fileToSave.getAbsolutePath());
                    } else {
                        System.out.println("La operación de guardado fue cancelada.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        });
    }

    public void convertHtmlToPdf2(
            String nombreEmpleado, String apellidoEmpleado, String idEmpleado,
            String periodosDePago, String FechaActual, double salarioBase,
            double comision, double isss, double afp, double renta, String Concepto1,
            String NombreBanco1, String CodigoOExpediente1,String codigoBanco1, double Credito1, String Concepto2,
            String NombreBanco2, String CodigoOExpediente2,String codigoBanco2, double Credito2,
            double totalHaberes, double descuentosLey, double totalPagar,
            String bonificacionEspecial, String nombreArchivo
    ) {
        SwingUtilities.invokeLater(() -> {
            new Thread(() -> {
                try {
                    String htmlContent = "<!DOCTYPE html>\n"
                            + "<html lang=\"es\">\n"
                            + "<head>\n"
                            + "    <meta charset=\"UTF-8\">\n"
                            + "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
                            + "    <title>Boleta de Pago - Trips & Tours</title>\n"
                            + "    <style>\n"
                            + "        body {\n"
                            + "            font-family: Arial, sans-serif;\n"
                            + "            margin: 20px;\n"
                            + "            width: 800px;\n"
                            + "            position: relative;\n"
                            + "        }\n"
                            + "        .header {\n"
                            + "            text-align: center;\n"
                            + "            margin-bottom: 20px;\n"
                            + "        }\n"
                            + "        .header h1 {\n"
                            + "            margin: 0;\n"
                            + "        }\n"
                            + "        .details-box {\n"
                            + "            border: 1px solid #000;\n"
                            + "            padding: 10px;\n"
                            + "            margin-bottom: 20px;\n"
                            + "        }\n"
                            + "        .details-box p {\n"
                            + "            margin: 5px 0;\n"
                            + "        }\n"
                            + "        table {\n"
                            + "            width: 100%;\n"
                            + "            border-collapse: collapse;\n"
                            + "        }\n"
                            + "        table, th, td {\n"
                            + "            border: 1px solid #000;\n"
                            + "        }\n"
                            + "        th, td {\n"
                            + "            padding: 10px;\n"
                            + "            text-align: left;\n"
                            + "        }\n"
                            + "        th {\n"
                            + "            background-color: #f2f2f2;\n"
                            + "        }\n"
                            + "        .totals {\n"
                            + "            font-weight: bold;\n"
                            + "        }\n"
                            + "        .summary {\n"
                            + "            margin-top: 20px;\n"
                            + "        }\n"
                            + "        .summary p {\n"
                            + "            margin: 5px 0;\n"
                            + "        }\n"
                            + "        .signature {\n"
                            + "            margin-top: 40px;\n"
                            + "            text-align: center;\n"
                            + "        }\n"
                            + "        .signature span {\n"
                            + "            display: inline-block;\n"
                            + "            width: 200px;\n"
                            + "            border-top: 1px solid #000;\n"
                            + "        }\n"
                            + "        .logo {\n"
                            + "            position: absolute;\n"
                            + "            bottom: 0;\n"
                            + "            right: 0;\n"
                            + "            width: 100px;\n"
                            + "            height: auto;\n"
                            + "        }\n"
                            + "    </style>\n"
                            + "</head>\n"
                            + "<body>\n"
                            + "    <div class=\"header\">\n"
                            + "        <h1>Boleta de Pago</h1>\n"
                            + "        <p><strong>Empresa:</strong> Trips & Tours</p>\n"
                            + "        <p><strong>Fecha estimada de Pago:</strong> " + periodosDePago + "</p>\n"
                            + "        <p><strong>Fecha de Emisión:</strong> " + FechaActual + "</p>\n"
                            + "    </div>\n"
                            + "    <div class=\"details-box\">\n"
                            + "        <p><strong>Datos del Empleado:</strong></p>\n"
                            + "        <table style=\"width: 100%; border: none;\">\n"
                            + "            <tr>\n"
                            + "                <td><strong>Nombre:</strong></td>\n"
                            + "                <td>" + nombreEmpleado + " " + apellidoEmpleado + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td><strong>ID de Empleado:</strong></td>\n"
                            + "                <td>" + idEmpleado + "</td>\n"
                            + "            </tr>\n"
                            + "        </table>\n"
                            + "    </div>\n"
                            + "    <table>\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>CONCEPTO</th>\n"
                            + "                <th>HABERES</th>\n"
                            + "                <th>DESCUENTOS</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>\n"
                            + "            <tr>\n"
                            + "                <td>Salario Base</td>\n"
                            + "                <td>$" + String.format("%.2f", salarioBase) + "</td>\n"
                            + "                <td></td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>Comisiones</td>\n"
                            + "                <td>$" + String.format("%.2f", comision) + "</td>\n"
                            + "                <td></td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>ISSS</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", isss) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>AFP</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", afp) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>Impuesto sobre la Renta</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", renta) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>" + Concepto1 + " de " + NombreBanco1 + "<br>" + CodigoOExpediente1 + " de " + codigoBanco1 + "</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", Credito1) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>" + Concepto2 + " de " + NombreBanco2 + "<br>" + CodigoOExpediente2 + " de " + codigoBanco2 + "</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", Credito2) + "</td>\n"
                            + "            </tr>\n"
                            + "        </tbody>\n"
                            + "        <tfoot>\n"
                            + "            <tr class=\"totals\">\n"
                            + "                <td>Total</td>\n"
                            + "                <td>$" + String.format("%.2f", salarioBase + comision) + "</td>\n"
                            + "                <td>$" + String.format("%.2f", descuentosLey) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr class=\"totals\">\n"
                            + "                <td>Salario Neto</td>\n"
                            + "                <td colspan=\"2\">$" + String.format("%.2f", totalPagar) + "</td>\n"
                            + "            </tr>\n"
                            + "        </tfoot>\n"
                            + "    </table>\n"
                            + "    <div class=\"summary\">\n"
                            + "        <p><strong>Bonificación Especial:</strong> " + bonificacionEspecial + "</p>\n"
                            + "    </div>\n"
                            + "    <img src=\"file:///C:/Users/MINEDUCYT/Downloads/mural/Logo_empresa.png\" class=\"logo\" alt=\"Logo\" style=\"width: 200px; height: auto;\">\n"
                            + "</body>\n"
                            + "</html>";
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(htmlContent.getBytes(StandardCharsets.UTF_8));

                    // Opciones de carga de HTML
                    HtmlLoadOptions htmlLoadOptions = new HtmlLoadOptions();

                    // Cargar el HTML desde el InputStream
                    Document pdfDocument = new Document(inputStream, htmlLoadOptions);

                    try {
                        FlatMaterialLighterIJTheme.setup();
                        UIManager.setLookAndFeel(new FlatMaterialLighterIJTheme());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    // Crear el JFileChooser
                    JFileChooser fileChooser = new JFileChooser();
                    File carpetaPorDefecto = new File("C:\\Users\\MINEDUCYT\\Documents\\Pdf de empleados");
                    if (carpetaPorDefecto.exists() && carpetaPorDefecto.isDirectory()) {
                        fileChooser.setCurrentDirectory(carpetaPorDefecto);
                    } else {
                        // Si la carpeta no existe, usa el directorio de usuario por defecto
                        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                    }
                    fileChooser.setDialogTitle("Guardar archivo PDF");

                    // Establecer un filtro de extensión para archivos PDF
                    FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos PDF", "pdf");
                    fileChooser.setFileFilter(filter);

                    // Establecer el nombre del archivo por defecto
                    fileChooser.setSelectedFile(new java.io.File(nombreArchivo + ".pdf"));

                    // Mostrar el diálogo de guardado
                    int userSelection = fileChooser.showSaveDialog(null);

                    // Procesar la selección del usuario
                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        java.io.File fileToSave = fileChooser.getSelectedFile();
                        // Guardar el documento PDF en la ubicación seleccionada por el usuario
                        pdfDocument.save(fileToSave.getAbsolutePath());
                        System.out.println("Conversión completada. El archivo se ha guardado en: " + fileToSave.getAbsolutePath());
                    } else {
                        System.out.println("La operación de guardado fue cancelada.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        });

    }

    public void convertHtmlToPdf3(
            String nombreEmpleado, String apellidoEmpleado, String idEmpleado,
            String periodosDePago, String FechaActual, double salarioBase,
            double comision, double isss, double afp, double renta,
            String Concepto1, String NombreBanco1, String codigoBanco1, double Credito1,
            String Concepto2, String NombreBanco2, String codigoBanco2, double Credito2,
            String NombreBanco3, String codigoBanco3, double Credito3,
            double totalHaberes, double descuentosLey, double totalPagar,
            String bonificacionEspecial, String nombreArchivo
    ) {
        SwingUtilities.invokeLater(() -> {
            new Thread(() -> {
                try {
                    String htmlContent = "<!DOCTYPE html>\n"
                            + "<html lang=\"es\">\n"
                            + "<head>\n"
                            + "    <meta charset=\"UTF-8\">\n"
                            + "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
                            + "    <title>Boleta de Pago - Trips & Tours</title>\n"
                            + "    <style>\n"
                            + "        body {\n"
                            + "            font-family: Arial, sans-serif;\n"
                            + "            margin: 20px;\n"
                            + "            width: 800px;\n"
                            + "            position: relative;\n"
                            + "        }\n"
                            + "        .header {\n"
                            + "            text-align: center;\n"
                            + "            margin-bottom: 20px;\n"
                            + "        }\n"
                            + "        .header h1 {\n"
                            + "            margin: 0;\n"
                            + "        }\n"
                            + "        .details-box {\n"
                            + "            border: 1px solid #000;\n"
                            + "            padding: 10px;\n"
                            + "            margin-bottom: 20px;\n"
                            + "        }\n"
                            + "        .details-box p {\n"
                            + "            margin: 5px 0;\n"
                            + "        }\n"
                            + "        table {\n"
                            + "            width: 100%;\n"
                            + "            border-collapse: collapse;\n"
                            + "        }\n"
                            + "        table, th, td {\n"
                            + "            border: 1px solid #000;\n"
                            + "        }\n"
                            + "        th, td {\n"
                            + "            padding: 10px;\n"
                            + "            text-align: left;\n"
                            + "        }\n"
                            + "        th {\n"
                            + "            background-color: #f2f2f2;\n"
                            + "        }\n"
                            + "        .totals {\n"
                            + "            font-weight: bold;\n"
                            + "        }\n"
                            + "        .summary {\n"
                            + "            margin-top: 20px;\n"
                            + "        }\n"
                            + "        .summary p {\n"
                            + "            margin: 5px 0;\n"
                            + "        }\n"
                            + "        .signature {\n"
                            + "            margin-top: 40px;\n"
                            + "            text-align: center;\n"
                            + "        }\n"
                            + "        .signature span {\n"
                            + "            display: inline-block;\n"
                            + "            width: 200px;\n"
                            + "            border-top: 1px solid #000;\n"
                            + "        }\n"
                            + "        .logo {\n"
                            + "            position: absolute;\n"
                            + "            bottom: 0;\n"
                            + "            right: 0;\n"
                            + "            width: 100px;\n"
                            + "            height: auto;\n"
                            + "        }\n"
                            + "    </style>\n"
                            + "</head>\n"
                            + "<body>\n"
                            + "    <div class=\"header\">\n"
                            + "        <h1>Boleta de Pago</h1>\n"
                            + "        <p><strong>Empresa:</strong> Trips & Tours</p>\n"
                            + "        <p><strong>Fecha estimada de Pago:</strong> " + periodosDePago + "</p>\n"
                            + "        <p><strong>Fecha de Emisión:</strong> " + FechaActual + "</p>\n"
                            + "    </div>\n"
                            + "    <div class=\"details-box\">\n"
                            + "        <p><strong>Datos del Empleado:</strong></p>\n"
                            + "        <table style=\"width: 100%; border: none;\">\n"
                            + "            <tr>\n"
                            + "                <td><strong>Nombre:</strong></td>\n"
                            + "                <td>" + nombreEmpleado + " " + apellidoEmpleado + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td><strong>ID de Empleado:</strong></td>\n"
                            + "                <td>" + idEmpleado + "</td>\n"
                            + "            </tr>\n"
                            + "        </table>\n"
                            + "    </div>\n"
                            + "    <table>\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>CONCEPTO</th>\n"
                            + "                <th>HABERES</th>\n"
                            + "                <th>DESCUENTOS</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>\n"
                            + "            <tr>\n"
                            + "                <td>Salario Base</td>\n"
                            + "                <td>$" + String.format("%.2f", salarioBase) + "</td>\n"
                            + "                <td></td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>Comisiones</td>\n"
                            + "                <td>$" + String.format("%.2f", comision) + "</td>\n"
                            + "                <td></td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>ISSS</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", isss) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>AFP</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", afp) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>Impuesto sobre la Renta</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", renta) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>" + Concepto1 + " de " + NombreBanco1 + "<br>Código Banco: " + codigoBanco1 + "</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", Credito1) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>" + Concepto2 + " de " + NombreBanco2 + "<br>Código Banco: " + codigoBanco2 + "</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", Credito2) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <td>" + NombreBanco3 + "<br>Código: " + codigoBanco3 + "</td>\n"
                            + "                <td></td>\n"
                            + "                <td>$" + String.format("%.2f", Credito3) + "</td>\n"
                            + "            </tr>\n"
                            + "        </tbody>\n"
                            + "        <tfoot>\n"
                            + "            <tr class=\"totals\">\n"
                            + "                <td>Total</td>\n"
                            + "                <td>$" + String.format("%.2f", salarioBase + comision) + "</td>\n"
                            + "                <td>$" + String.format("%.2f", descuentosLey) + "</td>\n"
                            + "            </tr>\n"
                            + "            <tr class=\"totals\">\n"
                            + "                <td>Salario Neto</td>\n"
                            + "                <td colspan=\"2\">$" + String.format("%.2f", totalPagar) + "</td>\n"
                            + "            </tr>\n"
                            + "        </tfoot>\n"
                            + "    </table>\n"
                            + "    <div class=\"summary\">\n"
                            + "        <p><strong>Bonificación Especial:</strong> " + bonificacionEspecial + "</p>\n"
                            + "    </div>\n"
                            + "    <img src=\"file:///C:/Users/MINEDUCYT/Downloads/mural/Logo_empresa.png\" class=\"logo\" alt=\"Logo\" style=\"width: 200px; height: auto;\">\n"
                            + "</body>\n"
                            + "</html>";
                    ByteArrayInputStream inputStream = new ByteArrayInputStream(htmlContent.getBytes(StandardCharsets.UTF_8));

                    // Opciones de carga de HTML
                    HtmlLoadOptions htmlLoadOptions = new HtmlLoadOptions();

                    // Cargar el HTML desde el InputStream
                    Document pdfDocument = new Document(inputStream, htmlLoadOptions);

                    try {
                        FlatMaterialLighterIJTheme.setup();
                        UIManager.setLookAndFeel(new FlatMaterialLighterIJTheme());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    // Crear el JFileChooser
                    JFileChooser fileChooser = new JFileChooser();
                    File carpetaPorDefecto = new File("C:\\Users\\MINEDUCYT\\Documents\\Pdf de empleados");
                    if (carpetaPorDefecto.exists() && carpetaPorDefecto.isDirectory()) {
                        fileChooser.setCurrentDirectory(carpetaPorDefecto);
                    } else {
                        // Si la carpeta no existe, usa el directorio de usuario por defecto
                        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                    }
                    fileChooser.setDialogTitle("Guardar archivo PDF");

                    // Establecer un filtro de extensión para archivos PDF
                    FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos PDF", "pdf");
                    fileChooser.setFileFilter(filter);

                    // Establecer el nombre del archivo por defecto
                    fileChooser.setSelectedFile(new java.io.File(nombreArchivo + ".pdf"));

                    // Mostrar el diálogo de guardado
                    int userSelection = fileChooser.showSaveDialog(null);

                    // Procesar la selección del usuario
                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        java.io.File fileToSave = fileChooser.getSelectedFile();
                        // Guardar el documento PDF en la ubicación seleccionada por el usuario
                        pdfDocument.save(fileToSave.getAbsolutePath());
                        System.out.println("Conversión completada. El archivo se ha guardado en: " + fileToSave.getAbsolutePath());
                    } else {
                        System.out.println("La operación de guardado fue cancelada.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        });
    }
}
