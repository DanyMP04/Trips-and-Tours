/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author MINEDUCYT
 */
public class MetodosUsuario {

    Connection con;
    conexion cn = new conexion();
    PreparedStatement ps;
    ResultSet rs;
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/tripsandtour";
    private static final String USER = "root";
    private static final String PASS = "Dany04022007";
    

    public List<Usuarios> Listar() {
        List<Usuarios> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuario";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Usuarios au = new Usuarios();
                au.setIdUsuario(rs.getInt(1));
                au.setNombre(rs.getString(2));
                au.setContraseña(rs.getString(3));
                lista.add(au);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
  
    
    
    public boolean actualizar(Usuarios au) {
        String sql = "UPDATE usuario SET nameUser=?,password=?,rol=?,idEmployee=? WHERE idUser=?";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, au.getNombre());
            ps.setString(2, au.getContraseña());
            ps.setString(3, au.getRol());
            ps.setInt(4, au.getIdEmployee());
            ps.setInt(5, au.getIdUsuario());

            int n = ps.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
    
    public DefaultTableModel buscarPersonas(String buscar) {

        String[] nombresColumnas = {"idUser", "nameUser", "password"};//Indica el nombre de las columnas en la tabla

        String[] registros = new String[3];

        DefaultTableModel empleados = new DefaultTableModel(null, nombresColumnas);

        String sql = "SELECT * FROM usuario WHERE idUser LIKE '%" + buscar + "%' OR nameUser LIKE '%" + buscar + "%'";

        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                registros[0] = rs.getString("idUser");

                registros[1] = rs.getString("nameUser");

                registros[2] = rs.getString("password");

                empleados.addRow(registros);

            }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, "Error al conectar. " + e.getMessage());

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (ps != null) {
                    ps.close();
                }

                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        return empleados;
    }
    
    public boolean guardar(Usuarios au) {
        String sql = "INSERT INTO usuario(nameUser,password, rol, idEmployee) VALUES(?,?,?,?)";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            
            ps.setString(1, au.getNombre());
            ps.setString(2, au.getContraseña());
            ps.setString(3, au.getRol());
            ps.setInt(4, au.getIdEmployee());
            int n = ps.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
    
    public boolean eliminar(Usuarios au) {

        String sql = "DELETE FROM usuario where idUser =?";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, au.getIdUsuario());
            int n = ps.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No puedes eliminar este autor debido a un error: " + e.getMessage());
            return false;
        }
    }
}
