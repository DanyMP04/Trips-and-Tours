/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.util.Date;

/**
 *
 * @author Danym
 */
public class Planilla {

    private int idWorksheet;
    private String creationDate;  // Se asume en formato yyyy-MM-dd
    private String month;
    private String year;
    private int idEmployee;
    private String code;  // Nuevo campo
    private String employeeName;
    private String employeeLastName;  // Nuevo campo
    private double salarioB;  // Nuevo campo
    private double comision;  // Nuevo campo
    private double earnedSalary;
    private double isss;
    private double afp;
    private double rent;
    private double credito;  // Nuevo campo
    private String bancoCredito;  // Nuevo campo para el banco asociado al crédito
    private double hipoteca;  // Nuevo campo
    private String bancoHipoteca;  // Nuevo campo para el banco asociado a la hipoteca
    private double procuraduria;  // Nuevo campo
    private String institucionProcuraduria;  // Nuevo campo para la institución asociada a la procuraduría
    private double othersD;
    private String bonificacion;
    private double salaryTotal;
    private String firma;
    private String alerta;

    // Constructores
    public Planilla() {

    }

    public Planilla(int idWorksheet, String creationDate, String month, String year, int idEmployee, String code, String employeeName, String employeeLastName, double salarioB, double comision, double earnedSalary, double isss, double afp, double rent, double credito, String bancoCredito, double hipoteca, String bancoHipoteca, double procuraduria, String institucionProcuraduria, double othersD, String bonificacion, double salaryTotal, String firma, String alerta) {
        this.idWorksheet = idWorksheet;
        this.creationDate = creationDate;
        this.month = month;
        this.year = year;
        this.idEmployee = idEmployee;
        this.code = code;
        this.employeeName = employeeName;
        this.employeeLastName = employeeLastName;
        this.salarioB = salarioB;
        this.comision = comision;
        this.earnedSalary = earnedSalary;
        this.isss = isss;
        this.afp = afp;
        this.rent = rent;
        this.credito = credito;
        this.bancoCredito = bancoCredito;
        this.hipoteca = hipoteca;
        this.bancoHipoteca = bancoHipoteca;
        this.procuraduria = procuraduria;
        this.institucionProcuraduria = institucionProcuraduria;
        this.othersD = othersD;
        this.bonificacion = bonificacion;
        this.salaryTotal = salaryTotal;
        this.firma = firma;
        this.alerta = alerta;
    }

    public int getIdWorksheet() {
        return idWorksheet;
    }

    public void setIdWorksheet(int idWorksheet) {
        this.idWorksheet = idWorksheet;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeLastName() {
        return employeeLastName;
    }

    public void setEmployeeLastName(String employeeLastName) {
        this.employeeLastName = employeeLastName;
    }

    public double getSalarioB() {
        return salarioB;
    }

    public void setSalarioB(double salarioB) {
        this.salarioB = salarioB;
    }

    public double getComision() {
        return comision;
    }

    public void setComision(double comision) {
        this.comision = comision;
    }

    public double getEarnedSalary() {
        return earnedSalary;
    }

    public void setEarnedSalary(double earnedSalary) {
        this.earnedSalary = earnedSalary;
    }

    public double getIsss() {
        return isss;
    }

    public void setIsss(double isss) {
        this.isss = isss;
    }

    public double getAfp() {
        return afp;
    }

    public void setAfp(double afp) {
        this.afp = afp;
    }

    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }

    public double getCredito() {
        return credito;
    }

    public void setCredito(double credito) {
        this.credito = credito;
    }

    public String getBancoCredito() {
        return bancoCredito;
    }

    public void setBancoCredito(String bancoCredito) {
        this.bancoCredito = bancoCredito;
    }

    public double getHipoteca() {
        return hipoteca;
    }

    public void setHipoteca(double hipoteca) {
        this.hipoteca = hipoteca;
    }

    public String getBancoHipoteca() {
        return bancoHipoteca;
    }

    public void setBancoHipoteca(String bancoHipoteca) {
        this.bancoHipoteca = bancoHipoteca;
    }

    public double getProcuraduria() {
        return procuraduria;
    }

    public void setProcuraduria(double procuraduria) {
        this.procuraduria = procuraduria;
    }

    public String getInstitucionProcuraduria() {
        return institucionProcuraduria;
    }

    public void setInstitucionProcuraduria(String institucionProcuraduria) {
        this.institucionProcuraduria = institucionProcuraduria;
    }

    public double getOthersD() {
        return othersD;
    }

    public void setOthersD(double othersD) {
        this.othersD = othersD;
    }

    public String getBonificacion() {
        return bonificacion;
    }

    public void setBonificacion(String bonificacion) {
        this.bonificacion = bonificacion;
    }

    public double getSalaryTotal() {
        return salaryTotal;
    }

    public void setSalaryTotal(double salaryTotal) {
        this.salaryTotal = salaryTotal;
    }

    public String getFirma() {
        return firma;
    }

    public void setFirma(String firma) {
        this.firma = firma;
    }

    public String getAlerta() {
        return alerta;
    }

    public void setAlerta(String alerta) {
        this.alerta = alerta;
    }
    
    
    @Override
public String toString() {
    return "Planilla{"
            + "idWorksheet=" + idWorksheet
            + ", creationDate='" + creationDate + '\''
            + ", month='" + month + '\''
            + ", year='" + year + '\''
            + ", idEmployee=" + idEmployee
            + ", code='" + code + '\''
            + ", employeeName='" + employeeName + '\''
            + ", employeeLastName='" + employeeLastName + '\''
            + ", salarioB=" + salarioB
            + ", comision=" + comision
            + ", earnedSalary=" + earnedSalary
            + ", isss=" + isss
            + ", afp=" + afp
            + ", rent=" + rent
            + ", credito=" + credito
            + ", bancoCredito='" + bancoCredito + '\''
            + ", hipoteca=" + hipoteca
            + ", bancoHipoteca='" + bancoHipoteca + '\''
            + ", procuraduria=" + procuraduria
            + ", institucionProcuraduria='" + institucionProcuraduria + '\''
            + ", othersD=" + othersD
            + ", bonificacion='" + bonificacion + '\''
            + ", salaryTotal=" + salaryTotal
            + ", firma='" + firma + '\''
            + ", alerta='" + alerta + '\''
            + '}';
}

}
