/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author Danym
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class MetodosPlanilla {

    Connection con;
    conexion cn = new conexion();
    PreparedStatement ps;
    ResultSet rs;

    public void populateComboBox(JComboBox<String> comboBox) {
        try {
            String query = "SELECT DISTINCT monthP, yearP FROM worksheet ORDER BY yearP, monthP";
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            comboBox.removeAllItems(); // Limpiar el comboBox antes de poblarlo

            while (rs.next()) {
                String mes = rs.getString("mes");
                String año = rs.getString("año");
                String item = mes + " - " + año;
                comboBox.addItem(item);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Planilla> Listar(String mes, String anio) {
    List<Planilla> lista = new ArrayList<>();
    String sql = "SELECT * FROM worksheet";

    // Modificar la consulta si se pasan parámetros para filtrar por mes y año
    if (mes != null && anio != null) {
        sql += " WHERE MonthP = ? AND YearP = ?";
    }

    try {
        con = cn.getConexion();
        ps = con.prepareStatement(sql);

        // Si se pasan parámetros, establecerlos en el PreparedStatement
        if (mes != null && anio != null) {
            ps.setString(1, mes);
            ps.setString(2, anio);
        }

        rs = ps.executeQuery();
        while (rs.next()) {
            Planilla au = new Planilla();
            au.setIdWorksheet(rs.getInt("idworksheet"));
            au.setCreationDate(rs.getString("CreationDate"));
            au.setMonth(rs.getString("MonthP"));
            au.setYear(rs.getString("YearP"));
            au.setIdEmployee(rs.getInt("IdEmployee"));
            au.setCode(rs.getString("Code"));
            au.setEmployeeName(rs.getString("EmployeeName"));
            au.setEmployeeLastName(rs.getString("EmployeeLastName"));  // Nuevo campo
            au.setSalarioB(rs.getDouble("SalarioB"));  // Nuevo campo
            au.setComision(rs.getDouble("Comision"));  // Nuevo campo
            au.setEarnedSalary(rs.getDouble("EarnedSalary"));
            au.setIsss(rs.getDouble("Isss"));
            au.setAfp(rs.getDouble("Afp"));
            au.setRent(rs.getDouble("Rent"));
            au.setCredito(rs.getDouble("Credito"));  // Nuevo campo
            au.setBancoCredito(rs.getString("BancoCredito"));  // Nuevo campo
            au.setHipoteca(rs.getDouble("Hipoteca"));  // Nuevo campo
            au.setBancoHipoteca(rs.getString("BancoHipoteca"));  // Nuevo campo
            au.setProcuraduria(rs.getDouble("Procuraduria"));  // Nuevo campo
            au.setInstitucionProcuraduria(rs.getString("InstitucionProcuraduria"));  // Nuevo campo
            au.setOthersD(rs.getDouble("OthersD"));
            au.setBonificacion(rs.getString("Bonificacion"));
            au.setSalaryTotal(rs.getDouble("SalaryTotal"));
            au.setFirma(rs.getString("Firma"));  // Nuevo campo
            au.setAlerta(rs.getString("Alerta"));  // Nuevo campo
            lista.add(au);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    return lista;
}

    // Método para obtener la suma de SalaryTotal filtrado por mes y año
    public double getTotalSalaryByParameters(String month, String year) {
        double totalSalary = 0.0;

        // Parámetros de conexión
        String url = "jdbc:mysql://localhost:3306/tripsandtour"; // Reemplaza con tu URL de conexión
        String user = "root"; // Reemplaza con tu usuario
        String password = "123456"; // Reemplaza con tu contraseña

        // Consulta SQL con parámetros
        String query = "SELECT SUM(SalaryTotal) AS total FROM worksheet WHERE MonthP = ? AND YearP = ?";

        try (Connection connection = DriverManager.getConnection(url, user, password); PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Establecer los valores de los parámetros
            preparedStatement.setString(1, month);
            preparedStatement.setString(2, year);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    totalSalary = resultSet.getDouble("total");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalSalary;
    }

    public boolean puedeGenerarPlanilla(int empleadoId, LocalDate fecha) {
        String sql = "SELECT COUNT(*) FROM worksheet WHERE IdEmployee = ? AND MONTH(CreationDate) = ? AND YEAR(CreationDate) = ?";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, empleadoId);
            ps.setInt(2, fecha.getMonthValue());
            ps.setInt(3, fecha.getYear());
            rs = ps.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                return count == 0; // Retorna true si no hay planillas en ese mes
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        return false;
    }

    public boolean guardarPlanilla(Planilla pla) {
    String sql = "INSERT INTO worksheet(idworksheet, CreationDate, MonthP, YearP, Code, IdEmployee, EmployeeName, EmployeeLastName, SalarioB, Comision, EarnedSalary, Isss, Afp, Rent, Credito, BancoCredito, Hipoteca, BancoHipoteca, Procuraduria, InstitucionProcuraduria, OthersD, SalaryTotal, Bonificacion, Firma, Alerta) "
               + "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    try {
        con = cn.getConexion();  // Obtener la conexión a la base de datos
        ps = con.prepareStatement(sql);  // Preparar la sentencia SQL

        ps.setInt(1, pla.getIdWorksheet());  // ID de la planilla
        ps.setString(2, pla.getCreationDate());  // Fecha de creación
        ps.setString(3, pla.getMonth());  // Mes
        ps.setString(4, pla.getYear());  // Año
        ps.setString(5, pla.getCode());  // Código
        ps.setInt(6, pla.getIdEmployee());  // ID del empleado
        ps.setString(7, pla.getEmployeeName());  // Nombre del empleado
        ps.setString(8, pla.getEmployeeLastName());  // Apellido del empleado
        ps.setDouble(9, pla.getSalarioB());  // Salario Base
        ps.setDouble(10, pla.getComision());  // Comisión
        ps.setDouble(11, pla.getEarnedSalary());  // Salario ganado
        ps.setDouble(12, pla.getIsss());  // ISSS
        ps.setDouble(13, pla.getAfp());  // AFP
        ps.setDouble(14, pla.getRent());  // Renta
        ps.setDouble(15, pla.getCredito());  // Crédito
        ps.setString(16, pla.getBancoCredito());  // Banco Crédito
        ps.setDouble(17, pla.getHipoteca());  // Hipoteca
        ps.setString(18, pla.getBancoHipoteca());  // Banco Hipoteca
        ps.setDouble(19, pla.getProcuraduria());  // Procuraduría
        ps.setString(20, pla.getInstitucionProcuraduria());  // Institución Procuraduría
        ps.setDouble(21, pla.getOthersD());  // Otros descuentos
        ps.setDouble(22, pla.getSalaryTotal());  // Salario total
        ps.setString(23, pla.getBonificacion());  // Bonificación
        ps.setString(24, pla.getFirma());  // Firma
        ps.setString(25, pla.getAlerta());  // Alerta

        // Ejecutar la consulta y verificar si se insertaron filas
        int n = ps.executeUpdate();
        return n != 0;  // Retorna true si la inserción fue exitosa, false en caso contrario
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, e);  // Mostrar mensaje de error en caso de excepción
        return false;  // Fallo debido a excepción
    }
}




    public boolean insertarEnBoleta(int idWorksheet) {
    String sqlSelect = "SELECT CreationDate, IdEmployee, EmployeeName, EmployeeLastName, Code, SalarioB, Comision, EarnedSalary, Isss, Afp, Rent, Credito, BancoCredito, Hipoteca, BancoHipoteca, Procuraduria, InstitucionProcuraduria, OthersD, Bonificacion, SalaryTotal, Alerta "
                     + "FROM worksheet WHERE idworksheet = ?";

    String sqlInsert = "INSERT INTO paymentsheet(IdEmployee, EmployeeName, EmployeeLastName, Code, IssueDate, SalarioBase, Comision, EarnedSalary, ISSS, AFP, Renta, Credito, BancoCredito, Hipoteca, BancoHipoteca, Procuraduria, InstitucionProcuraduria, OtrosDescuentos, Bonificacion, SalaryTotal, Alerta) "
                     + "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    try (Connection con = cn.getConexion(); 
         PreparedStatement psSelect = con.prepareStatement(sqlSelect); 
         PreparedStatement psInsert = con.prepareStatement(sqlInsert)) {

        psSelect.setInt(1, idWorksheet);
        ResultSet rs = psSelect.executeQuery();

        if (rs.next()) {
            // Crear un objeto Planilla con los datos obtenidos
            Planilla planilla = new Planilla();
            planilla.setIdEmployee(rs.getInt("IdEmployee"));
            planilla.setEmployeeName(rs.getString("EmployeeName"));
            planilla.setEmployeeLastName(rs.getString("EmployeeLastName"));
            planilla.setCode(rs.getString("Code"));
            planilla.setCreationDate(rs.getString("CreationDate"));
            planilla.setSalarioB(rs.getDouble("SalarioB"));
            planilla.setComision(rs.getDouble("Comision"));
            planilla.setEarnedSalary(rs.getDouble("EarnedSalary"));
            planilla.setIsss(rs.getDouble("Isss"));
            planilla.setAfp(rs.getDouble("Afp"));
            planilla.setRent(rs.getDouble("Rent"));
            planilla.setCredito(rs.getDouble("Credito"));
            planilla.setBancoCredito(rs.getString("BancoCredito"));  // Nuevo campo
            planilla.setHipoteca(rs.getDouble("Hipoteca"));
            planilla.setBancoHipoteca(rs.getString("BancoHipoteca"));  // Nuevo campo
            planilla.setProcuraduria(rs.getDouble("Procuraduria"));
            planilla.setInstitucionProcuraduria(rs.getString("InstitucionProcuraduria"));  // Nuevo campo
            planilla.setOthersD(rs.getDouble("OthersD"));
            planilla.setBonificacion(rs.getString("Bonificacion"));
            planilla.setSalaryTotal(rs.getDouble("SalaryTotal"));
            planilla.setAlerta(rs.getString("Alerta"));

            // Insertar en paymentsheet
            psInsert.setInt(1, planilla.getIdEmployee());
            psInsert.setString(2, planilla.getEmployeeName());
            psInsert.setString(3, planilla.getEmployeeLastName());
            psInsert.setString(4, planilla.getCode());
            psInsert.setString(5, planilla.getCreationDate());  // Convierte la fecha a java.sql.Date si es necesario
            psInsert.setDouble(6, planilla.getSalarioB());
            psInsert.setDouble(7, planilla.getComision());
            psInsert.setDouble(8, planilla.getEarnedSalary());
            psInsert.setDouble(9, planilla.getIsss());
            psInsert.setDouble(10, planilla.getAfp());
            psInsert.setDouble(11, planilla.getRent());
            psInsert.setDouble(12, planilla.getCredito());
            psInsert.setString(13, planilla.getBancoCredito());  // Nuevo campo
            psInsert.setDouble(14, planilla.getHipoteca());
            psInsert.setString(15, planilla.getBancoHipoteca());  // Nuevo campo
            psInsert.setDouble(16, planilla.getProcuraduria());
            psInsert.setString(17, planilla.getInstitucionProcuraduria());  // Nuevo campo
            psInsert.setDouble(18, planilla.getOthersD());
            psInsert.setString(19, planilla.getBonificacion());
            psInsert.setDouble(20, planilla.getSalaryTotal());
            psInsert.setString(21, planilla.getAlerta());

            int n = psInsert.executeUpdate();
            return n != 0;
        } else {
            return false;
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, e);
        return false;
    }
}




    public boolean insertarTodosRegistrosMesActual() {
        LocalDate now = LocalDate.now();
        String currentMonth = getMesEnEspanolMinusculas(now.getMonthValue());
        String sqlSelect = "SELECT idworksheet FROM worksheet WHERE MonthP = ?";

        System.out.println("Mes actual: " + currentMonth);

        try (Connection con = cn.getConexion(); PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ps.setString(1, currentMonth);
            try (ResultSet rs = ps.executeQuery()) {
                boolean allInserted = true;
                int count = 0;

                while (rs.next()) {
                    int idWorksheet = rs.getInt("idworksheet");
                    System.out.println("Intentando insertar worksheet ID: " + idWorksheet);
                    boolean inserted = insertarEnBoleta(idWorksheet);
                    if (!inserted) {
                        allInserted = false;
                        System.out.println("Fallo al insertar worksheet ID: " + idWorksheet);
                    } else {
                        count++;
                    }
                }

                System.out.println("Total de registros insertados: " + count);
                return allInserted;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            return false;
        }
    }

    private String getMesEnEspanolMinusculas(int monthValue) {
        switch (monthValue) {
            case 1:
                return "enero";
            case 2:
                return "febrero";
            case 3:
                return "marzo";
            case 4:
                return "abril";
            case 5:
                return "mayo";
            case 6:
                return "junio";
            case 7:
                return "julio";
            case 8:
                return "agosto";
            case 9:
                return "septiembre";
            case 10:
                return "octubre";
            case 11:
                return "noviembre";
            case 12:
                return "diciembre";
            default:
                throw new IllegalArgumentException("Mes inválido: " + monthValue);
        }
    }

}
