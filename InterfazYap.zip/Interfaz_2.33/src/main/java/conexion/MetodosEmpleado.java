package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MetodosEmpleado {

    Connection con;
    conexion cn = new conexion();
    PreparedStatement ps;
    ResultSet rs;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/tripsandtour";
    private static final String USER = "root";
    private static final String PASS = "123456";

    public static Map<String, Object> buscarEmpleadoPorUsuario(String username) {
        String sql = "SELECT e.*, u.nameUser "
                + "FROM employee e "
                + "JOIN usuario u ON CONCAT(e.name, ' ', e.lastName) = u.nameUser "
                + "WHERE u.nameUser = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Map<String, Object> empleado = new HashMap<>();
                    ResultSetMetaData metaData = rs.getMetaData();
                    int columnCount = metaData.getColumnCount();

                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        Object columnValue = rs.getObject(i);
                        empleado.put(columnName, columnValue);
                    }

                    return empleado;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean usuarioIgu(String nombre) {
        try {
            // Debes inicializar la conexión antes de usarla
            con = cn.getConexion(); // Esto establece la conexión

            // Consulta para verificar si el nombre ya existe
            String consulta = "SELECT COUNT(*) FROM employee WHERE nombre = ?";
            ps = con.prepareStatement(consulta);
            ps.setString(1, nombre); // El índice debe ser 1, no 0

            rs = ps.executeQuery();

            if (rs.next()) {
                int count = rs.getInt(1);
                return count > 0; // Si count > 0, el usuario ya existe
            }

            return false;
        } catch (SQLException e) {
            // Manejo de excepciones en caso de error
            e.printStackTrace();
            return false;
        }
    }

    public String obtenerCorreoPorId(int idUsuario) {
        String sql = "SELECT contact FROM employee WHERE idEmployee=?";
        String correo = null;

        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idUsuario);

            rs = ps.executeQuery();
            if (rs.next()) {
                correo = rs.getString("contact");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return correo;
    }

    public boolean usuarioId(int idusuario, String nombre) {
        try {
            // Debes inicializar la conexión antes de usarla
            con = cn.getConexion(); // Esto establece la conexión

            // Consulta para verificar si el nombre ya existe
            String consulta = "SELECT COUNT(*) FROM employee WHERE name = ? AND idEmployee != ?";
            ps = con.prepareStatement(consulta);
            ps.setString(1, nombre);
            ps.setInt(2, idusuario);

            rs = ps.executeQuery();

            if (rs.next()) {
                int count = rs.getInt(1);
                return count > 0; // Si count > 0, ya existe un usuario con el mismo nombre, excluyendo el usuario actual
            }

            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getIdusu(String nombreUsuario) throws SQLException {
        int idUsuario = -1; // Valor predeterminado si el usuario no se encuentra

        try {
            con = cn.getConexion();
            // Consulta para obtener el ID de un usuario por nombre
            String consulta = "SELECT idEmployee FROM employee WHERE name = ?";
            ps = con.prepareStatement(consulta);
            ps.setString(1, nombreUsuario);

            rs = ps.executeQuery();

            if (rs.next()) {
                idUsuario = rs.getInt("idEmployee");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return idUsuario;
    }

    public List<Empleados> Listar() {
        List<Empleados> lista = new ArrayList<>();
        String sql = "SELECT * FROM employee";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Empleados au = new Empleados();
                au.setId(rs.getInt(1));
                au.setNombre(rs.getString(2));
                au.setApellido(rs.getString(3));
                au.setCorreo(rs.getString(4));
                lista.add(au);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public boolean guardar(Empleados au) {
        String sql = "INSERT INTO employee(name,lastName,Contact) VALUES(?,?,?)";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, au.getNombre());
            ps.setString(2, au.getApellido());
            ps.setString(3, au.getCorreo());
            int n = ps.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

    public boolean actualizar(Empleados au) {
        String sql = "UPDATE employee SET name=?, lastName=?, contact=? WHERE idEmployee=?";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, au.getNombre());
            ps.setString(2, au.getApellido());
            ps.setString(3, au.getCorreo());
            ps.setInt(4, au.getId());

            int n = ps.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

    public boolean correoExiste(String correo) {
        boolean existe = false;
        String sql = "SELECT COUNT(*) FROM employee WHERE Contact = ?";

        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, correo);
            rs = ps.executeQuery();

            if (rs.next()) {
                existe = rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return existe;
    }

    public boolean eliminar(Empleados au) {

        String sql = "DELETE FROM employee where idEmployee =?";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, au.getId());
            int n = ps.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No puedes eliminar este autor debido a un error: " + e.getMessage());
            return false;
        }
    }

    public DefaultTableModel buscarPersonas(String buscar) {

        String[] nombresColumnas = {"ID", "Nombre", "Apellido", "Correo"};//Indica el nombre de las columnas en la tabla

        String[] registros = new String[4];

        DefaultTableModel empleados = new DefaultTableModel(null, nombresColumnas);

        String sql = "SELECT * FROM employee WHERE idEmployee LIKE '%" + buscar + "%' OR name LIKE '%" + buscar + "%' OR lastName LIKE '%" + buscar + "%'";

        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                registros[0] = rs.getString("idEmployee");

                registros[1] = rs.getString("name");

                registros[2] = rs.getString("lastName");

                registros[3] = rs.getString("Contact");

                empleados.addRow(registros);

            }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, "Error al conectar. " + e.getMessage());

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (ps != null) {
                    ps.close();
                }

                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        return empleados;
    }

}
