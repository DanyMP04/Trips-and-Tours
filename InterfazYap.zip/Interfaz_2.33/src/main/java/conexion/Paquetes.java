

package conexion;

/**
 *
 * @author MINEDUCYT
 */
public class Paquetes {
    
    
    private int idPackage;
    private String packageType;
    private String description;
    private double cost;
    private int points;
    private double costPoints;

    public Paquetes() {
    }

    public Paquetes(int idPackage, String packageType, String description, double cost, int points, double costPoints) {
        this.idPackage = idPackage;
        this.packageType = packageType;
        this.description = description;
        this.cost = cost;
        this.points = points;
        this.costPoints = costPoints;
    }

    public int getIdPackage() {
        return idPackage;
    }

    public void setIdPackage(int idPackage) {
        this.idPackage = idPackage;
    }

    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public double getCostPoints() {
        return costPoints;
    }

    public void setCostPoints(double costPoints) {
        this.costPoints = costPoints;
    }
    
    
    @Override
    public String toString() {
        return "Package{" +
                "idPackage=" + idPackage +
                ", packageType='" + packageType + '\'' +
                ", description='" + description + '\'' +
                ", cost=" + cost +
                ", points=" + points +
                ", costPoints=" + costPoints +
                '}';
}

    
    
    
}
