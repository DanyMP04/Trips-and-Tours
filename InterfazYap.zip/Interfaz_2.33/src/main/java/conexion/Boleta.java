/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author MINEDUCYT
 */
public class Boleta {
    private int idboleta;
    private int idEmpleado;
    private String EmployeeLastName;
    private String EmployeeName;
    private String Code;
    private String IssueDate;
    private double SalarioBase;
    private double Comision;
    private double EarnedSalary;
    private double ISSS;
    private double AFP;
    private double Renta;
    private double Credito;
    private String BancoCredito;       // Campo agregado
    private double Hipoteca;
    private String BancoHipoteca;      // Campo agregado
    private double Procuraduria;
    private String InstitucionProcuraduria; // Campo agregado
    private double OtrosDescuentos;
    private double SalaryTotal;
    private String Bonificacion;
    private String Alerta;

    // Getters y setters
    public int getIdboleta() {
        return idboleta;
    }

    public void setIdboleta(int idboleta) {
        this.idboleta = idboleta;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getEmployeeLastName() {
        return EmployeeLastName;
    }

    public void setEmployeeLastName(String employeeLastName) {
        EmployeeLastName = employeeLastName;
    }

    public String getEmployeeName() {
        return EmployeeName;
    }

    public void setEmployeeName(String employeeName) {
        EmployeeName = employeeName;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        Code = code;
    }

    public String getIssueDate() {
        return IssueDate;
    }

    public void setIssueDate(String issueDate) {
        IssueDate = issueDate;
    }

    public double getSalarioBase() {
        return SalarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        SalarioBase = salarioBase;
    }

    public double getComision() {
        return Comision;
    }

    public void setComision(double comision) {
        Comision = comision;
    }

    public double getEarnedSalary() {
        return EarnedSalary;
    }

    public void setEarnedSalary(double earnedSalary) {
        EarnedSalary = earnedSalary;
    }

    public double getISSS() {
        return ISSS;
    }

    public void setISSS(double ISSS) {
        this.ISSS = ISSS;
    }

    public double getAFP() {
        return AFP;
    }

    public void setAFP(double AFP) {
        this.AFP = AFP;
    }

    public double getRenta() {
        return Renta;
    }

    public void setRenta(double renta) {
        Renta = renta;
    }

    public double getCredito() {
        return Credito;
    }

    public void setCredito(double credito) {
        Credito = credito;
    }

    public String getBancoCredito() {
        return BancoCredito;
    }

    public void setBancoCredito(String bancoCredito) {
        BancoCredito = bancoCredito;
    }

    public double getHipoteca() {
        return Hipoteca;
    }

    public void setHipoteca(double hipoteca) {
        Hipoteca = hipoteca;
    }

    public String getBancoHipoteca() {
        return BancoHipoteca;
    }

    public void setBancoHipoteca(String bancoHipoteca) {
        BancoHipoteca = bancoHipoteca;
    }

    public double getProcuraduria() {
        return Procuraduria;
    }

    public void setProcuraduria(double procuraduria) {
        Procuraduria = procuraduria;
    }

    public String getInstitucionProcuraduria() {
        return InstitucionProcuraduria;
    }

    public void setInstitucionProcuraduria(String institucionProcuraduria) {
        InstitucionProcuraduria = institucionProcuraduria;
    }

    public double getOtrosDescuentos() {
        return OtrosDescuentos;
    }

    public void setOtrosDescuentos(double otrosDescuentos) {
        OtrosDescuentos = otrosDescuentos;
    }

    public double getSalaryTotal() {
        return SalaryTotal;
    }

    public void setSalaryTotal(double salaryTotal) {
        SalaryTotal = salaryTotal;
    }

    public String getBonificacion() {
        return Bonificacion;
    }

    public void setBonificacion(String bonificacion) {
        Bonificacion = bonificacion;
    }

    public String getAlerta() {
        return Alerta;
    }

    public void setAlerta(String alerta) {
        Alerta = alerta;
    }

}

