package conexion;

import com.aspose.pdf.Document;
import com.aspose.pdf.HtmlLoadOptions;
import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMaterialLighterIJTheme;
import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;

public class pdf {

    public void convertHtmlToPdf3(
            String nombreEmpleado, String apellidoEmpleado, String idEmpleado,
            String codigoBoleta, String fechaCreacion, double salarioBase,
            double comision, double salarioDevengado, double isss, double afp, double renta,
            double credito, String bancoCredito, String codigoBancoCredito,
            double hipoteca, String bancoHipoteca, String codigoBancoHipoteca,
            double procuraduria, String Institucion, String expediente, double totalDescuentos, double salarioTotal,
            String bonificacion, String alerta, String nombreArchivo
    ) {
        SwingUtilities.invokeLater(() -> {
            new Thread(() -> {
                try {
                    StringBuilder htmlContent = new StringBuilder();
                    htmlContent.append("<!DOCTYPE html>\n")
                            .append("<html lang=\"es\">\n")
                            .append("<head>\n")
                            .append("    <meta charset=\"UTF-8\">\n")
                            .append("    <style>\n")
                            .append("        body { font-family: Arial, sans-serif; margin: 0; padding: 0; width: 100%; position: relative; }\n")
                            .append("        table { width: 100%; border-collapse: collapse; margin: 0; padding: 0; }\n")
                            .append("        th, td { border: 1px solid black; padding: 8px; text-align: left; }\n")
                            .append("        th { background-color: #f2f2f2; }\n")
                            .append("        .centered { text-align: center; }\n")
                            .append("        .not-bold { font-weight: normal; }\n")
                            .append("        .full-width { width: 100%; }\n")
                            .append("        .top-right { position: absolute; top: 10px; right: 10px; width: 150px; height: auto; }\n") // Ajuste de tamaño de la imagen
                            .append("    </style>\n")
                            .append("</head>\n")
                            .append("<body>\n")
                            .append("    <img src=\"file:///C:/Users/MINEDUCYT/Downloads/mural/Logo_empresa.png\" alt=\"Logo\" class=\"top-right\">\n") // Imagen en la esquina superior derecha
                            .append("    <h2 class=\"centered\">Boleta de Pago</h2>\n")
                            .append("    <p class=\"centered not-bold\">Empresa: Trips & Tours</p>\n")
                            .append("    <p class=\"centered not-bold\">Fecha estimada de Pago: ").append(fechaCreacion).append("</p>\n")
                            .append("    <h3>Datos del Empleado:</h3>\n")
                            .append("    <table class=\"full-width\">\n")
                            .append("        <tr><td><strong>Nombre:</strong></td><td>").append(nombreEmpleado).append(" ").append(apellidoEmpleado).append("</td></tr>\n")
                            .append("        <tr><td><strong>ID de Empleado:</strong></td><td>").append(idEmpleado).append("</td></tr>\n")
                            .append("    </table>\n")
                            .append("    <br>\n")
                            .append("    <table class=\"full-width\">\n")
                            .append("        <tr><th>CONCEPTO</th><th>HABERES</th><th>DESCUENTOS</th></tr>\n")
                            .append("        <tr><td>Salario Base</td><td>$").append(String.format("%.2f", salarioBase)).append("</td><td></td></tr>\n")
                            .append("        <tr><td>Comisiones</td><td>$").append(String.format("%.2f", comision)).append("</td><td></td></tr>\n")
                            .append("        <tr><td>ISSS</td><td></td><td>$").append(String.format("%.2f", isss)).append("</td></tr>\n")
                            .append("        <tr><td>AFP</td><td></td><td>$").append(String.format("%.2f", afp)).append("</td></tr>\n")
                            .append("        <tr><td>Impuesto sobre la Renta</td><td></td><td>$").append(String.format("%.2f", renta)).append("</td></tr>\n");

                    if (credito > 0) {
                        htmlContent.append("        <tr><td>Crédito de ").append(bancoCredito).append("<br>Código de Banco: ").append(codigoBancoCredito).append("</td><td></td><td>$").append(String.format("%.2f", credito)).append("</td></tr>\n");
                    }

                    if (hipoteca > 0) {
                        htmlContent.append("        <tr><td>Hipoteca de ").append(bancoHipoteca).append("<br>Código de Banco: ").append(codigoBancoHipoteca).append("</td><td></td><td>$").append(String.format("%.2f", hipoteca)).append("</td></tr>\n");
                    }

                    if (procuraduria > 0) {
                        htmlContent.append("        <tr><td>Descuento de ").append(Institucion).append("<br>Numero de expediente: ").append(expediente).append("</td><td></td><td>$").append(String.format("%.2f", procuraduria)).append("</td></tr>\n");
                    }

                    htmlContent.append("        <tr><th>Total</th><td>$").append(String.format("%.2f", salarioDevengado)).append("</td><td>$").append(String.format("%.2f", totalDescuentos)).append("</td></tr>\n")
                            .append("        <tr><th>Salario Neto</th><td colspan=\"2\">$").append(String.format("%.2f", salarioTotal)).append("</td></tr>\n")
                            .append("    </table>\n")
                            .append("    <p><strong>Bonificación Especial:</strong> ").append(bonificacion.isEmpty() ? "NO APLICA" : bonificacion).append("</p>\n");

                    if (!alerta.isEmpty()) {
                        htmlContent.append("    <p><strong>Alerta:</strong> ").append(alerta).append("</p>\n");
                    }

                    htmlContent.append("</body>\n")
                            .append("</html>");

                    ByteArrayInputStream inputStream = new ByteArrayInputStream(htmlContent.toString().getBytes(StandardCharsets.UTF_8));

                    // Opciones de carga de HTML
                    HtmlLoadOptions htmlLoadOptions = new HtmlLoadOptions();

                    // Cargar el HTML desde el InputStream
                    Document pdfDocument = new Document(inputStream, htmlLoadOptions);

                    try {
                        FlatMaterialLighterIJTheme.setup();
                        UIManager.setLookAndFeel(new FlatMaterialLighterIJTheme());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    // Crear el JFileChooser
                    JFileChooser fileChooser = new JFileChooser();
                    File carpetaPorDefecto = new File("C:\\Users\\MINEDUCYT\\Documents\\Pdf de empleados");
                    if (carpetaPorDefecto.exists() && carpetaPorDefecto.isDirectory()) {
                        fileChooser.setCurrentDirectory(carpetaPorDefecto);
                    } else {
                        // Si la carpeta no existe, usa el directorio de usuario por defecto
                        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                    }
                    fileChooser.setDialogTitle("Guardar archivo PDF");

                    // Establecer un filtro de extensión para archivos PDF
                    FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos PDF", "pdf");
                    fileChooser.setFileFilter(filter);

                    // Establecer el nombre del archivo por defecto
                    fileChooser.setSelectedFile(new java.io.File(nombreArchivo + ".pdf"));

                    // Mostrar el diálogo de guardado
                    int userSelection = fileChooser.showSaveDialog(null);

                    // Procesar la selección del usuario
                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        java.io.File fileToSave = fileChooser.getSelectedFile();
                        // Guardar el documento PDF en la ubicación seleccionada por el usuario
                        pdfDocument.save(fileToSave.getAbsolutePath());
                        System.out.println("Conversión completada. El archivo se ha guardado en: " + fileToSave.getAbsolutePath());
                    } else {
                        System.out.println("La operación de guardado fue cancelada.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        });
    }
}
