/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author MINEDUCYT
 */
public class Usuarios {
    private int idUsuario;
    private String Nombre;
    private String Contraseña;
    private String rol;
    private int idEmployee;

    public Usuarios() {
    }

    public Usuarios(int idUsuario, String Nombre, String Contraseña, String rol, int idEmployee) {
        this.idUsuario = idUsuario;
        this.Nombre = Nombre;
        this.Contraseña = Contraseña;
        this.rol = rol;
        this.idEmployee = idEmployee;
    }

    

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    
}
