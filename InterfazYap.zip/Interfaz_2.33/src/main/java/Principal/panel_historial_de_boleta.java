/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Principal;

import Principal.panel_calculo_puntos.EmpleadoInfo;
import com.formdev.flatlaf.FlatClientProperties;
import conexion.Boleta;
import conexion.EmailSender;
import conexion.Empleados;
import conexion.MetodosBoleta;
import conexion.pdf;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author xyali
 */
public class panel_historial_de_boleta extends javax.swing.JPanel {
    private static final pdf PDF = new pdf();
    private List<Empleados> empleados;
    private Map<String, panel_calculo_puntos.EmpleadoInfo> empleadosMap = new HashMap<>();
    private static final EmailSender Correo = new EmailSender();
    public panel_historial_de_boleta(List<Empleados> empleados, Map<String, panel_calculo_puntos.EmpleadoInfo> empleadosMap) {
        initComponents();
        this.empleados = empleados;
        this.empleadosMap = empleadosMap;
        InitStyles();
        
        actualizarComboBoxUsuarios();
        tableBoletas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listarBoleta(null);  // Mostrar todas las boletas inicialmente

        seleccion_empleado.addActionListener(e -> {
            String empleadoSeleccionado = (String) seleccion_empleado.getSelectedItem();
            listarBoleta(empleadoSeleccionado);  // Filtrar boletas por el empleado seleccionado

            // Obtener el empleado seleccionado por nombre
            Empleados empleado = null;
            for (Empleados emp : empleados) {
                String nombreCompleto = String.valueOf(emp.getId()) + " " + emp.getNombre() + " " + emp.getApellido();
                if (nombreCompleto.equals(empleadoSeleccionado)) {
                    empleado = emp;
                    break;
                }
            }

            // Si se encontró el empleado, actualizar el JLabel
            if (empleado != null) {
                String infoEmpleado = "" + empleado.getId();
                String Nombre1 = "" + empleado.getNombre();
                id.setText(infoEmpleado);
                Nombre.setText(Nombre1);
            } else {
                id.setText("");
                Nombre.setText("");
            }
        });
    }

    private void InitStyles() {
        seleccion_empleado.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
    }

    public void actualizarComboBoxUsuarios() {
        seleccion_empleado.removeAllItems();  // Limpiar el JComboBox

        for (Empleados empleado : empleados) {
            String nombreCompleto = String.valueOf(empleado.getId()) + " " + empleado.getNombre() + " " + empleado.getApellido();
            seleccion_empleado.addItem(nombreCompleto);
        }

        seleccion_empleado.revalidate();  // Asegurar que el JComboBox se actualice
        seleccion_empleado.repaint();
    }

    MetodosBoleta fua = new MetodosBoleta();
    DefaultTableModel dfcat = new DefaultTableModel();

    private Empleados obtenerEmpleadoPorId(int idEmpleado) {
        for (Empleados empleado : empleados) {
            if (empleado.getId() == idEmpleado) {
                return empleado;
            }
        }
        return null; // o lanza una excepción si no se encuentra
    }

    private void listarBoleta(String empleadoSeleccionado) {
        List<Boleta> lista = fua.Listar();
        dfcat = (DefaultTableModel) tableBoletas.getModel();
        dfcat.setRowCount(0);

        for (Boleta boleta : lista) {
            Empleados empleado = obtenerEmpleadoPorId(boleta.getIdEmpleado());

            if (empleado == null) {
                continue;  // Salta si no encuentra al empleado
            }

            // Si se seleccionó un empleado y no coincide con la boleta, omitir esta fila
            if (empleadoSeleccionado != null && !empleadoSeleccionado.equals(String.valueOf(empleado.getId()) + " " + empleado.getNombre() + " " + empleado.getApellido())) {
                continue;
            }

            Object[] ob = new Object[21];
            ob[0] = boleta.getIdEmpleado();
            ob[1] = boleta.getEmployeeName();
            ob[2] = boleta.getEmployeeLastName();
            ob[3] = boleta.getCode();
            ob[4] = boleta.getIssueDate();
            ob[5] = boleta.getSalarioBase();
            ob[6] = boleta.getComision();
            ob[7] = boleta.getEarnedSalary();
            ob[8] = boleta.getISSS();
            ob[9] = boleta.getAFP();
            ob[10] = boleta.getRenta();
            ob[11] = boleta.getCredito();
            ob[12] = boleta.getBancoCredito();
            ob[13] = boleta.getHipoteca();
            ob[14] = boleta.getBancoHipoteca();
            ob[15] = boleta.getProcuraduria();
            ob[16] = boleta.getInstitucionProcuraduria();
            ob[17] = boleta.getOtrosDescuentos();
            ob[18] = boleta.getSalaryTotal();
            ob[19] = boleta.getBonificacion();
            ob[20] = boleta.getAlerta();
            dfcat.addRow(ob);
        }

        tableBoletas.setModel(dfcat);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondo_planilla_pago = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        seleccion_empleado = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        id = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableBoletas = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Selección de empleado");

        seleccion_empleado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        seleccion_empleado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Elvis Teck", "Susana Oria" }));
        seleccion_empleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seleccion_empleadoActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("ID:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Nombre:");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/6073873 (2).png"))); // NOI18N

        jButton1.setText("Exportar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

        tableBoletas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "idEmpleado", "Nombre", "Apellido", "Codigo de boleta", "Fecha de Creacion", "Salario Base", "Comision", "Salario Devengado", "ISSS", "AFP", "Renta", "Credito", "Banco Credito", "Hipoteca", "Banco Hipoteca", "Procuraduria", "Institucion", "Total Descuentos", "Salario Total", "Bonificacion", "Alerta"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, true, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableBoletas.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane2.setViewportView(tableBoletas);
        if (tableBoletas.getColumnModel().getColumnCount() > 0) {
            tableBoletas.getColumnModel().getColumn(0).setResizable(false);
            tableBoletas.getColumnModel().getColumn(0).setPreferredWidth(75);
            tableBoletas.getColumnModel().getColumn(1).setPreferredWidth(100);
            tableBoletas.getColumnModel().getColumn(2).setResizable(false);
            tableBoletas.getColumnModel().getColumn(2).setPreferredWidth(100);
            tableBoletas.getColumnModel().getColumn(3).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(4).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(5).setPreferredWidth(100);
            tableBoletas.getColumnModel().getColumn(6).setPreferredWidth(100);
            tableBoletas.getColumnModel().getColumn(7).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(8).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(9).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(10).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(11).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(12).setPreferredWidth(100);
            tableBoletas.getColumnModel().getColumn(13).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(14).setPreferredWidth(100);
            tableBoletas.getColumnModel().getColumn(15).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(16).setPreferredWidth(100);
            tableBoletas.getColumnModel().getColumn(17).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(18).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(19).setPreferredWidth(150);
            tableBoletas.getColumnModel().getColumn(20).setPreferredWidth(100);
        }

        jButton2.setText("Enviar por correo");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout fondo_planilla_pagoLayout = new javax.swing.GroupLayout(fondo_planilla_pago);
        fondo_planilla_pago.setLayout(fondo_planilla_pagoLayout);
        fondo_planilla_pagoLayout.setHorizontalGroup(
            fondo_planilla_pagoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_planilla_pagoLayout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addGroup(fondo_planilla_pagoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane2)
                    .addGroup(fondo_planilla_pagoLayout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(fondo_planilla_pagoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(fondo_planilla_pagoLayout.createSequentialGroup()
                                .addGap(219, 219, 219)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(seleccion_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(fondo_planilla_pagoLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(fondo_planilla_pagoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(fondo_planilla_pagoLayout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(Nombre))
                                    .addGroup(fondo_planilla_pagoLayout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel2)
                                        .addGap(56, 56, 56)
                                        .addComponent(id)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1)
                                .addGap(35, 35, 35)
                                .addComponent(jButton2)
                                .addGap(66, 66, 66)))))
                .addGap(15, 15, 15))
        );
        fondo_planilla_pagoLayout.setVerticalGroup(
            fondo_planilla_pagoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondo_planilla_pagoLayout.createSequentialGroup()
                .addGroup(fondo_planilla_pagoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondo_planilla_pagoLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(fondo_planilla_pagoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(seleccion_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(fondo_planilla_pagoLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(fondo_planilla_pagoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(fondo_planilla_pagoLayout.createSequentialGroup()
                                .addGroup(fondo_planilla_pagoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(id))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(fondo_planilla_pagoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(Nombre)
                                    .addComponent(jButton1)
                                    .addComponent(jButton2))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fondo_planilla_pago, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fondo_planilla_pago, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void seleccion_empleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seleccion_empleadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_seleccion_empleadoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     int selectedRow = tableBoletas.getSelectedRow();
    if (selectedRow != -1) {
        // Usar una función auxiliar para manejar los valores nulos y la conversión de datos
        String idEmpleado = getStringValueAt(selectedRow, 0);
        String nombreEmpleado = getStringValueAt(selectedRow, 1);
        String apellidoEmpleado = getStringValueAt(selectedRow, 2);
        String codigoBoleta = getStringValueAt(selectedRow, 3);
        String fechaCreacion = obtenerUltimoDiaDelMes();
        double salarioBase = getDoubleValueAt(selectedRow, 5);
        double comision = getDoubleValueAt(selectedRow, 6);
        double salarioDevengado = getDoubleValueAt(selectedRow, 7);
        double isss = getDoubleValueAt(selectedRow, 8);
        double afp = getDoubleValueAt(selectedRow, 9);
        double renta = getDoubleValueAt(selectedRow, 10);
        double credito = getDoubleValueAt(selectedRow, 11);
        String bancoCredito = getStringValueAt(selectedRow, 12);
        String codigoBancoCredito = "123456"; // Valor de ejemplo
        double hipoteca = getDoubleValueAt(selectedRow, 13);
        String bancoHipoteca = getStringValueAt(selectedRow, 14);
        String codigoBancoHipoteca = "789012"; // Valor de ejemplo
        double procuraduria = getDoubleValueAt(selectedRow, 15);
        String Institucion = getStringValueAt(selectedRow, 16);
        String codigoProcuraduria = "887181";
        double totalDescuentos = getDoubleValueAt(selectedRow, 17);
        double salarioTotal = getDoubleValueAt(selectedRow, 18);
        String bonificacion = getStringValueAt(selectedRow, 19);
        String alerta = getStringValueAt(selectedRow, 20);
        String nombreArchivo = codigoBoleta;
        

        // Assuming 'this' is an instance of the class containing convertHtmlToPdf3 method
        if (pdfExiste(nombreArchivo)) {
            JOptionPane.showMessageDialog(this, "El archivo PDF ya existe.");
        } else {
            // Asumir que 'this' es una instancia de la clase que contiene el método convertHtmlToPdf3
            PDF.convertHtmlToPdf3(
                nombreEmpleado, apellidoEmpleado, idEmpleado,
                codigoBoleta, fechaCreacion, salarioBase,
                comision, salarioDevengado, isss, afp, renta,
                credito, bancoCredito, codigoBancoCredito,
                hipoteca, bancoHipoteca, codigoBancoHipoteca,
                procuraduria, Institucion, codigoProcuraduria, totalDescuentos, salarioTotal,
                bonificacion, alerta, nombreArchivo
            );
            JOptionPane.showMessageDialog(this, "Datos validos");
        }
    
    }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

            String correo = "@gmail.com";

            while (true) {
                correo = JOptionPane.showInputDialog(null, "Ingrese su correo electrónico:", correo);

                if (correo == null) {
                    JOptionPane.showMessageDialog(null, "Operación cancelada.", "Cancelación", JOptionPane.WARNING_MESSAGE);
                    break;
                } else if (correo.endsWith("@gmail.com")) {
                    JOptionPane.showMessageDialog(null, "Correo válido: " + correo, "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "El correo debe terminar en @gmail.com. Por favor, ingrese un correo válido.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            String from = "softwareworldrevolution24@gmail.com";
            String to = correo;
            String subject = "Estimado empleado";
            String body = "Se le adjunta su boleta de pago en formato pdf";

            Correo.sendEmailWithAttachment(from, to, subject, body);
    }//GEN-LAST:event_jButton2ActionPerformed


    private boolean pdfExiste(String nombreArchivo) {
        String rutaPDF = System.getProperty("user.home") + File.separator + "Documents" + File.separator + "Pdf de empleados" + File.separator;

        File archivo = new File(rutaPDF + nombreArchivo + ".pdf");
        return archivo.exists();
    }

     private String getStringValueAt(int row, int column) {
     Object value = tableBoletas.getValueAt(row, column);
     return (value != null) ? value.toString() : "";
 }

 private double getDoubleValueAt(int row, int column) {
     Object value = tableBoletas.getValueAt(row, column);
     return (value != null && !value.toString().isEmpty()) ? Double.parseDouble(value.toString()) : 0.0;
 }
 
 public String obtenerUltimoDiaDelMes() {
        LocalDate fechaActual = LocalDate.now();
        LocalDate ultimoDiaDelMes = fechaActual.withDayOfMonth(fechaActual.lengthOfMonth());
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return ultimoDiaDelMes.format(formato);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Nombre;
    private javax.swing.JPanel fondo_planilla_pago;
    private javax.swing.JLabel id;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JComboBox<String> seleccion_empleado;
    private javax.swing.JTable tableBoletas;
    // End of variables declaration//GEN-END:variables
}
