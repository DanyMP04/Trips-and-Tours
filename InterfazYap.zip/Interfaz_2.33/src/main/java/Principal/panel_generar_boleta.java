/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Principal;

import Principal.panel_calculo_puntos.EmpleadoInfo;
import com.formdev.flatlaf.FlatClientProperties;
import conexion.Boleta;
import conexion.Comision;
import conexion.EmailSender;
import conexion.Empleados;
import conexion.MetodosBoleta;
import conexion.MetodosComision;
import conexion.MetodosEmpleado;
import conexion.MetodosPlanilla;
import conexion.Planilla;
import conexion.pdf;
import java.awt.BorderLayout;
import java.awt.Color;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author xyali
 */
public class panel_generar_boleta extends javax.swing.JPanel {

    private static final pdf PDF = new pdf();
    private static final EmailSender Correo = new EmailSender();
    MetodosEmpleado fu = new MetodosEmpleado();
    MetodosComision metCom = new MetodosComision();
    MetodosPlanilla fua = new MetodosPlanilla();
    private Map<String, panel_calculo_puntos.EmpleadoInfo> empleadosMap = new HashMap<>();
    private List<Empleados> empleados;
    private List<String> boleta;
    private List<String> comision;
    private panel_calculo_puntos instancia;
    public double descuentosLey;
    private boolean shakeInProgress = false;
    private boolean primerError = true;
    public int puntosI;
    public int puntosN;
    public int puntosTot;
    public double salarioTot;
    public String nombre;
    public String IdEmpleado;
    public double ComisionN;
    public double ComisionI;
    public double ComisionT;
    public double descuentoAdicional;
    public double descuentoAdicional1;
    public double descuentoAdicional2;
    public double descuentosTot;
    public String otrosDescuentosText1;
    public String otrosDescuentosText2;
    public String otrosDescuentosText3;
    private double salarioTotalInicial = 0.0;

    /**
     * Creates new form panel_generar_boleta
     */
    public panel_generar_boleta(panel_calculo_puntos instancia, List<Empleados> empleados, Map<String, panel_calculo_puntos.EmpleadoInfo> empleadosMap) {
        initComponents();
        InitStyles();
        this.instancia = instancia;
        this.empleados = empleados;
        this.empleadosMap = empleadosMap;
        hacerAlgo();
        CalcularSalario();
        agregarListeners();
        agregarListeners1();
        agregarListeners2();
        mostrarInformacionEmpleado();
    }

    private void InitStyles() {
        OtrosDescuentos.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        OtrosDescuentos1.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        OtrosDescuentos2.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        descuento1.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        exportar17.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
    }

    public void mostrarInformacionEmpleado() {
        panel_calculo_puntos.EmpleadoInfo info = instancia.getEmpleadoInfoSeleccionado();
        if (info != null) {
            int id = info.getId();
            nombre = info.getNombre();
            String apellido = info.getApellido();
            IdEmpleado = Integer.toString(id);
            identificador.setText(IdEmpleado);
            Nombre.setText(nombre);
            Apellido.setText(apellido);
            String fechaPago = fechaMes.getText();
            Codigo.setText("Boleta_" + IdEmpleado + "_" + nombre.replace(" ", "_") + "_" + fechaPago);
        } else {
            System.out.println("No se ha seleccionado ningún empleado.");
        }
    }

    private void agregarListeners() {
        OtrosDescuentos.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void removeUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void insertUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }
        });
    }

    private void agregarListeners1() {
        OtrosDescuentos1.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void removeUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void insertUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }
        });
    }

    private void agregarListeners2() {
        OtrosDescuentos2.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void removeUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void insertUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }
        });
    }

    private void shakeComponent(JComponent component) {
        if (shakeInProgress) {
            return;
        }

        shakeInProgress = true;
        final int originalX = component.getLocation().x;
        final int originalY = component.getLocation().y;

        final int shakeDistance = 3;
        final int shakeDuration = 30;
        final int shakeCount = 3;

        new Thread(() -> {
            try {
                for (int i = 0; i < shakeCount; i++) {
                    // Movimiento hacia la izquierda
                    SwingUtilities.invokeLater(() -> component.setLocation(originalX - shakeDistance, originalY));
                    Thread.sleep(shakeDuration);
                    // Movimiento hacia la derecha
                    SwingUtilities.invokeLater(() -> component.setLocation(originalX + shakeDistance, originalY));
                    Thread.sleep(shakeDuration);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                // Restaurar la posición original
                SwingUtilities.invokeLater(() -> component.setLocation(originalX, originalY));
                shakeInProgress = false;
            }
        }).start();
    }

    private void actualizarSalarioTotal() {
        otrosDescuentosText1 = OtrosDescuentos.getText();
        otrosDescuentosText2 = OtrosDescuentos1.getText();
        otrosDescuentosText3 = OtrosDescuentos2.getText();
        double descuentoAdicional = 0.0;
        double descuentoAdicional1 = 0.0;
        double descuentoAdicional2 = 0.0;
        boolean hayError = false;
        double salarioTotF = salarioTotalInicial;
        double maxDescuentoTotal = salarioTotF * 0.20; // 20% fijo del salario inicial

        try {
            // Procesar todos los descuentos
            if (!otrosDescuentosText1.isEmpty()) {
                descuentoAdicional = Double.parseDouble(otrosDescuentosText1);
                descuentoAdicional = redondear(descuentoAdicional);
                if (descuentoAdicional > maxDescuentoTotal) {
                    throw new NumberFormatException("El primer descuento no puede ser mayor al 20% del salario total.");
                }
            }
            if (!otrosDescuentosText2.isEmpty()) {
                descuentoAdicional1 = Double.parseDouble(otrosDescuentosText2);
                descuentoAdicional1 = redondear(descuentoAdicional1);
            }
            if (!otrosDescuentosText3.isEmpty()) {
                descuentoAdicional2 = Double.parseDouble(otrosDescuentosText3);
                descuentoAdicional2 = redondear(descuentoAdicional2);
            }

            // Calcular el total de descuentos actual
            double totalDescuentosActual = descuentoAdicional + descuentoAdicional1 + descuentoAdicional2;

            // Redondear el total de descuentos actual
            totalDescuentosActual = redondear(totalDescuentosActual);

            // Verificar que el total de descuentos no supere el salario total (con un margen de error)
            double margenError = 0.01; // Puedes ajustar este margen si es necesario
            if (totalDescuentosActual > salarioTotF + margenError) {
                throw new NumberFormatException("El total de descuentos no puede ser mayor al salario total.");
            }

            // Calcular el salario restante después de los descuentos
            double salarioRestante = salarioTotF - totalDescuentosActual;

            // Asegúrate de que el salario restante no sea negativo
            salarioRestante = Math.max(salarioRestante, 0.0);

            // Redondear el salario restante
            salarioRestante = redondear(salarioRestante);

            // Actualizar los máximos disponibles para cada campo
            actualizarMaximoDescuento(OtrosDescuentos, Math.min(maxDescuentoTotal, salarioRestante + descuentoAdicional));
            actualizarMaximoDescuento(OtrosDescuentos1, salarioRestante + descuentoAdicional1);
            actualizarMaximoDescuento(OtrosDescuentos2, salarioRestante + descuentoAdicional2);

            OtrosDescuentos.setBackground(Color.WHITE);
            OtrosDescuentos1.setBackground(Color.WHITE);
            OtrosDescuentos2.setBackground(Color.WHITE);
            exportar17.setEnabled(true);
        } catch (NumberFormatException e) {
            OtrosDescuentos.setBackground(Color.PINK);
            OtrosDescuentos1.setBackground(Color.PINK);
            OtrosDescuentos2.setBackground(Color.PINK);
            exportar17.setEnabled(false);
            hayError = true;
            JOptionPane.showMessageDialog(this, "Verifique los datos ingresados: " + e.getMessage());
        }

        if (!hayError) {
            // Recalcular el salario total
            double salarioBase = 365;
            double bonificaciones = ComisionT;
            double salarioDevengado = 0.0;
            if (puntosTot <= 525) {
                salarioDevengado = salarioBase;
            } else if (puntosTot > 525) {
                salarioDevengado = salarioBase + bonificaciones;
            }
            double isss = salarioDevengado * 0.03;
            double afp = salarioDevengado * 0.0725;
            double salarioSubtotal = salarioDevengado - isss - afp;

            // Calcular total de descuentos adicionales
            double totalDescuentos = descuentoAdicional + descuentoAdicional1 + descuentoAdicional2;
            Descuento.setText(String.format("%.2f", totalDescuentos));

            // Calcular renta (usando el método existente)
            ResultadoCalculo resultado = calcularTramo(salarioDevengado, salarioSubtotal);

            // Actualizar el salario total
            double salarioTotal = resultado.getSalarioTotal() - totalDescuentos;
            salarioTotal = Math.max(salarioTotal, 0.0);

            // Actualizar los campos en la interfaz
            Salariodevengado.setText(String.format("%.2f", salarioDevengado));
            ISSS.setText(String.format("%.2f", isss));
            AFP.setText(String.format("%.2f", afp));
            Renta.setText(String.format("%.2f", resultado.getRenta()));
            Salariosubtotal.setText(String.format("%.2f", salarioSubtotal));
            SalarioTotal.setText(String.format("%.2f", salarioTotal));

            // Actualizar los valores globales si es necesario
            this.salarioTot = salarioTotal;
            this.descuentosLey = isss + afp + resultado.getRenta();
            DescuentosTotales.setText(String.format("%.2f", descuentosLey));
            this.descuentosTot = isss + afp + resultado.getRenta() + descuentoAdicional + descuentoAdicional1 + descuentoAdicional2;
        } else {
            SalarioTotal.setText("Error");
        }
    }

    private void actualizarMaximoDescuento(JTextField campo, double maxDescuento) {
        String mensaje = String.format("Máximo descuento disponible: %.2f", Math.min(maxDescuento, salarioTotalInicial));
        campo.setToolTipText(mensaje);
    }

    private double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    public static String obtenerMesEnLetras() {
        // Obtener la fecha completa en formato "yyyy-MM-dd"
        String fechaCompleta = obtenerDiaDelMes();

        // Parsear la fecha completa a un objeto LocalDate
        LocalDate fecha = LocalDate.parse(fechaCompleta);

        // Obtener el mes en letras
        return fecha.getMonth().getDisplayName(TextStyle.FULL, new Locale("es", "ES"));
    }

    public static int obtenerAnio() {
        // Obtener la fecha completa en formato "yyyy-MM-dd"
        String fechaCompleta = obtenerDiaDelMes();

        // Parsear la fecha completa a un objeto LocalDate
        LocalDate fecha = LocalDate.parse(fechaCompleta);

        // Obtener el año
        return fecha.getYear();
    }

    private static String obtenerDiaDelMes() {
        // Método de ejemplo para obtener la fecha actual en formato "yyyy-MM-dd"
        LocalDate fechaActual = LocalDate.now();
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return fechaActual.format(formato);
    }

    public String obtenerUltimoDiaDelMes() {
        LocalDate fechaActual = LocalDate.now();
        LocalDate ultimoDiaDelMes = fechaActual.withDayOfMonth(fechaActual.lengthOfMonth());
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return ultimoDiaDelMes.format(formato);
    }

    public class ResultadoCalculo {

        private double salarioTotal;
        private double renta;

        public ResultadoCalculo(double salarioTotal, double renta) {
            this.salarioTotal = salarioTotal;
            this.renta = renta;
        }

        public double getSalarioTotal() {
            return salarioTotal;
        }

        public double getRenta() {
            return renta;
        }
    }

    public ResultadoCalculo calcularTramo(double SalarioDevengado, double sala_sub) {
        double renta = 0;
        double sala_tot = 0;

        if (sala_sub >= 0.01 && sala_sub <= 472.00) {
            // Tramo I: Sin retención
            sala_tot = sala_sub;
        } else if (sala_sub >= 472.01 && sala_sub <= 895.24) {
            // Tramo II: 10% sobre el exceso de 472.00 más una cuota fija de 17.67
            renta = (sala_sub - 472.00) * 0.10 + 17.67;
            sala_tot = sala_sub - renta;
        } else if (sala_sub >= 895.25 && sala_sub <= 2038.10) {
            // Tramo III: 20% sobre el exceso de 895.24 más una cuota fija de 60.00
            renta = (sala_sub - 895.24) * 0.20 + 60.00;
            sala_tot = sala_sub - renta;
        } else if (sala_sub >= 2038.11) {
            // Tramo IV: 30% sobre el exceso de 2038.10 más una cuota fija de 288.57
            renta = (sala_sub - 2038.10) * 0.30 + 288.57;
            sala_tot = sala_sub - renta;
        }

        return new ResultadoCalculo(sala_tot, renta);
    }

    public void CalcularSalario() {
        puntosN = instancia.getTotalPuntosN();
        puntosI = instancia.getTotalPuntosI();
        puntosTot = puntosI + puntosN;
        ComisionN = instancia.getComisionTotalNacional();
        ComisionI = instancia.getComisionTotalInternacional();
        ComisionT = ComisionI + ComisionN;

        double salarioBase = 365; // salario mínimo de base
        double SalarioDevengado = salarioBase;

        if (puntosTot <= 525) {
            SalarioDevengado = salarioBase;
        } else if (puntosTot > 525 && puntosTot <= 2500) {
            SalarioDevengado = salarioBase + ComisionT;
        } else if (puntosTot > 2500) {
            SalarioDevengado = salarioBase + ComisionT;
        }

        double isss = SalarioDevengado * 0.03;
        double afp = SalarioDevengado * 0.0725;
        double SalarioSubtotal = SalarioDevengado - isss - afp;

        Salariodevengado.setText(String.format("%.2f", SalarioDevengado));
        ISSS.setText(String.format("%.2f", isss));
        AFP.setText(String.format("%.2f", afp));
        Salariosubtotal.setText(String.format("%.2f", SalarioSubtotal));

        ResultadoCalculo resultado = calcularTramo(SalarioDevengado, SalarioSubtotal);

        double salarioTotal = resultado.getSalarioTotal();
        SalarioTotal.setText(String.format("%.2f", salarioTotal));

        // Asigna el valor inicial de salario total
        salarioTotalInicial = salarioTotal;
        double xd = salarioTotal * 0.20;
        String cf1 = String.valueOf(xd);

        double renta = Double.parseDouble(String.format("%.2f", resultado.getRenta()));
        Renta.setText(String.format("%.2f", renta));

        descuentosLey = isss + afp + renta;
        DescuentosTotales.setText(String.format("%.2f", descuentosLey));

        descuentosTot = descuentosLey + descuentoAdicional + descuentoAdicional1 + descuentoAdicional2;
        Descuento.setText("0");
    }

    public void hacerAlgo() {
        fechaMes.setText(obtenerDiaDelMes());
        PeriodoPago.setText(obtenerUltimoDiaDelMes());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        fondo_interno_generar_boleta = new javax.swing.JPanel();
        Salariosubtotal = new javax.swing.JLabel();
        AFP = new javax.swing.JLabel();
        jLabel289 = new javax.swing.JLabel();
        Codigo = new javax.swing.JLabel();
        ISSS = new javax.swing.JLabel();
        jSeparator150 = new javax.swing.JSeparator();
        jLabel290 = new javax.swing.JLabel();
        jLabel291 = new javax.swing.JLabel();
        jLabel292 = new javax.swing.JLabel();
        jSeparator151 = new javax.swing.JSeparator();
        jLabel293 = new javax.swing.JLabel();
        jLabel294 = new javax.swing.JLabel();
        jLabel295 = new javax.swing.JLabel();
        identificador = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        Apellido = new javax.swing.JLabel();
        jLabel296 = new javax.swing.JLabel();
        PeriodoPago = new javax.swing.JLabel();
        fechaMes = new javax.swing.JLabel();
        jSeparator152 = new javax.swing.JSeparator();
        jLabel297 = new javax.swing.JLabel();
        jLabel298 = new javax.swing.JLabel();
        Salariodevengado = new javax.swing.JLabel();
        jSeparator153 = new javax.swing.JSeparator();
        jLabel299 = new javax.swing.JLabel();
        jSeparator154 = new javax.swing.JSeparator();
        jLabel300 = new javax.swing.JLabel();
        jSeparator155 = new javax.swing.JSeparator();
        jLabel301 = new javax.swing.JLabel();
        jSeparator156 = new javax.swing.JSeparator();
        jLabel302 = new javax.swing.JLabel();
        jSeparator157 = new javax.swing.JSeparator();
        jLabel303 = new javax.swing.JLabel();
        OtrosDescuentos2 = new javax.swing.JTextField();
        descuento1 = new javax.swing.JComboBox<>();
        Descuento = new javax.swing.JLabel();
        jSeparator158 = new javax.swing.JSeparator();
        jLabel306 = new javax.swing.JLabel();
        SalarioTotal = new javax.swing.JLabel();
        Renta = new javax.swing.JLabel();
        atras = new javax.swing.JButton();
        OtrosDescuentos1 = new javax.swing.JTextField();
        OtrosDescuentos = new javax.swing.JTextField();
        descuento = new javax.swing.JComboBox<>();
        exportar17 = new javax.swing.JButton();
        jLabel307 = new javax.swing.JLabel();
        jLabel308 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator159 = new javax.swing.JSeparator();
        jLabel309 = new javax.swing.JLabel();
        DescuentosTotales = new javax.swing.JLabel();

        setBackground(java.awt.Color.lightGray);

        fondo_interno_generar_boleta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                fondo_interno_generar_boletaMouseClicked(evt);
            }
        });

        Salariosubtotal.setText("$$$.$$");

        AFP.setText("$$$.$$");

        jLabel289.setText("Código de boleta");

        Codigo.setText("019201");

        ISSS.setText("$$$.$$");

        jLabel290.setText("ID");

        jLabel291.setText("Nombre");

        jLabel292.setText("Apellido");

        jLabel293.setText("Empresa");

        jLabel294.setText("Fecha estimada de Pago");

        jLabel295.setText("Fecha emisión");

        identificador.setText("19382");

        Nombre.setText("Susana");

        Apellido.setText("Oria");

        jLabel296.setText("TRIPS & TOURS ");

        PeriodoPago.setText("23/04/2024 - 30/07/2024");

        fechaMes.setText("28/08/2024");

        jSeparator152.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel297.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel297.setText("DESCUENTOS");

        jLabel298.setText("Salario devengado");

        Salariodevengado.setText("$$$.$$");

        jLabel299.setText("ISSS");

        jLabel300.setText("AFP");

        jLabel301.setText("Salario subtotal");

        jLabel302.setText("Renta");

        jLabel303.setText("Credito");

        OtrosDescuentos2.setBackground(new java.awt.Color(239, 239, 239));

        descuento1.setBackground(new java.awt.Color(239, 239, 239));
        descuento1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Banco Agrícola S.A.", "Banco Davivienda Salvadoreño S.A.", "Banco de América Central S.A. (BAC Credomatic)", "Scotiabank El Salvador S.A.", "Banco Cuscatlán de El Salvador S.A.", "Banco G&T Continental El Salvador S.A." }));

        Descuento.setText("$$$.$$");

        jLabel306.setText("Salario total");

        SalarioTotal.setText("$$$.$$");

        Renta.setText("$$$.$$");

        atras.setBackground(new java.awt.Color(239, 239, 239));
        atras.setText("Atrás");
        atras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atrasActionPerformed(evt);
            }
        });

        OtrosDescuentos1.setBackground(new java.awt.Color(239, 239, 239));

        OtrosDescuentos.setBackground(new java.awt.Color(239, 239, 239));

        descuento.setBackground(new java.awt.Color(239, 239, 239));
        descuento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Banco Agrícola, S.A.", "Banco Cuscatlán de El Salvador, S.A.", "Banco Davivienda Salvadoreño, S.A.", "Banco Promérica, S.A.", "Banco de América Central, S.A.", "Banco Atlántida El Salvador, S.A.", "Banco ABANK, S.A.", "Banco Industrial El Salvador, S.A.", "Banco Azul de El Salvador, S.A.", " " }));
        descuento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                descuentoActionPerformed(evt);
            }
        });

        exportar17.setBackground(new java.awt.Color(239, 239, 239));
        exportar17.setText("Guardar");
        exportar17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportar17ActionPerformed(evt);
            }
        });

        jLabel307.setText("Hipoteca");

        jLabel308.setText("Procuraduria");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Planilla");

        jLabel309.setText("Total descuentos de Ley");

        DescuentosTotales.setText("$$$.$$");

        javax.swing.GroupLayout fondo_interno_generar_boletaLayout = new javax.swing.GroupLayout(fondo_interno_generar_boleta);
        fondo_interno_generar_boleta.setLayout(fondo_interno_generar_boletaLayout);
        fondo_interno_generar_boletaLayout.setHorizontalGroup(
            fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel294)
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addComponent(jLabel295)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(fechaMes))
                    .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                            .addComponent(jLabel293)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel296))
                        .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                            .addComponent(jLabel290)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(identificador))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                            .addComponent(jLabel289)
                            .addGap(18, 18, 18)
                            .addComponent(Codigo))
                        .addComponent(jSeparator150, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                            .addComponent(jLabel291)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Nombre))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                            .addComponent(jLabel292)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Apellido))
                        .addComponent(jSeparator151, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(PeriodoPago))
                .addGap(28, 28, 28)
                .addComponent(jSeparator152, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator158)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                        .addGap(35, 35, 35)
                                        .addComponent(jLabel306)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(SalarioTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(88, 88, 88)
                                        .addComponent(exportar17))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel303)
                                            .addComponent(jLabel307)
                                            .addComponent(jLabel308))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(OtrosDescuentos1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(OtrosDescuentos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(OtrosDescuentos2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(descuento, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(descuento1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addGap(65, 65, 65)
                                                .addComponent(Descuento)))))
                                .addGap(131, 131, 131))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addComponent(jLabel309)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(DescuentosTotales))
                            .addComponent(jLabel301)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addComponent(jLabel300)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(AFP))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addComponent(jLabel302)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Renta))
                            .addComponent(jSeparator157)
                            .addComponent(jSeparator155)
                            .addComponent(jSeparator154)
                            .addComponent(jSeparator153, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator156)
                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addComponent(jLabel299)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(ISSS))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(Salariosubtotal))
                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addComponent(jLabel298)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Salariodevengado))
                            .addComponent(jSeparator159))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel297)
                        .addGap(101, 101, 101)))
                .addGap(35, 35, 35))
            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(atras, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(263, 263, 263)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        fondo_interno_generar_boletaLayout.setVerticalGroup(
            fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addGap(222, 222, 222)
                        .addComponent(jLabel297)
                        .addGap(106, 106, 106))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel298)
                            .addComponent(Salariodevengado))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator153, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel299)
                            .addComponent(ISSS))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator154, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel300)
                            .addComponent(AFP))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator155, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Salariosubtotal)
                            .addComponent(jLabel301, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator156, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel302)
                            .addComponent(Renta))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator157, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel309)
                            .addComponent(DescuentosTotales))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator159, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel303)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel307)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel308))
                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addComponent(OtrosDescuentos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(OtrosDescuentos1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(4, 4, 4)
                                .addComponent(OtrosDescuentos2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(20, 20, 20))
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(descuento1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(descuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Descuento)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator158, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(exportar17)
                        .addComponent(jLabel306)
                        .addComponent(SalarioTotal)))
                .addContainerGap(20, Short.MAX_VALUE))
            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(atras)
                .addGap(90, 90, 90)
                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel289)
                            .addComponent(Codigo, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator150, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel290)
                            .addComponent(identificador))
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel291)
                            .addComponent(Nombre))
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel292)
                            .addComponent(Apellido))
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator151, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel293)
                            .addComponent(jLabel296))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel294)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PeriodoPago)
                        .addGap(26, 26, 26)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel295)
                            .addComponent(fechaMes)))
                    .addComponent(jSeparator152, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(54, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(fondo_interno_generar_boleta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(118, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(fondo_interno_generar_boleta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void atrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atrasActionPerformed

        panel_calculo_puntos calculo_puntos = new panel_calculo_puntos(empleados, empleadosMap);
        calculo_puntos.setSize(940, 510);
        calculo_puntos.setLocation(0, 0);

        jPanel1.removeAll();
        jPanel1.add(calculo_puntos, BorderLayout.CENTER);
        jPanel1.revalidate();
        jPanel1.repaint();
    }//GEN-LAST:event_atrasActionPerformed

    private void exportar17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportar17ActionPerformed

        double credito;
        double hipoteca;
        double procuraduria;
        String Banco1;
        String Banco2;
        String Institucion;

        try {
            // Intentar convertir el texto a double
            credito = Double.parseDouble(otrosDescuentosText1.isEmpty() ? "0" : otrosDescuentosText1);
            Object selectedItem1 = descuento.getSelectedItem();
            Banco1 = credito == 0 ? "" : selectedItem1.toString(); // Verificar si el crédito es 0

            hipoteca = Double.parseDouble(otrosDescuentosText2.isEmpty() ? "0" : otrosDescuentosText2);
            Object selectedItem2 = descuento1.getSelectedItem();
            Banco2 = hipoteca == 0 ? "" : selectedItem2.toString(); // Verificar si la hipoteca es 0

            procuraduria = Double.parseDouble(otrosDescuentosText3.isEmpty() ? "0" : otrosDescuentosText3);

        } catch (NumberFormatException e) {
            // Asignar 0.0 en caso de error
            credito = 0.0;
            hipoteca = 0.0;
            procuraduria = 0.0;
            Banco1 = "";
            Banco2 = "";
            Institucion = "";
        }

        // Creación de la nueva planilla
        Planilla pla = new Planilla();
        String Bonificacion = "NO APLICA";
        String Alerta = "";
        String Firma = "";
        if (puntosTot <= 525) {
            Alerta = "Usted ha tenido un rendimiento bajo en ventas";
        }
        if (puntosTot > 525 && puntosTot <= 2500) {
            Bonificacion = "NO APLICA";
        } else if (puntosTot > 2500) {
            Bonificacion = "APLICA TAJETA DE REGALO DE 100$";
        }
        String salarioStr = Salariodevengado.getText();
        double salariob = Double.parseDouble(salarioStr);
        int numero = Integer.parseInt(IdEmpleado);

        LocalDate fecha = LocalDate.now();
        if (!fua.puedeGenerarPlanilla(numero, fecha)) {
            JOptionPane.showMessageDialog(this, "Ya existe una planilla para este empleado en el mes actual.");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de que desea guardar la planilla?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            // Asignación de valores a la planilla
            pla.setIdEmployee(numero);
            pla.setCode(Codigo.getText());
            pla.setCreationDate(fechaMes.getText());  // Convertir LocalDate a String
            pla.setEmployeeName(Nombre.getText());  // Asigna el nombre del empleado // Asigna el apellido del empleado
            pla.setEmployeeLastName(Apellido.getText());
            pla.setSalarioB(365);
            pla.setFirma(Firma);
            if (puntosTot >= 525) {
                pla.setComision(ComisionT);
            } else if (puntosTot < 525) {
                double comisionFalse = 0.0;
                pla.setComision(comisionFalse);
            }
            pla.setAlerta(Alerta);
            pla.setEarnedSalary(salariob);
            String mes = obtenerMesEnLetras();
            int anio = obtenerAnio();
            String anioComoString = String.valueOf(anio);
            pla.setMonth(mes);
            pla.setYear(anioComoString);
            String isssStr = ISSS.getText();
            String afpStr = AFP.getText();
            String rentaStr = Renta.getText();
            String otrosDescuentosStr = Descuento.getText();
            pla.setIsss(Double.parseDouble(isssStr));
            pla.setAfp(Double.parseDouble(afpStr));
            pla.setRent(Double.parseDouble(rentaStr));
            pla.setCredito(credito);
            pla.setBancoCredito(Banco1);
            pla.setHipoteca(hipoteca);
            pla.setBancoHipoteca(Banco2);
            pla.setProcuraduria(procuraduria);
            pla.setInstitucionProcuraduria("");
            pla.setBonificacion(Bonificacion);
            pla.setOthersD(Double.parseDouble(otrosDescuentosStr) + descuentosLey);
            Comision com = new Comision();
            // Calcular el salario total después de descuentos
            pla.setSalaryTotal(salarioTot);

            // Guardar la planilla
            if (fua.guardarPlanilla(pla)) {
                JOptionPane.showMessageDialog(this, "Planilla registrada con éxito");
                com.setIdEmpleado(numero);
                String fechaPago = fechaMes.getText();
                com.setFechaComision(fechaPago);
                com.setPuntosGanados(puntosTot);
                com.setComision(ComisionT);
                metCom.guardar(com);
                comision = metCom.Listar();
            } else {
                JOptionPane.showMessageDialog(this, "Error al guardar la planilla");
            }
        } else {
            JOptionPane.showMessageDialog(this, "La operación ha sido cancelada.");
        }
    }//GEN-LAST:event_exportar17ActionPerformed

    private void fondo_interno_generar_boletaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fondo_interno_generar_boletaMouseClicked

    }//GEN-LAST:event_fondo_interno_generar_boletaMouseClicked

    private void descuentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_descuentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_descuentoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AFP;
    private javax.swing.JLabel Apellido;
    private javax.swing.JLabel Codigo;
    private javax.swing.JLabel Descuento;
    private javax.swing.JLabel DescuentosTotales;
    private javax.swing.JLabel ISSS;
    private javax.swing.JLabel Nombre;
    private javax.swing.JTextField OtrosDescuentos;
    private javax.swing.JTextField OtrosDescuentos1;
    private javax.swing.JTextField OtrosDescuentos2;
    private javax.swing.JLabel PeriodoPago;
    private javax.swing.JLabel Renta;
    private javax.swing.JLabel SalarioTotal;
    private javax.swing.JLabel Salariodevengado;
    private javax.swing.JLabel Salariosubtotal;
    private javax.swing.JButton atras;
    private javax.swing.JComboBox<String> descuento;
    private javax.swing.JComboBox<String> descuento1;
    private javax.swing.JButton exportar17;
    private javax.swing.JLabel fechaMes;
    private javax.swing.JPanel fondo_interno_generar_boleta;
    private javax.swing.JLabel identificador;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel289;
    private javax.swing.JLabel jLabel290;
    private javax.swing.JLabel jLabel291;
    private javax.swing.JLabel jLabel292;
    private javax.swing.JLabel jLabel293;
    private javax.swing.JLabel jLabel294;
    private javax.swing.JLabel jLabel295;
    private javax.swing.JLabel jLabel296;
    private javax.swing.JLabel jLabel297;
    private javax.swing.JLabel jLabel298;
    private javax.swing.JLabel jLabel299;
    private javax.swing.JLabel jLabel300;
    private javax.swing.JLabel jLabel301;
    private javax.swing.JLabel jLabel302;
    private javax.swing.JLabel jLabel303;
    private javax.swing.JLabel jLabel306;
    private javax.swing.JLabel jLabel307;
    private javax.swing.JLabel jLabel308;
    private javax.swing.JLabel jLabel309;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator150;
    private javax.swing.JSeparator jSeparator151;
    private javax.swing.JSeparator jSeparator152;
    private javax.swing.JSeparator jSeparator153;
    private javax.swing.JSeparator jSeparator154;
    private javax.swing.JSeparator jSeparator155;
    private javax.swing.JSeparator jSeparator156;
    private javax.swing.JSeparator jSeparator157;
    private javax.swing.JSeparator jSeparator158;
    private javax.swing.JSeparator jSeparator159;
    // End of variables declaration//GEN-END:variables
}
