/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author MINEDUCYT
 */
public class Comision {
    private int idComision;
    private int idEmpleado;
    private String fechaComision;
    private int puntosGanados;
    private double comision;

    public Comision() {
    }

    public Comision(int idComision, int idEmpleado, String fechaComision, int puntosGanados, double comision) {
        this.idComision = idComision;
        this.idEmpleado = idEmpleado;
        this.fechaComision = fechaComision;
        this.puntosGanados = puntosGanados;
        this.comision = comision;
    }

    public int getIdComision() {
        return idComision;
    }

    public void setIdComision(int idComision) {
        this.idComision = idComision;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getFechaComision() {
        return fechaComision;
    }

    public void setFechaComision(String fechaComision) {
        this.fechaComision = fechaComision;
    }

    public int getPuntosGanados() {
        return puntosGanados;
    }

    public void setPuntosGanados(int puntosGanados) {
        this.puntosGanados = puntosGanados;
    }

    public double getComision() {
        return comision;
    }

    public void setComision(double comision) {
        this.comision = comision;
    }
    
    
}
