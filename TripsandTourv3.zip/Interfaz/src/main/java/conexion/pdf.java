/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;
import com.aspose.pdf.Document;
import com.aspose.pdf.HtmlLoadOptions;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import javax.swing.JFileChooser;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
/**
 *
 * @author MINEDUCYT
 */
public class pdf {

    public static void main(String[] args) {
        // Cadena de código HTML
        String htmlContent = "<!DOCTYPE html>\n" +
"<html lang=\"es\">\n" +
"<head>\n" +
"    <meta charset=\"UTF-8\">\n" +
"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
"    <title>Boleta de Pago</title>\n" +
"    <style>\n" +
"        html, body {\n" +
"            margin: 0;\n" +
"            padding: 0;\n" +
"            width: 100%;\n" +
"            height: 100%;\n" +
"            font-family: Arial, sans-serif;\n" +
"            color: #333;\n" +
"        }\n" +
"        .container {\n" +
"            width: 100%;\n" +
"            height: 100%;\n" +
"            padding: 20px;\n" +
"            box-sizing: border-box;\n" +
"            border: 1px solid #ddd;\n" +
"            border-radius: 8px;\n" +
"            background-color: #f9f9f9;\n" +
"        }\n" +
"        .header, .footer {\n" +
"            text-align: center;\n" +
"            margin-bottom: 20px;\n" +
"        }\n" +
"        .header h1 {\n" +
"            margin: 0;\n" +
"            color: #007bff;\n" +
"        }\n" +
"        .details, .summary {\n" +
"            margin-bottom: 20px;\n" +
"        }\n" +
"        .details table, .summary table {\n" +
"            width: 100%;\n" +
"            border-collapse: collapse;\n" +
"        }\n" +
"        .details th, .summary th {\n" +
"            background-color: #007bff;\n" +
"            color: #fff;\n" +
"            padding: 10px;\n" +
"            text-align: left;\n" +
"        }\n" +
"        .details td, .summary td {\n" +
"            padding: 10px;\n" +
"            border-bottom: 1px solid #ddd;\n" +
"        }\n" +
"        .summary td {\n" +
"            text-align: right;\n" +
"        }\n" +
"        .total {\n" +
"            font-weight: bold;\n" +
"            font-size: 1.2em;\n" +
"        }\n" +
"    </style>\n" +
"</head>\n" +
"<body>\n" +
"    <div class=\"container\">\n" +
"        <div class=\"header\">\n" +
"            <h1>Boleta de Pago</h1>\n" +
"            <p>Empresa: Trips & Tours S.A.</p>\n" +
"            <p>Dirección: Calle Ficticia 123, Ciudad, País</p>\n" +
"        </div>\n" +
"        <div class=\"details\">\n" +
"            <h2>Detalles del Empleado</h2>\n" +
"            <table>\n" +
"                <tr>\n" +
"                    <th>Nombre</th>\n" +
"                    <td>Juan Pérez</td>\n" +
"                </tr>\n" +
"                <tr>\n" +
"                    <th>Posición</th>\n" +
"                    <td>Desarrollador de Software</td>\n" +
"                </tr>\n" +
"                <tr>\n" +
"                    <th>ID Empleado</th>\n" +
"                    <td>EMP12345</td>\n" +
"                </tr>\n" +
"                <tr>\n" +
"                    <th>Fecha de Pago</th>\n" +
"                    <td>31 de Julio de 2024</td>\n" +
"                </tr>\n" +
"            </table>\n" +
"        </div>\n" +
"        <div class=\"summary\">\n" +
"            <h2>Resumen de Pago</h2>\n" +
"            <table>\n" +
"                <tr>\n" +
"                    <th>Descripción</th>\n" +
"                    <th>Monto</th>\n" +
"                </tr>\n" +
"                <tr>\n" +
"                    <td>Salario Base</td>\n" +
"                    <td>$2,000.00</td>\n" +
"                </tr>\n" +
"                <tr>\n" +
"                    <td>Horas Extras</td>\n" +
"                    <td>$150.00</td>\n" +
"                </tr>\n" +
"                <tr>\n" +
"                    <td>Bonificaciones</td>\n" +
"                    <td>$100.00</td>\n" +
"                </tr>\n" +
"                <tr>\n" +
"                    <td>Descuentos</td>\n" +
"                    <td>($50.00)</td>\n" +
"                </tr>\n" +
"                <tr>\n" +
"                    <td class=\"total\">Total a Pagar</td>\n" +
"                    <td class=\"total\">$2,200.00</td>\n" +
"                </tr>\n" +
"            </table>\n" +
"        </div>\n" +
"        <div class=\"footer\">\n" +
"            <p>Gracias por tu trabajo y dedicación.</p>\n" +
"            <p>Trips & Tours S.A.</p>\n" +
"        </div>\n" +
"    </div>\n" +
"</body>\n" +
"</html>";

        // Crear un ByteArrayInputStream a partir del contenido HTML
        ByteArrayInputStream inputStream = new ByteArrayInputStream(htmlContent.getBytes(StandardCharsets.UTF_8));

        // Opciones de carga de HTML
        HtmlLoadOptions htmlLoadOptions = new HtmlLoadOptions();

        // Cargar el HTML desde el InputStream
        Document pdfDocument = new Document(inputStream, htmlLoadOptions);

       try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Crear el JFileChooser
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar archivo PDF");

        // Establecer un filtro de extensión para archivos PDF
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos PDF", "pdf");
        fileChooser.setFileFilter(filter);

        // Establecer el nombre del archivo por defecto
        fileChooser.setSelectedFile(new java.io.File("salida.pdf"));

        // Mostrar el diálogo de guardado
        int userSelection = fileChooser.showSaveDialog(null);

        // Procesar la selección del usuario
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            java.io.File fileToSave = fileChooser.getSelectedFile();
            // Guardar el documento PDF en la ubicación seleccionada por el usuario
            // pdfDocument.save(fileToSave.getAbsolutePath()); // Asegúrate de tener esta línea implementada correctamente
            System.out.println("Conversión completada. El archivo se ha guardado en: " + fileToSave.getAbsolutePath());
        } else {
            System.out.println("La operación de guardado fue cancelada.");
        }
    }
}
   
