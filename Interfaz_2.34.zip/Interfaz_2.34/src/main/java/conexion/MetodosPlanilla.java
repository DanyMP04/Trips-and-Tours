/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author Danym
 */import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MetodosPlanilla {

    Connection con;
    conexion cn = new conexion();
    PreparedStatement ps;
    ResultSet rs;

        public List<Planilla> Listar() {
        List<Planilla> lista = new ArrayList<>();
        String sql = "SELECT * FROM worksheet";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Planilla au = new Planilla();
                au.setIdPaymentSheet(rs.getInt(1));
                au.setMonth(rs.getString(2));
                au.setYear(rs.getString(3));
                au.setIdEmployee(rs.getInt(4));
                au.setEmployeeName(rs.getString(5));
                au.setEmployeeLastName(rs.getString(6));
                au.setEarnedSalary(rs.getDouble(7));
                au.setDiscount(rs.getDouble(8));
                au.setSalaryTotal(rs.getDouble(9));
                lista.add(au);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    
}