/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author Danym
 */


public class Planilla {

    private int idPaymentSheet;
    private String month;
    private String year;
    private int idEmployee;
    private String employeeName;
    private String employeeLastName;
    private double earnedSalary;
    private double discount;
    private double salaryTotal;

    // Constructores
    public Planilla(){
    
    }
    
    public Planilla(int idPaymentSheet, String month, String year, int idEmployee, String employeeName,
                    String employeeLastName, double earnedSalary, double discount, double salaryTotal) {
        this.idPaymentSheet = idPaymentSheet;
        this.month = month;
        this.year = year;
        this.idEmployee = idEmployee;
        this.employeeName = employeeName;
        this.employeeLastName = employeeLastName;
        this.earnedSalary = earnedSalary;
        this.discount = discount;
        this.salaryTotal = salaryTotal;
    }

    // Getters and Setters
    public int getIdPaymentSheet() {
        return idPaymentSheet;
    }

    public void setIdPaymentSheet(int idPaymentSheet) {
        this.idPaymentSheet = idPaymentSheet;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeLastName() {
        return employeeLastName;
    }

    public void setEmployeeLastName(String employeeLastName) {
        this.employeeLastName = employeeLastName;
    }

    public double getEarnedSalary() {
        return earnedSalary;
    }

    public void setEarnedSalary(double earnedSalary) {
        this.earnedSalary = earnedSalary;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getSalaryTotal() {
        return salaryTotal;
    }

    public void setSalaryTotal(double salaryTotal) {
        this.salaryTotal = salaryTotal;
    }

    @Override
    public String toString() {
        return "Planilla{" +
                "idPaymentSheet=" + idPaymentSheet +
                ", month='" + month + '\'' +
                ", year='" + year + '\'' +
                ", idEmployee=" + idEmployee +
                ", employeeName='" + employeeName + '\'' +
                ", employeeLastName='" + employeeLastName + '\'' +
                ", earnedSalary=" + earnedSalary +
                ", discount=" + discount +
                ", salaryTotal=" + salaryTotal +
                '}';
    }
}
