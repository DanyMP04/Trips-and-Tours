/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author MINEDUCYT
 */
public class Boleta {
    private int idboleta;
    private int idEmpleado;
    private String IssueDate;
    private double EarnedSalary;
    private double Discount;
    private double SalaryTotal;

    public Boleta() {
    }

    public Boleta(int idboleta, int idEmpleado, String IssueDate, double EarnedSalary, double Discount, double SalaryTotal) {
        this.idboleta = idboleta;
        this.idEmpleado = idEmpleado;
        this.IssueDate = IssueDate;
        this.EarnedSalary = EarnedSalary;
        this.Discount = Discount;
        this.SalaryTotal = SalaryTotal;
    }

    public int getIdboleta() {
        return idboleta;
    }

    public void setIdboleta(int idboleta) {
        this.idboleta = idboleta;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getIssueDate() {
        return IssueDate;
    }

    public void setIssueDate(String IssueDate) {
        this.IssueDate = IssueDate;
    }

    public double getEarnedSalary() {
        return EarnedSalary;
    }

    public void setEarnedSalary(double EarnedSalary) {
        this.EarnedSalary = EarnedSalary;
    }

    public double getDiscount() {
        return Discount;
    }

    public void setDiscount(double Discount) {
        this.Discount = Discount;
    }

    public double getSalaryTotal() {
        return SalaryTotal;
    }

    public void setSalaryTotal(double SalaryTotal) {
        this.SalaryTotal = SalaryTotal;
    }
    
    
}
