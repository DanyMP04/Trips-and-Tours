/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author MINEDUCYT
 */
public class MetodosBoleta {
    
    Connection con;
    conexion cn = new conexion();
    PreparedStatement ps;
    ResultSet rs;
    
    public List Listar(){
        List<Boleta> lista = new ArrayList<>();
        String sql = "SELECT * FROM paymentsheet";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Boleta bol = new Boleta();
                bol.setIdboleta(rs.getInt(1));
                bol.setIdEmpleado(rs.getInt(2));
                bol.setEarnedSalary(rs.getDouble(3));
                bol.setDiscount(rs.getDouble(4));
                bol.setSalaryTotal(rs.getDouble(5));
                lista.add(bol);
            } 
        } catch (SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return lista;
    }
    
    public boolean guardar(Boleta bol){
        String sql = "INSERT INTO paymentsheet(IdPaymentsheet,IdEmployee,EarnedSalary,Discount,SalaryTotal) VALUES(?,?,?,?,?)";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, bol.getIdboleta());
            ps.setInt(2, bol.getIdEmpleado());
            ps.setDouble(3, bol.getEarnedSalary());
            ps.setDouble(4, bol.getDiscount());
            ps.setDouble(5, bol.getSalaryTotal());
            int n = ps.executeUpdate();
            if(n!=0){
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
    
}
