/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package principal;

import conexion.Boleta;
import conexion.MetodosBoleta;
import conexion.pdf;
import java.awt.Color;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author xyali
 */
public class panel_generar_boleta extends javax.swing.JPanel {

    private static final pdf PDF = new pdf();
    MetodosBoleta fu = new MetodosBoleta();
    private List<String> boleta;
    private panel_calculo_puntos instancia;
    public double descuentosTot;
    private double valorPuntos;
    private boolean shakeInProgress = false;
    private boolean primerError = true;
    public int puntosI;
    public int puntosN;
    public int puntosTot;
    public double salarioTot;
    public String Id;

    /**
     * Creates new form panel_generar_planilla
     */
    public panel_generar_boleta(panel_calculo_puntos instancia) {
        initComponents();
        this.instancia = instancia;
        hacerAlgo();
        CalcularSalario();
        establecerPeriodoDePago();
        agregarListeners();
        Id = instancia.getid();
        id.setText(Id);
        String nombreEmpleado = instancia.getNombre();
        Nombre.setText(nombreEmpleado);
        String ApellidoEmpleado = instancia.getApellido();
        Apellido.setText(ApellidoEmpleado);
    }

    private void agregarListeners() {
        OtrosDescuentos.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void removeUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void insertUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }
        });
    }

    private void shakeComponent(JComponent component) {
        if (shakeInProgress) {
            return;
        }

        shakeInProgress = true;
        final int originalX = component.getLocation().x;
        final int originalY = component.getLocation().y;

        final int shakeDistance = 3;
        final int shakeDuration = 30;
        final int shakeCount = 3;

        new Thread(() -> {
            try {
                for (int i = 0; i < shakeCount; i++) {
                    // Movimiento hacia la izquierda
                    SwingUtilities.invokeLater(() -> component.setLocation(originalX - shakeDistance, originalY));
                    Thread.sleep(shakeDuration);
                    // Movimiento hacia la derecha
                    SwingUtilities.invokeLater(() -> component.setLocation(originalX + shakeDistance, originalY));
                    Thread.sleep(shakeDuration);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                // Restaurar la posición original
                SwingUtilities.invokeLater(() -> component.setLocation(originalX, originalY));
                shakeInProgress = false;
            }
        }).start();
    }

    private void actualizarSalarioTotal() {
        try {
            String textoDescuento = OtrosDescuentos.getText();
            double porcentajeDescuento = 0.0;
            if (!textoDescuento.isEmpty()) {
                porcentajeDescuento = Double.parseDouble(textoDescuento);
                if (porcentajeDescuento < 0 || porcentajeDescuento > 100) {
                    throw new NumberFormatException("Porcentaje de descuento inválido");
                }
            }
            OtrosDescuentos.setBackground(Color.WHITE);
            primerError = true;
            CalcularSalario();
        } catch (NumberFormatException e) {
            SalarioTotal.setText("Error");
            if (primerError) {
                shakeComponent(OtrosDescuentos);
                OtrosDescuentos.setBackground(Color.PINK);
                primerError = false;
            }
        }
    }

    private String obtenerUltimoDiaDelMes() {
        LocalDate fechaActual = LocalDate.now();
        int ultimoDia = fechaActual.lengthOfMonth();
        LocalDate ultimoDiaDelMes = LocalDate.of(fechaActual.getYear(), fechaActual.getMonth(), ultimoDia);
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return ultimoDiaDelMes.format(formato);
    }

    private void establecerPeriodoDePago() {
        LocalDate fechaActual = LocalDate.now();
        LocalDate inicioPeriodo = fechaActual.withDayOfMonth(1);
        LocalDate finPeriodo = fechaActual.withDayOfMonth(fechaActual.lengthOfMonth());
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String periodoDePago = inicioPeriodo.format(formato) + " - " + finPeriodo.format(formato);
        PeriodoPago.setText(periodoDePago);
    }

    public class ResultadoCalculo {

        private double salarioTotal;
        private double renta;

        public ResultadoCalculo(double salarioTotal, double renta) {
            this.salarioTotal = salarioTotal;
            this.renta = renta;
        }

        public double getSalarioTotal() {
            return salarioTotal;
        }

        public double getRenta() {
            return renta;
        }
    }

    public ResultadoCalculo calcularTramo(double SalarioDevengado, double sala_sub) {
        double renta = 0;
        double sala_tot = 0;

        if (SalarioDevengado >= 0.01 && SalarioDevengado <= 472.00) {
            sala_tot = sala_sub;
        } else if (SalarioDevengado >= 472.01 && SalarioDevengado <= 895.24) {
            renta = (sala_sub - 472.00) * 0.10 + 17.67;
            sala_tot = sala_sub - renta;
        } else if (SalarioDevengado >= 895.25 && SalarioDevengado <= 2038.10) {
            renta = (sala_sub - 895.24) * 0.20 + 60.00;
            sala_tot = sala_sub - renta;
        } else if (SalarioDevengado >= 2038.11) {
            renta = (sala_sub - 2038.10) * 0.30 + 288.57;
            sala_tot = sala_sub - renta;
        }

        return new ResultadoCalculo(sala_tot, renta);
    }

    public double calcularValorPuntos(int puntosTotales, int puntosNacionales, int puntosInternacionales) {
        double valorPorPuntoNacional = 0.35;
        double valorPorPuntoInternacional = 0.10;

        double valorTotal = (puntosNacionales * valorPorPuntoNacional) + (puntosInternacionales * valorPorPuntoInternacional);

        return valorTotal;
    }

    public void CalcularSalario() {
        puntosN = instancia.getTotalPuntosN();
        puntosI = instancia.getTotalPuntosI();
        puntosTot = puntosI + puntosN;

        valorPuntos = calcularValorPuntos(puntosTot, puntosN, puntosI);
        double salarioBase = 365; // salario mínimo de base
        double SalarioDevengado = salarioBase;
        if (puntosTot <= 525) {
            SalarioDevengado = salarioBase;
        } else if (puntosTot > 525 && puntosTot <= 2500) {
            SalarioDevengado = salarioBase + valorPuntos;
        } else if (puntosTot > 2500) {
            SalarioDevengado = salarioBase + valorPuntos;
        }

        double isss = SalarioDevengado * 0.03;
        double afp = SalarioDevengado * 0.0725;
        double SalarioSubtotal = SalarioDevengado - isss - afp;
        Salariosubtotal.setText(String.format("%.2f", SalarioSubtotal));

        double porcentajeDescuento = 0.0;
        String textoDescuento = OtrosDescuentos.getText();
        if (!textoDescuento.isEmpty()) {
            try {
                porcentajeDescuento = Double.parseDouble(textoDescuento);
                OtrosDescuentos.setBackground(Color.WHITE);
                primerError = true;
            } catch (NumberFormatException e) {
                porcentajeDescuento = 0.0;
                OtrosDescuentos.setBackground(Color.PINK);
                primerError = false;
            }
        }
        double descuentoAdicional = SalarioSubtotal * (porcentajeDescuento / 100);
        SalarioSubtotal -= descuentoAdicional;
        

        ResultadoCalculo resultado = calcularTramo(SalarioDevengado, SalarioSubtotal);
        Descuento.setText(String.format("%.2f", descuentoAdicional));
        Salariodevengado.setText(String.format("%.2f", SalarioDevengado));
        ISSS.setText(String.format("%.2f", isss));
        AFP.setText(String.format("%.2f", afp));
        Renta.setText(String.format("%.2f", resultado.getRenta()));
        SalarioTotal.setText(String.format("%.2f", resultado.getSalarioTotal()));
        salarioTot = Double.parseDouble(String.format("%.2f", resultado.getSalarioTotal()));
        double renta = Double.parseDouble(String.format("%.2f", resultado.getRenta()));
        descuentosTot = isss + afp + renta + descuentoAdicional;
    }

    public void hacerAlgo() {
        int numero = (int) (Math.random() * 900000) + 100000;
        Codigo.setText(String.valueOf(numero));
        fechaMes.setText(obtenerUltimoDiaDelMes());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        txt_nombe = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        Codigo = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        Apellido = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jSeparator9 = new javax.swing.JSeparator();
        id = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        PeriodoPago = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        descuento = new javax.swing.JComboBox<>();
        jSeparator11 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        fechaMes = new javax.swing.JLabel();
        Salariodevengado = new javax.swing.JLabel();
        ISSS = new javax.swing.JLabel();
        AFP = new javax.swing.JLabel();
        Renta = new javax.swing.JLabel();
        Salariosubtotal = new javax.swing.JLabel();
        OtrosDescuentos = new javax.swing.JTextField();
        Descuento = new javax.swing.JLabel();
        SalarioTotal = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        exportar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setMinimumSize(new java.awt.Dimension(1000, 540));
        setPreferredSize(new java.awt.Dimension(1000, 540));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fondo.setBackground(new java.awt.Color(235, 235, 235));
        fondo.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        fondo.setPreferredSize(new java.awt.Dimension(1000, 540));

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel1.setText("Generar boleta");

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_nombe.setText("Nombre:");
        jPanel1.add(txt_nombe, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        jLabel2.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        jLabel2.setText("Descuentos");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 10, -1, -1));

        jLabel3.setText("Apellido:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel4.setText("Código de boleta:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(264, 20, 10, 340));

        jLabel5.setText("AFP");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 120, -1, -1));

        jLabel6.setText("ISS");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 80, -1, -1));

        jLabel7.setText("Renta");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 160, -1, -1));

        jLabel9.setText("Salario devengado");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 40, -1, -1));

        jLabel10.setText("Salario subtotal");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 200, -1, -1));

        jLabel11.setText("Salario total");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 350, -1, -1));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 220, 10));
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 100, 220, 10));
        jPanel1.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 140, 220, 10));
        jPanel1.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 180, 220, 10));
        jPanel1.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 220, 220, 10));
        jPanel1.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 340, 220, 10));

        Codigo.setText("10010101");
        jPanel1.add(Codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, -1, -1));

        Nombre.setText("Oni chan");
        jPanel1.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, -1, -1));

        Apellido.setText("Daski");
        jPanel1.add(Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 120, -1, -1));

        jLabel22.setText("ID:");
        jPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));
        jPanel1.add(jSeparator9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 240, 20));

        id.setText("101010101");
        jPanel1.add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, 60, -1));

        jLabel24.setText("Empresa:");
        jPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));
        jPanel1.add(jSeparator10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 230, 10));

        jLabel25.setText("Trips and Tours");
        jPanel1.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, -1, -1));

        jLabel26.setText("Periodo de pago:");
        jPanel1.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, -1, -1));

        PeriodoPago.setText("56 /12/5067 - 89/45/5067");
        jPanel1.add(PeriodoPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 210, 140, -1));

        jLabel28.setText("Fecha emisión:");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, -1));

        descuento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Manutención Infantil y Pensión Alimenticia", "Deudas Tributarias", "Embargo de Salario por Deuda", "Multas o Sanciones Judiciales", "Reparaciones Civiles", "Retenciones Judiciales por Fraude o Estafa", "Gastos de Procedimientos Médicos Ordenados Judicialmente", "Reintegros por Dañar Propiedad de la Empresa", "Retenciones por Deudas con Instituciones Educativas", "Costos Legales y de Representación" }));
        jPanel1.add(descuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 310, 150, 20));
        jPanel1.add(jSeparator11, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 300, 220, 10));

        jLabel8.setText("Otros descuento");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 240, -1, 20));

        jLabel30.setText("Porcentaje a aplicar");
        jPanel1.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, -1, -1));

        fechaMes.setText("32/46/5067");
        jPanel1.add(fechaMes, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 250, 60, -1));

        Salariodevengado.setText("$$$.$$");
        jPanel1.add(Salariodevengado, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 40, -1, -1));

        ISSS.setText("$$$.$$");
        jPanel1.add(ISSS, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 80, -1, -1));

        AFP.setText("$$$.$$");
        jPanel1.add(AFP, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 120, -1, -1));

        Renta.setText("$$$.$$");
        jPanel1.add(Renta, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 160, -1, -1));

        Salariosubtotal.setText("$$$.$$");
        jPanel1.add(Salariosubtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 200, -1, -1));
        jPanel1.add(OtrosDescuentos, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 270, 70, -1));

        Descuento.setText("$$$.$$");
        jPanel1.add(Descuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 310, -1, -1));

        SalarioTotal.setText("$$$.$$");
        jPanel1.add(SalarioTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 350, -1, -1));

        exportar.setText("Exportar en PDF");
        exportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportarActionPerformed(evt);
            }
        });

        jButton1.setText("Guardar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout fondoLayout = new javax.swing.GroupLayout(fondo);
        fondo.setLayout(fondoLayout);
        fondoLayout.setHorizontalGroup(
            fondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoLayout.createSequentialGroup()
                .addContainerGap(57, Short.MAX_VALUE)
                .addGroup(fondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondoLayout.createSequentialGroup()
                        .addGroup(fondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 903, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 813, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(fondoLayout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addGap(29, 29, 29)
                                .addComponent(exportar)))
                        .addGap(38, 38, 38))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondoLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(359, 359, 359))))
        );
        fondoLayout.setVerticalGroup(
            fondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondoLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(fondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exportar)
                    .addComponent(jButton1))
                .addContainerGap())
        );

        add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 540));
    }// </editor-fold>//GEN-END:initComponents

    private void exportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportarActionPerformed
        exportar.setEnabled(false);

        String nombreEmpleado = Nombre.getText();
        String idEmpleado = id.getText();
        String posicion = "Vendedor";
        String fechaPago = fechaMes.getText();
        double salarioBase = 365;
        double bonificaciones = calcularValorPuntos(puntosTot, puntosN, puntosI);
        double total = Double.parseDouble(SalarioTotal.getText());
        if (puntosTot <= 525) {
            PDF.convertHtmlToPdf(nombreEmpleado, idEmpleado, posicion, fechaPago, salarioBase, 0, descuentosTot, total);
        } else if (puntosTot > 525) {
            PDF.convertHtmlToPdf(nombreEmpleado, idEmpleado, posicion, fechaPago, salarioBase, bonificaciones, descuentosTot, total);
        }
        exportar.setEnabled(true);
    }//GEN-LAST:event_exportarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        double salariob = 365;
        int numero = Integer.parseInt(Id);
        Boleta bol = new Boleta();
        bol.setIdEmpleado(numero);
        bol.setEarnedSalary(salariob);
        bol.setDiscount(descuentosTot);
        bol.setSalaryTotal(salarioTot);
        if (fu.guardar(bol)) {
            JOptionPane.showMessageDialog(this, "Registrado con éxito");
            boleta = fu.Listar();
        } else {
            JOptionPane.showMessageDialog(this, "Error al guardar");
        }
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AFP;
    private javax.swing.JLabel Apellido;
    private javax.swing.JLabel Codigo;
    private javax.swing.JLabel Descuento;
    private javax.swing.JLabel ISSS;
    private javax.swing.JLabel Nombre;
    private javax.swing.JTextField OtrosDescuentos;
    private javax.swing.JLabel PeriodoPago;
    private javax.swing.JLabel Renta;
    private javax.swing.JLabel SalarioTotal;
    private javax.swing.JLabel Salariodevengado;
    private javax.swing.JLabel Salariosubtotal;
    private javax.swing.JComboBox<String> descuento;
    private javax.swing.JButton exportar;
    private javax.swing.JLabel fechaMes;
    private javax.swing.JPanel fondo;
    private javax.swing.JLabel id;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JLabel txt_nombe;
    // End of variables declaration//GEN-END:variables
}
