/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package principal;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author xyali
 */
public class inicio_menu extends javax.swing.JPanel {

    /**
     * Creates new form inicio_menu_bienvenida
     */
    public inicio_menu() {
        initComponents();
        mostrarFechaYHora();
    }

    private void mostrarFechaYHora() {
        Timer timer = new Timer(1000, e -> {
            SimpleDateFormat formatoFechaHora = new SimpleDateFormat("EEEE dd 'de' MMMM 'de' yyyy HH:mm:ss");
            String fechaHoraActual = formatoFechaHora.format(new Date());
            lblHora.setText(fechaHoraActual);
        });
        timer.start();
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        inicio = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblHora = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(1000, 540));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        inicio.setBackground(new java.awt.Color(235, 235, 235));
        inicio.setMinimumSize(new java.awt.Dimension(1000, 540));
        inicio.setPreferredSize(new java.awt.Dimension(1000, 540));
        inicio.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 36)); // NOI18N
        jLabel1.setText("Bienvenido");
        inicio.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, -1, -1));

        jLabel4.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        jLabel4.setText("TRIPS & TOURS ");
        inicio.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 130, -1, -1));

        lblHora.setFont(new java.awt.Font("MS Gothic", 1, 14)); // NOI18N
        inicio.add(lblHora, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 510, 280, 20));

        add(inicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 540));
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel inicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lblHora;
    // End of variables declaration//GEN-END:variables
}
