/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Principal;

import com.formdev.flatlaf.FlatClientProperties;
import conexion.Boleta;
import conexion.EmailSender;
import conexion.Empleados;
import conexion.MetodosBoleta;
import conexion.MetodosEmpleado;
import conexion.pdf;
import java.awt.BorderLayout;
import java.awt.Color;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author xyali
 */
public class panel_generar_boleta extends javax.swing.JPanel {

    private static final pdf PDF = new pdf();
    private static final EmailSender Correo = new EmailSender();
    MetodosEmpleado fu = new MetodosEmpleado();
    MetodosBoleta fua = new MetodosBoleta();
    private Map<String, panel_calculo_puntos.EmpleadoInfo> empleadosMap = new HashMap<>();
    private List<Empleados> empleados;
    private List<String> boleta;
    private panel_calculo_puntos instancia;
    public double descuentosTot;
    private double valorPuntos;
    private boolean shakeInProgress = false;
    private boolean primerError = true;
    public int puntosI;
    public int puntosN;
    public int puntosTot;
    public double salarioTot;
    public String nombre;
    public String IdEmpleado;

    /**
     * Creates new form panel_generar_boleta
     */
    public panel_generar_boleta(panel_calculo_puntos instancia, List<Empleados> empleados, Map<String, panel_calculo_puntos.EmpleadoInfo> empleadosMap) {
        initComponents();
        InitStyles();
        this.instancia = instancia;
        this.empleados = empleados;
        this.empleadosMap = empleadosMap;
        hacerAlgo();
        CalcularSalario();
        establecerPeriodoDePago();
        agregarListeners();
        agregarListeners1();
        agregarListeners2();
        mostrarInformacionEmpleado();
    }

    private void InitStyles() {
        OtrosDescuentos2.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        descuento1.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        exportar.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        exportar17.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
    }

    public void mostrarInformacionEmpleado() {
        panel_calculo_puntos.EmpleadoInfo info = instancia.getEmpleadoInfoSeleccionado();
        if (info != null) {
            int id = info.getId();
            nombre = info.getNombre();
            String apellido = info.getApellido();
            IdEmpleado = Integer.toString(id);
            identificador.setText(IdEmpleado);
            Nombre.setText(nombre);
            Apellido.setText(apellido);
            String fechaPago = fechaMes.getText();
            Codigo.setText("Boleta_" + IdEmpleado + "_" + nombre.replace(" ", "_") + "_" + fechaPago);
        } else {
            System.out.println("No se ha seleccionado ningún empleado.");
        }
    }

    private void agregarListeners() {
        OtrosDescuentos.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void removeUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void insertUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }
        });
    }

    private void agregarListeners1() {
        OtrosDescuentos1.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void removeUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void insertUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }
        });
    }

    private void agregarListeners2() {
        OtrosDescuentos2.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void removeUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void insertUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }
        });
    }

    private void shakeComponent(JComponent component) {
        if (shakeInProgress) {
            return;
        }

        shakeInProgress = true;
        final int originalX = component.getLocation().x;
        final int originalY = component.getLocation().y;

        final int shakeDistance = 3;
        final int shakeDuration = 30;
        final int shakeCount = 3;

        new Thread(() -> {
            try {
                for (int i = 0; i < shakeCount; i++) {
                    // Movimiento hacia la izquierda
                    SwingUtilities.invokeLater(() -> component.setLocation(originalX - shakeDistance, originalY));
                    Thread.sleep(shakeDuration);
                    // Movimiento hacia la derecha
                    SwingUtilities.invokeLater(() -> component.setLocation(originalX + shakeDistance, originalY));
                    Thread.sleep(shakeDuration);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                // Restaurar la posición original
                SwingUtilities.invokeLater(() -> component.setLocation(originalX, originalY));
                shakeInProgress = false;
            }
        }).start();
    }

    private void actualizarSalarioTotal() {
        // Variables de descuento
        String textoDescuento = OtrosDescuentos2.getText();
        String textoDescuento1 = OtrosDescuentos1.getText();
        String textoDescuento2 = OtrosDescuentos1.getText();
        double porcentajeDescuento = 0.0;
        double porcentajeDescuento1 = 0.0;
        double porcentajeDescuento2 = 0.0;
        boolean primerError = true;

        try {
            // Validar y convertir el primer descuento
            if (!textoDescuento.isEmpty()) {
                porcentajeDescuento = Double.parseDouble(textoDescuento);
                if (porcentajeDescuento < 0 || porcentajeDescuento > 100) {
                    throw new NumberFormatException("Porcentaje de descuento inválido");
                }
            }
            OtrosDescuentos.setBackground(Color.WHITE); // Resetea el color de fondo en caso de éxito
        } catch (NumberFormatException e) {
            OtrosDescuentos.setBackground(Color.PINK); // Marca el campo con un color de error
            primerError = false;
            JOptionPane.showMessageDialog(this, "El valor del primer descuento no es válido. Debe ser un número entre 0 y 100.");
        }

// Validar y convertir el segundo descuento
        try {
            if (!textoDescuento1.isEmpty()) {
                porcentajeDescuento1 = Double.parseDouble(textoDescuento1);
                if (porcentajeDescuento1 < 0 || porcentajeDescuento1 > 100) {
                    throw new NumberFormatException("Porcentaje de descuento inválido");
                }
            }
            OtrosDescuentos1.setBackground(Color.WHITE); // Resetea el color de fondo en caso de éxito
        } catch (NumberFormatException e) {
            OtrosDescuentos1.setBackground(Color.PINK); // Marca el campo con un color de error
            primerError = false;
            JOptionPane.showMessageDialog(this, "El valor del segundo descuento no es válido. Debe ser un número entre 0 y 100.");
        }

        try {
            // Validar y convertir el primer descuento
            if (!textoDescuento2.isEmpty()) {
                porcentajeDescuento2 = Double.parseDouble(textoDescuento2);
                if (porcentajeDescuento < 0 || porcentajeDescuento > 100) {
                    throw new NumberFormatException("Porcentaje de descuento inválido");
                }
            }
            OtrosDescuentos2.setBackground(Color.WHITE); // Resetea el color de fondo en caso de éxito
        } catch (NumberFormatException e) {
            OtrosDescuentos2.setBackground(Color.PINK); // Marca el campo con un color de error
            primerError = false;
            JOptionPane.showMessageDialog(this, "El valor del primer descuento no es válido. Debe ser un número entre 0 y 100.");
        }

// Comprobar si hay errores antes de calcular el salario
        if (primerError) {
            CalcularSalario();
        } else {
            SalarioTotal.setText("Error");
            shakeComponent(OtrosDescuentos);
            shakeComponent(OtrosDescuentos1);
            shakeComponent(OtrosDescuentos2);
        }

    }

    public String obtenerDiaDelMes() {
        LocalDate fechaActual = LocalDate.now();
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return fechaActual.format(formato);
    }

    private void establecerPeriodoDePago() {
        LocalDate fechaActual = LocalDate.now();
        LocalDate inicioPeriodo = fechaActual.withDayOfMonth(1);
        LocalDate finPeriodo = fechaActual.withDayOfMonth(fechaActual.lengthOfMonth());
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String periodoDePago = inicioPeriodo.format(formato) + " - " + finPeriodo.format(formato);
        PeriodoPago.setText(periodoDePago);
    }

    public class ResultadoCalculo {

        private double salarioTotal;
        private double renta;

        public ResultadoCalculo(double salarioTotal, double renta) {
            this.salarioTotal = salarioTotal;
            this.renta = renta;
        }

        public double getSalarioTotal() {
            return salarioTotal;
        }

        public double getRenta() {
            return renta;
        }
    }

    public ResultadoCalculo calcularTramo(double SalarioDevengado, double sala_sub) {
        double renta = 0;
        double sala_tot = 0;

        if (SalarioDevengado >= 0.01 && SalarioDevengado <= 472.00) {
            sala_tot = sala_sub;
        } else if (SalarioDevengado >= 472.01 && SalarioDevengado <= 895.24) {
            renta = (sala_sub - 472.00) * 0.10 + 17.67;
            sala_tot = sala_sub - renta;
        } else if (SalarioDevengado >= 895.25 && SalarioDevengado <= 2038.10) {
            renta = (sala_sub - 895.24) * 0.20 + 60.00;
            sala_tot = sala_sub - renta;
        } else if (SalarioDevengado >= 2038.11) {
            renta = (sala_sub - 2038.10) * 0.30 + 288.57;
            sala_tot = sala_sub - renta;
        }

        return new ResultadoCalculo(sala_tot, renta);
    }

    public double calcularValorPuntos(int puntosTotales, int puntosNacionales, int puntosInternacionales) {
        double valorPorPuntoNacional = 0.35;
        double valorPorPuntoInternacional = 0.10;

        double valorTotal = (puntosNacionales * valorPorPuntoNacional) + (puntosInternacionales * valorPorPuntoInternacional);

        return valorTotal;
    }

    public void CalcularSalario() {
        puntosN = instancia.getTotalPuntosN();
        puntosI = instancia.getTotalPuntosI();
        puntosTot = puntosI + puntosN;

        valorPuntos = calcularValorPuntos(puntosTot, puntosN, puntosI);
        double salarioBase = 365; // salario mínimo de base
        double SalarioDevengado = salarioBase;
        if (puntosTot <= 525) {
            SalarioDevengado = salarioBase;
        } else if (puntosTot > 525 && puntosTot <= 2500) {
            SalarioDevengado = salarioBase + valorPuntos;
        } else if (puntosTot > 2500) {
            SalarioDevengado = salarioBase + valorPuntos;
        }

        double isss = SalarioDevengado * 0.03;
        double afp = SalarioDevengado * 0.0725;
        double SalarioSubtotal = SalarioDevengado - isss - afp;
        Salariosubtotal.setText(String.format("%.2f", SalarioSubtotal));

        double porcentajeDescuento = 0.0;
        double porcentajeDescuento1 =0.0;
        double porcentajeDescuento2 = 0.0;
        String textoDescuento = OtrosDescuentos.getText();
        String textoDescuento1 = OtrosDescuentos1.getText();
        String textoDescuento2 = OtrosDescuentos2.getText();
        boolean errorEncontrado = false;

        // Validar y convertir el primer descuento
        if (!textoDescuento.isEmpty()) {
            try {
                porcentajeDescuento = Double.parseDouble(textoDescuento);
                if (porcentajeDescuento < 0 || porcentajeDescuento > 100) {
                    throw new NumberFormatException("Porcentaje de descuento inválido");
                }
                OtrosDescuentos.setBackground(Color.WHITE);
            } catch (NumberFormatException e) {
                porcentajeDescuento = 0.0;
                OtrosDescuentos.setBackground(Color.PINK);
                errorEncontrado = true;
            }
        }

        // Validar y convertir el segundo descuento
        if (!textoDescuento1.isEmpty()) {
            try {
                porcentajeDescuento1 = Double.parseDouble(textoDescuento1);
                if (porcentajeDescuento1 < 0 || porcentajeDescuento1 > 100) {
                    throw new NumberFormatException("Porcentaje de descuento inválido");
                }
                OtrosDescuentos1.setBackground(Color.WHITE);
            } catch (NumberFormatException e) {
                porcentajeDescuento1 = 0.0;
                OtrosDescuentos1.setBackground(Color.PINK);
                errorEncontrado = true;
            }
        }

        if (!textoDescuento2.isEmpty()) {
            try {
                porcentajeDescuento2 = Double.parseDouble(textoDescuento2);
                if (porcentajeDescuento2 < 0 || porcentajeDescuento2 > 100) {
                    throw new NumberFormatException("Porcentaje de descuento inválido");
                }
                OtrosDescuentos2.setBackground(Color.WHITE);
            } catch (NumberFormatException e) {
                porcentajeDescuento1 = 0.0;
                OtrosDescuentos2.setBackground(Color.PINK);
                errorEncontrado = true;
            }
        }

        // Comprobar si hubo errores antes de continuar con el cálculo
        if (errorEncontrado) {
            SalarioTotal.setText("Error");
            shakeComponent(OtrosDescuentos);
            shakeComponent(OtrosDescuentos1);
            shakeComponent(OtrosDescuentos2);
            return; // Salir del método si hay errores
        }

        double descuentoAdicional = SalarioSubtotal * (porcentajeDescuento / 100);
        SalarioSubtotal -= descuentoAdicional;
        double descuentoAdicional1 = SalarioSubtotal * (porcentajeDescuento1 / 100);
        SalarioSubtotal -= descuentoAdicional1;
        double descuentoAdicional2 = SalarioSubtotal * (porcentajeDescuento2 / 100);
        SalarioSubtotal -= descuentoAdicional2;
        double totalDescuento = descuentoAdicional + descuentoAdicional1 + descuentoAdicional2;
        ResultadoCalculo resultado = calcularTramo(SalarioDevengado, SalarioSubtotal);
        Descuento.setText(String.format("%.2f", totalDescuento));
        Salariodevengado.setText(String.format("%.2f", SalarioDevengado));
        ISSS.setText(String.format("%.2f", isss));
        AFP.setText(String.format("%.2f", afp));
        Renta.setText(String.format("%.2f", resultado.getRenta()));
        SalarioTotal.setText(String.format("%.2f", resultado.getSalarioTotal()));
        salarioTot = Double.parseDouble(String.format("%.2f", resultado.getSalarioTotal()));
        double renta = Double.parseDouble(String.format("%.2f", resultado.getRenta()));
        descuentosTot = isss + afp + renta + descuentoAdicional;
    }

    public void hacerAlgo() {
        fechaMes.setText(obtenerDiaDelMes());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        fondo_interno_generar_boleta = new javax.swing.JPanel();
        Renta = new javax.swing.JLabel();
        AFP = new javax.swing.JLabel();
        jLabel289 = new javax.swing.JLabel();
        Codigo = new javax.swing.JLabel();
        ISSS = new javax.swing.JLabel();
        exportar = new javax.swing.JButton();
        jSeparator150 = new javax.swing.JSeparator();
        jLabel290 = new javax.swing.JLabel();
        jLabel291 = new javax.swing.JLabel();
        jLabel292 = new javax.swing.JLabel();
        jSeparator151 = new javax.swing.JSeparator();
        jLabel293 = new javax.swing.JLabel();
        jLabel294 = new javax.swing.JLabel();
        jLabel295 = new javax.swing.JLabel();
        identificador = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        Apellido = new javax.swing.JLabel();
        jLabel296 = new javax.swing.JLabel();
        PeriodoPago = new javax.swing.JLabel();
        fechaMes = new javax.swing.JLabel();
        jSeparator152 = new javax.swing.JSeparator();
        jLabel297 = new javax.swing.JLabel();
        jLabel298 = new javax.swing.JLabel();
        Salariodevengado = new javax.swing.JLabel();
        jSeparator153 = new javax.swing.JSeparator();
        jLabel299 = new javax.swing.JLabel();
        jSeparator154 = new javax.swing.JSeparator();
        jLabel300 = new javax.swing.JLabel();
        jSeparator155 = new javax.swing.JSeparator();
        jLabel301 = new javax.swing.JLabel();
        jSeparator156 = new javax.swing.JSeparator();
        jLabel302 = new javax.swing.JLabel();
        jSeparator157 = new javax.swing.JSeparator();
        jLabel303 = new javax.swing.JLabel();
        jLabel304 = new javax.swing.JLabel();
        OtrosDescuentos2 = new javax.swing.JTextField();
        jLabel305 = new javax.swing.JLabel();
        descuento1 = new javax.swing.JComboBox<>();
        Descuento = new javax.swing.JLabel();
        jSeparator158 = new javax.swing.JSeparator();
        jLabel306 = new javax.swing.JLabel();
        SalarioTotal = new javax.swing.JLabel();
        Salariosubtotal = new javax.swing.JLabel();
        atras = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        OtrosDescuentos1 = new javax.swing.JTextField();
        OtrosDescuentos = new javax.swing.JTextField();
        descuento = new javax.swing.JComboBox<>();
        descuento2 = new javax.swing.JComboBox<>();
        exportar17 = new javax.swing.JButton();

        Renta.setForeground(new java.awt.Color(0, 0, 0));
        Renta.setText("$$$.$$");

        AFP.setForeground(new java.awt.Color(0, 0, 0));
        AFP.setText("$$$.$$");

        jLabel289.setForeground(new java.awt.Color(0, 0, 0));
        jLabel289.setText("Código de boleta");

        Codigo.setForeground(new java.awt.Color(0, 0, 0));
        Codigo.setText("019201");

        ISSS.setForeground(new java.awt.Color(0, 0, 0));
        ISSS.setText("$$$.$$");

        exportar.setBackground(new java.awt.Color(204, 204, 204));
        exportar.setForeground(new java.awt.Color(0, 0, 0));
        exportar.setText("Exportar");
        exportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportarexportarActionPerformed(evt);
            }
        });

        jLabel290.setForeground(new java.awt.Color(0, 0, 0));
        jLabel290.setText("ID");

        jLabel291.setForeground(new java.awt.Color(0, 0, 0));
        jLabel291.setText("Nombre");

        jLabel292.setForeground(new java.awt.Color(0, 0, 0));
        jLabel292.setText("Apellido");

        jLabel293.setForeground(new java.awt.Color(0, 0, 0));
        jLabel293.setText("Empresa");

        jLabel294.setForeground(new java.awt.Color(0, 0, 0));
        jLabel294.setText("Periodo de pago");

        jLabel295.setForeground(new java.awt.Color(0, 0, 0));
        jLabel295.setText("Fecha emisión");

        identificador.setForeground(new java.awt.Color(0, 0, 0));
        identificador.setText("19382");

        Nombre.setForeground(new java.awt.Color(0, 0, 0));
        Nombre.setText("Susana");

        Apellido.setForeground(new java.awt.Color(0, 0, 0));
        Apellido.setText("Oria");

        jLabel296.setForeground(new java.awt.Color(0, 0, 0));
        jLabel296.setText("TRIPS & TOURS ");

        PeriodoPago.setForeground(new java.awt.Color(0, 0, 0));
        PeriodoPago.setText("23/04/2024 - 30/07/2024");

        fechaMes.setForeground(new java.awt.Color(0, 0, 0));
        fechaMes.setText("28/08/2024");

        jSeparator152.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel297.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel297.setForeground(new java.awt.Color(0, 0, 0));
        jLabel297.setText("DESCUENTOS");

        jLabel298.setForeground(new java.awt.Color(0, 0, 0));
        jLabel298.setText("Salario devengado");

        Salariodevengado.setForeground(new java.awt.Color(0, 0, 0));
        Salariodevengado.setText("$$$.$$");

        jLabel299.setForeground(new java.awt.Color(0, 0, 0));
        jLabel299.setText("ISSS");

        jLabel300.setForeground(new java.awt.Color(0, 0, 0));
        jLabel300.setText("AFP");

        jLabel301.setForeground(new java.awt.Color(0, 0, 0));
        jLabel301.setText("Renta");

        jLabel302.setForeground(new java.awt.Color(0, 0, 0));
        jLabel302.setText("Salario subtotal");

        jLabel303.setForeground(new java.awt.Color(0, 0, 0));
        jLabel303.setText("Otros descuentos");

        jLabel304.setForeground(new java.awt.Color(0, 0, 0));
        jLabel304.setText("Porcentaje en aplicar");

        OtrosDescuentos2.setBackground(new java.awt.Color(204, 204, 204));
        OtrosDescuentos2.setForeground(new java.awt.Color(0, 0, 0));

        jLabel305.setForeground(new java.awt.Color(0, 0, 0));
        jLabel305.setText("%");

        descuento1.setBackground(new java.awt.Color(204, 204, 204));
        descuento1.setForeground(new java.awt.Color(0, 0, 0));
        descuento1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Banco Agrícola, S.A.", "Banco Cuscatlán de El Salvador, S.A.", "Banco Davivienda Salvadoreño, S.A.", "Banco Promérica, S.A.", "Banco de América Central, S.A.", "Banco Atlántida El Salvador, S.A.", "Banco ABANK, S.A.", "Banco Industrial El Salvador, S.A.", "Banco Azul de El Salvador, S.A.", " " }));

        Descuento.setForeground(new java.awt.Color(0, 0, 0));
        Descuento.setText("$$$.$$");

        jLabel306.setForeground(new java.awt.Color(0, 0, 0));
        jLabel306.setText("Salario total");

        SalarioTotal.setForeground(new java.awt.Color(0, 0, 0));
        SalarioTotal.setText("$$$.$$");

        Salariosubtotal.setForeground(new java.awt.Color(0, 0, 0));
        Salariosubtotal.setText("$$$.$$");

        atras.setBackground(new java.awt.Color(204, 204, 204));
        atras.setForeground(new java.awt.Color(0, 0, 0));
        atras.setText("Atrás");
        atras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atrasActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Boleta");

        OtrosDescuentos1.setBackground(new java.awt.Color(204, 204, 204));
        OtrosDescuentos1.setForeground(new java.awt.Color(0, 0, 0));

        OtrosDescuentos.setBackground(new java.awt.Color(204, 204, 204));
        OtrosDescuentos.setForeground(new java.awt.Color(0, 0, 0));

        descuento.setBackground(new java.awt.Color(204, 204, 204));
        descuento.setForeground(new java.awt.Color(0, 0, 0));
        descuento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Banco Agrícola, S.A.", "Banco Cuscatlán de El Salvador, S.A.", "Banco Davivienda Salvadoreño, S.A.", "Banco Promérica, S.A.", "Banco de América Central, S.A.", "Banco Atlántida El Salvador, S.A.", "Banco ABANK, S.A.", "Banco Industrial El Salvador, S.A.", "Banco Azul de El Salvador, S.A.", " " }));

        descuento2.setBackground(new java.awt.Color(204, 204, 204));
        descuento2.setForeground(new java.awt.Color(0, 0, 0));
        descuento2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Banco Agrícola, S.A.", "Banco Cuscatlán de El Salvador, S.A.", "Banco Davivienda Salvadoreño, S.A.", "Banco Promérica, S.A.", "Banco de América Central, S.A.", "Banco Atlántida El Salvador, S.A.", "Banco ABANK, S.A.", "Banco Industrial El Salvador, S.A.", "Banco Azul de El Salvador, S.A.", " " }));

        exportar17.setBackground(new java.awt.Color(204, 204, 204));
        exportar17.setForeground(new java.awt.Color(0, 0, 0));
        exportar17.setText("Guardar");
        exportar17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportar17ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout fondo_interno_generar_boletaLayout = new javax.swing.GroupLayout(fondo_interno_generar_boleta);
        fondo_interno_generar_boleta.setLayout(fondo_interno_generar_boletaLayout);
        fondo_interno_generar_boletaLayout.setHorizontalGroup(
            fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel294)
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addComponent(jLabel295)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(fechaMes))
                    .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                            .addComponent(jLabel293)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel296))
                        .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                            .addComponent(jLabel290)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(identificador))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                            .addComponent(jLabel289)
                            .addGap(18, 18, 18)
                            .addComponent(Codigo))
                        .addComponent(jSeparator150, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                            .addComponent(jLabel291)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Nombre))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                            .addComponent(jLabel292)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Apellido))
                        .addComponent(jSeparator151, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(PeriodoPago))
                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jSeparator152, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addComponent(jLabel301)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSeparator158, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addComponent(jLabel303)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(OtrosDescuentos1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(OtrosDescuentos, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addComponent(jLabel300)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(AFP))
                                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addComponent(jLabel302)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(Salariosubtotal))
                                            .addComponent(jSeparator157, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator155, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator154, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator153)
                                            .addComponent(jSeparator156, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addComponent(jLabel299)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(ISSS))
                                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(Renta))
                                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addComponent(jLabel304)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabel305)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(OtrosDescuentos2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addComponent(jLabel298)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(Salariodevengado)))
                                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addGap(172, 172, 172)
                                                .addComponent(Descuento))
                                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(descuento, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(descuento1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(descuento2, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                                .addGap(53, 53, 53))))
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addGap(142, 142, 142)
                        .addComponent(jLabel306)
                        .addGap(18, 18, 18)
                        .addComponent(SalarioTotal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(exportar17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(exportar)
                        .addGap(16, 16, 16))))
            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(atras, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(267, 267, 267)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel297)
                .addGap(239, 239, 239))
        );
        fondo_interno_generar_boletaLayout.setVerticalGroup(
            fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(atras))
                .addGap(38, 38, 38)
                .addComponent(jLabel297)
                .addGap(18, 18, 18)
                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel289)
                            .addComponent(Codigo, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator150, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel290)
                            .addComponent(identificador))
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel291)
                            .addComponent(Nombre))
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel292)
                            .addComponent(Apellido))
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator151, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel293)
                            .addComponent(jLabel296))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel294)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PeriodoPago)
                        .addGap(26, 26, 26)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel295)
                            .addComponent(fechaMes)))
                    .addComponent(jSeparator152, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel298)
                            .addComponent(Salariodevengado))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator153, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel299)
                            .addComponent(ISSS))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator154, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel300)
                            .addComponent(AFP))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator155, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Renta)
                            .addComponent(jLabel301, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator156, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel302)
                            .addComponent(Salariosubtotal))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator157, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addComponent(jLabel303)
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(OtrosDescuentos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Descuento))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(OtrosDescuentos1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(descuento1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(4, 4, 4))
                            .addGroup(fondo_interno_generar_boletaLayout.createSequentialGroup()
                                .addComponent(descuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel304)
                            .addComponent(OtrosDescuentos2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel305)
                            .addComponent(descuento2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addComponent(jSeparator158, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(fondo_interno_generar_boletaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel306)
                            .addComponent(SalarioTotal)
                            .addComponent(exportar)
                            .addComponent(exportar17))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addComponent(fondo_interno_generar_boleta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(98, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(fondo_interno_generar_boleta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void exportarexportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportarexportarActionPerformed
        Object[] options = {"Descargar en PDF", "Enviar por correo", "Cancelar"};
        int seleccion = JOptionPane.showOptionDialog(null, "¿Cómo lo desea exportar?", "Exportar", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[2]);

        if (seleccion == JOptionPane.YES_OPTION) {
            System.out.println("PDF");
            exportar.setEnabled(true);
            // Validación del campo OtrosDescuentos
            String textoDescuento = OtrosDescuentos.getText();
            double porcentajeDescuento = 0.0;
            String textoDescuento1 = OtrosDescuentos1.getText();
            double porcentajeDescuento1 = 0.0;
            if (!textoDescuento.isEmpty() && !textoDescuento1.isEmpty()) {
                try {
                    // Verificar si es un número entero
                    int descuentoEntero = Integer.parseInt(textoDescuento);
                    int descuentoEntero1 = Integer.parseInt(textoDescuento1);
                    // Verificar si el número está dentro del rango permitido
                    if (descuentoEntero < 0 || descuentoEntero > 100 || descuentoEntero1 < 0 || descuentoEntero1 > 100) {
                        throw new NumberFormatException("El descuento debe estar entre 0 y 100.");
                    }
                    porcentajeDescuento1 = descuentoEntero1;
                    porcentajeDescuento = descuentoEntero;
                    OtrosDescuentos.setBackground(Color.WHITE);
                    OtrosDescuentos1.setBackground(Color.WHITE);
                    primerError = true;
                } catch (NumberFormatException e) {
                    OtrosDescuentos.setBackground(Color.PINK);
                    OtrosDescuentos1.setBackground(Color.PINK);
                    primerError = false;
                    JOptionPane.showMessageDialog(this, "El valor de otros descuentos no es válido. Debe ser un número entero entre 0 y 100.");
                    return;  // Salir del método si el valor es inválido
                }
            }

            // Datos para el PDF
            String nombreEmpleado = Nombre.getText();
            String idEmpleado = identificador.getText();
            String fechaPago = fechaMes.getText();
            double salarioBase = 365;
            double bonificaciones = calcularValorPuntos(puntosTot, puntosN, puntosI);
            double total = Double.parseDouble(SalarioTotal.getText());
            double otrosD = porcentajeDescuento;
            double otrosD1 = porcentajeDescuento1;
            // Lógica para exportar el PDF
            String Tarjeta = "NO APLICA";
            if (puntosTot < 525) {
                bonificaciones = 0;
            }
            if (puntosTot > 525 && puntosTot <= 2500) {
                Tarjeta = "NO APLICA";
            } else if (puntosTot > 2500) {
                Tarjeta = "APLICA TAJETA DE REGALO DE 100$";
            }
            String rutaPDF = System.getProperty("user.home") + File.separator + "Documents" + File.separator + "Pdf de empleados" + File.separator;

            String nombreArchivoBase = "Boleta_" + idEmpleado + "_" + nombreEmpleado.replace(" ", "_") + "_" + fechaPago;

            File archivo = new File(rutaPDF + nombreArchivoBase + ".pdf");

            if (archivo.exists()) {
                JOptionPane.showMessageDialog(this, "Ya existe un archivo PDF con el nombre especificado. No se puede crear uno nuevo.");
                System.out.println("Archivo ya existe: " + archivo.getAbsolutePath());
                return;  // Salir del método si el archivo ya existe
            } else {
                System.out.println("Archivo no existe, procediendo a crear: " + archivo.getAbsolutePath());
            }
            
            if (otrosD > 0 && otrosD1 == 0){
                String Institucion1 = descuento.getSelectedItem().toString();
                PDF.convertHtmlToPdf1(nombreEmpleado, idEmpleado, fechaPago, salarioBase, bonificaciones, descuentosTot, otrosD, Institucion1,total, Tarjeta, nombreArchivoBase);
            } else if (otrosD > 0 && otrosD1 == 0){
                String Institucion1 = descuento.getSelectedItem().toString();
                String Institucion2 = descuento1.getSelectedItem().toString();
                PDF.convertHtmlToPdf2(nombreEmpleado, idEmpleado, fechaPago, salarioBase, bonificaciones, descuentosTot, otrosD, Institucion1,otrosD1,Institucion2,total, Tarjeta, nombreArchivoBase);
            }
             else {
                PDF.convertHtmlToPdfSinOtrosDescuentos(nombreEmpleado, idEmpleado, fechaPago, salarioBase, bonificaciones, descuentosTot, total, Tarjeta, nombreArchivoBase);
            }
            exportar.setEnabled(true);
        } else if (seleccion == JOptionPane.NO_OPTION) {
            System.out.println("Correo");

            // Lógica para enviar por correo
        } else if (seleccion == JOptionPane.CANCEL_OPTION || seleccion == JOptionPane.CLOSED_OPTION) {
            System.out.println("Cancelar");

            // Lógica para cerrar la pestaña
        }
    }//GEN-LAST:event_exportarexportarActionPerformed

    private void atrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atrasActionPerformed

        panel_calculo_puntos calculo_puntos = new panel_calculo_puntos(empleados,empleadosMap);
        calculo_puntos.setSize(940, 510);
        calculo_puntos.setLocation(0, 0);

        fondo_interno_generar_boleta.removeAll();
        fondo_interno_generar_boleta.add(calculo_puntos, BorderLayout.CENTER);
        fondo_interno_generar_boleta.revalidate();
        fondo_interno_generar_boleta.repaint();
    }//GEN-LAST:event_atrasActionPerformed

    private void exportar17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportar17ActionPerformed
        String textoDescuento = OtrosDescuentos.getText();
        String textoDescuento1 = OtrosDescuentos2.getText();
        String textoDescuento2 = OtrosDescuentos2.getText();
        double porcentajeDescuento = 0.0;
        double porcentajeDescuento1 = 0.0;
        double porcentajeDescuento2 = 0.0;
        if (!textoDescuento.isEmpty()) {
            try {
                // Verificar si es un número entero
                int descuentoEntero = Integer.parseInt(textoDescuento);
                // Verificar si el número está dentro del rango permitido
                if (descuentoEntero < 0 || descuentoEntero > 100) {
                    throw new NumberFormatException("El descuento debe estar entre 0 y 100.");
                }
                porcentajeDescuento = descuentoEntero;
            } catch (NumberFormatException e) {
                porcentajeDescuento = 0.0;
                JOptionPane.showMessageDialog(this, "El valor del primer descuento no es válido. Debe ser un número entero entre 0 y 100.");
                return; // Salir del método si el valor es inválido
            }
        }

        // Validar y convertir el segundo descuento
        if (!textoDescuento1.isEmpty()) {
            try {
                // Verificar si es un número entero
                int descuentoEntero1 = Integer.parseInt(textoDescuento1);
                // Verificar si el número está dentro del rango permitido
                if (descuentoEntero1 < 0 || descuentoEntero1 > 100) {
                    throw new NumberFormatException("El descuento debe estar entre 0 y 100.");
                }
                porcentajeDescuento1 = descuentoEntero1;
            } catch (NumberFormatException e) {
                porcentajeDescuento1 = 0.0;
                JOptionPane.showMessageDialog(this, "El valor del segundo descuento no es válido. Debe ser un número entero entre 0 y 100.");
                return; // Salir del método si el valor es inválido
            }
        }

        if (!textoDescuento2.isEmpty()) {
            try {
                // Verificar si es un número entero
                int descuentoEntero2 = Integer.parseInt(textoDescuento2);
                // Verificar si el número está dentro del rango permitido
                if (descuentoEntero2 < 0 || descuentoEntero2 > 100) {
                    throw new NumberFormatException("El descuento debe estar entre 0 y 100.");
                }
                porcentajeDescuento2 = descuentoEntero2;
            } catch (NumberFormatException e) {
                porcentajeDescuento = 0.0;
                JOptionPane.showMessageDialog(this, "El valor del primer descuento no es válido. Debe ser un número entero entre 0 y 100.");
                return; // Salir del método si el valor es inválido
            }
        }

        Boleta bol = new Boleta();
        double salariob = 365;
        int numero = Integer.parseInt(IdEmpleado);

        LocalDate fecha = LocalDate.now();
        // Verificar si se puede generar una nueva boleta
        if (!fua.puedeGenerarBoleta(numero, fecha)) {
            JOptionPane.showMessageDialog(this, "Ya existe una boleta para este empleado en el mes actual.");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de que desea guardar la boleta?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            bol.setIdEmpleado(numero);
            String fechaPago = fechaMes.getText();
            bol.setCode("Boleta_" + IdEmpleado + "_" + nombre.replace(" ", "_") + "_" + fechaPago);
            bol.setIssueDate(fecha.toString());  // Convertir LocalDate a String
            bol.setEarnedSalary(salariob);
            bol.setDiscount(descuentosTot);
            bol.setSalaryTotal(salarioTot);
            if (fua.guardar(bol)) {
                JOptionPane.showMessageDialog(this, "Registrado con éxito");
                boleta = fua.Listar();
            } else {
                JOptionPane.showMessageDialog(this, "Error al guardar");
            }
        } else {
            // El usuario ha cancelado la operación
            JOptionPane.showMessageDialog(this, "La operación ha sido cancelada.");
        }
    }//GEN-LAST:event_exportar17ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AFP;
    private javax.swing.JLabel Apellido;
    private javax.swing.JLabel Codigo;
    private javax.swing.JLabel Descuento;
    private javax.swing.JLabel ISSS;
    private javax.swing.JLabel Nombre;
    private javax.swing.JTextField OtrosDescuentos;
    private javax.swing.JTextField OtrosDescuentos1;
    private javax.swing.JTextField OtrosDescuentos2;
    private javax.swing.JLabel PeriodoPago;
    private javax.swing.JLabel Renta;
    private javax.swing.JLabel SalarioTotal;
    private javax.swing.JLabel Salariodevengado;
    private javax.swing.JLabel Salariosubtotal;
    private javax.swing.JButton atras;
    private javax.swing.JComboBox<String> descuento;
    private javax.swing.JComboBox<String> descuento1;
    private javax.swing.JComboBox<String> descuento2;
    private javax.swing.JButton exportar;
    private javax.swing.JButton exportar17;
    private javax.swing.JLabel fechaMes;
    private javax.swing.JPanel fondo_interno_generar_boleta;
    private javax.swing.JLabel identificador;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel289;
    private javax.swing.JLabel jLabel290;
    private javax.swing.JLabel jLabel291;
    private javax.swing.JLabel jLabel292;
    private javax.swing.JLabel jLabel293;
    private javax.swing.JLabel jLabel294;
    private javax.swing.JLabel jLabel295;
    private javax.swing.JLabel jLabel296;
    private javax.swing.JLabel jLabel297;
    private javax.swing.JLabel jLabel298;
    private javax.swing.JLabel jLabel299;
    private javax.swing.JLabel jLabel300;
    private javax.swing.JLabel jLabel301;
    private javax.swing.JLabel jLabel302;
    private javax.swing.JLabel jLabel303;
    private javax.swing.JLabel jLabel304;
    private javax.swing.JLabel jLabel305;
    private javax.swing.JLabel jLabel306;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator150;
    private javax.swing.JSeparator jSeparator151;
    private javax.swing.JSeparator jSeparator152;
    private javax.swing.JSeparator jSeparator153;
    private javax.swing.JSeparator jSeparator154;
    private javax.swing.JSeparator jSeparator155;
    private javax.swing.JSeparator jSeparator156;
    private javax.swing.JSeparator jSeparator157;
    private javax.swing.JSeparator jSeparator158;
    // End of variables declaration//GEN-END:variables
}
