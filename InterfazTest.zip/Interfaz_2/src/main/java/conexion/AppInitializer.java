package conexion;

import com.aspose.pdf.HtmlLoadOptions;
import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMaterialLighterIJTheme;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class AppInitializer {

    // Almacenar configuraciones precargadas
    private HtmlLoadOptions htmlLoadOptions;

    public AppInitializer() {
        // Inicia la configuración al principio
        SwingUtilities.invokeLater(() -> {
            new Thread(() -> {
                try {
                    // Configurar el tema de la UI
                    FlatMaterialLighterIJTheme.setup();
                    UIManager.setLookAndFeel(new FlatMaterialLighterIJTheme());

                    // Inicializar recursos
                    htmlLoadOptions = new HtmlLoadOptions();

                    // Opcional: Realizar una conversión de prueba para precargar el proceso
                    precargarRecursos();

                    System.out.println("Recursos precargados con éxito.");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        });
    }

    private void precargarRecursos() {
        // Realizar una conversión de prueba para precargar los recursos
        String htmlContent = "<html><body><h1>Prueba de Precarga</h1></body></html>";
        try {
            ByteArrayInputStream inputStream = new ByteArrayInputStream(htmlContent.getBytes(StandardCharsets.UTF_8));
            new com.aspose.pdf.Document(inputStream, htmlLoadOptions);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public HtmlLoadOptions getHtmlLoadOptions() {
        return htmlLoadOptions;
    }
}
