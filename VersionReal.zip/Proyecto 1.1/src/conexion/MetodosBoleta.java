/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author MINEDUCYT
 */
public class MetodosBoleta {

    Connection con;
    conexion cn = new conexion();
    PreparedStatement ps;
    ResultSet rs;

    public List Listar() {
        List<Boleta> lista = new ArrayList<>();
        String sql = "SELECT * FROM paymentsheet";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Boleta bol = new Boleta();
                bol.setIdboleta(rs.getInt(1));
                bol.setIdEmpleado(rs.getInt(2));
                bol.setIssueDate(rs.getString(3));
                bol.setEarnedSalary(rs.getDouble(4));
                bol.setDiscount(rs.getDouble(5));
                bol.setSalaryTotal(rs.getDouble(6));
                lista.add(bol);
            }
        } catch (SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return lista;
    }

    public boolean puedeGenerarBoleta(int empleadoId, LocalDate fecha) {
        String sql = "SELECT COUNT(*) FROM paymentsheet WHERE IdEmployee = ? AND MONTH(issueDate) = ? AND YEAR(issueDate) = ?";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, empleadoId);
            ps.setInt(2, fecha.getMonthValue());
            ps.setInt(3, fecha.getYear());
            rs = ps.executeQuery();

            if (rs.next()) {
                int count = rs.getInt(1);
                return count == 0; // Retorna true si no hay boletas en ese mes
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        return false;
    }

    public boolean guardar(Boleta bol) {
        String sql = "INSERT INTO paymentsheet(IdPaymentsheet,IdEmployee,IssueDate,EarnedSalary,Discount,SalaryTotal) VALUES(?,?,?,?,?,?)";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, bol.getIdboleta());
            ps.setInt(2, bol.getIdEmpleado());
            ps.setString(3, bol.getIssueDate());
            ps.setDouble(4, bol.getEarnedSalary());
            ps.setDouble(5, bol.getDiscount());
            ps.setDouble(6, bol.getSalaryTotal());
            int n = ps.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

}
