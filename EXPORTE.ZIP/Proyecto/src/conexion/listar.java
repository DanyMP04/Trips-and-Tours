package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class listar {
    Connection con;
    conexion cn = new conexion();
    PreparedStatement ps;
    ResultSet rs;

    public List<Empleados> Listar() {
        List<Empleados> lista = new ArrayList<>();
        String sql = "SELECT * FROM employee";
        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Empleados au = new Empleados();
                au.setId(rs.getInt(1));
                au.setNombre(rs.getString(2));
                au.setApellido(rs.getString(3));
                lista.add(au);
            }
        } catch (SQLException e) {
            e.printStackTrace();  
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
}
