/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.util.Date;

/**
 *
 * @author Danym
 */


public class Planilla {

    private int idPaymentSheet;
    private Date creationDate;
    private String month;
    private String year;
    private int idEmployee;
    private String employeeName;
    private String employeeLastName;
    private double earnedSalary;
    private double discount;
    private double isss;
    private double afp;
    private double rent;
    private double othersD;
    private double salaryTotal;

    // Constructores
    public Planilla(){
    
    }
    
    public Planilla(int idPaymentSheet,Date CreationDate , String month, String year, int idEmployee, String employeeName,
                    String employeeLastName, double earnedSalary, double discount, double isss, double afp, double rent, double othersD, double salaryTotal) {
        this.idPaymentSheet = idPaymentSheet;
        this.creationDate = creationDate;
        this.month = month;
        this.year = year;
        this.idEmployee = idEmployee;
        this.employeeName = employeeName;
        this.employeeLastName = employeeLastName;
        this.earnedSalary = earnedSalary;
        this.discount = discount;
        this.isss = isss;
        this.afp = afp;
        this.rent = rent;
        this.othersD = othersD;
        this.salaryTotal = salaryTotal;
    }

    // Getters and Setters
    public int getIdPaymentSheet() {
        return idPaymentSheet;
    }

    public void setIdPaymentSheet(int idPaymentSheet) {
        this.idPaymentSheet = idPaymentSheet;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeLastName() {
        return employeeLastName;
    }

    public void setEmployeeLastName(String employeeLastName) {
        this.employeeLastName = employeeLastName;
    }

    public double getEarnedSalary() {
        return earnedSalary;
    }

    public void setEarnedSalary(double earnedSalary) {
        this.earnedSalary = earnedSalary;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getSalaryTotal() {
        return salaryTotal;
    }

    public void setSalaryTotal(double salaryTotal) {
        this.salaryTotal = salaryTotal;
    }

    public double getIsss() {
        return isss;
    }

    public void setIsss(double isss) {
        this.isss = isss;
    }

    public double getAfp() {
        return afp;
    }

    public void setAfp(double afp) {
        this.afp = afp;
    }

    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }

    public double getOthersD() {
        return othersD;
    }

    public void setOthersD(double othersD) {
        this.othersD = othersD;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }
    
    
    
@Override
public String toString() {
    return "Planilla{" +
            "idPaymentSheet=" + idPaymentSheet +
            ", month='" + month + '\'' +
            ", year='" + year + '\'' +
            ", idEmployee=" + idEmployee +
            ", employeeName='" + employeeName + '\'' +
            ", employeeLastName='" + employeeLastName + '\'' +
            ", earnedSalary=" + earnedSalary +
            ", discount=" + discount +
            ", isss=" + isss +
            ", afp=" + afp +
            ", rent=" + rent +
            ", othersD=" + othersD +
            ", salaryTotal=" + salaryTotal +
            '}';
}

}