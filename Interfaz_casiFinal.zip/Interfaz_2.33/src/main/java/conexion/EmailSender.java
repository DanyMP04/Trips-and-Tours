package conexion;

import Principal.*;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.util.Properties;

public class EmailSender {

    public void sendEmailWithAttachment(String from, String to, String subject, String body) {
        // Abrir un JFileChooser para seleccionar el archivo PDF
        JFileChooser fileChooser = new JFileChooser();

        // Establecer la carpeta por defecto (puedes cambiar la ruta a la carpeta deseada)
        File carpetaPorDefecto = new File("C:\\Users\\MINEDUCYT\\Documents\\Pdf de empleados");
        if (carpetaPorDefecto.exists() && carpetaPorDefecto.isDirectory()) {
            fileChooser.setCurrentDirectory(carpetaPorDefecto);
        } else {
            // Si la carpeta no existe, usa el directorio de usuario por defecto
            fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        }

        // Filtrar para que solo se puedan seleccionar archivos PDF
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos PDF", "pdf");
        fileChooser.setFileFilter(filter);

        // Mostrar el diálogo de selección de archivos
        int result = fileChooser.showOpenDialog(null);

        // Si el usuario selecciona un archivo, procedemos a enviar el correo
        if (result == JFileChooser.APPROVE_OPTION) {
            String attachmentPath = fileChooser.getSelectedFile().getAbsolutePath();

            // Configuración de las propiedades del correo
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");  // Agregar esta línea

            // Creación de la sesión de correo
            Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("softwareworldrevolution24@gmail.com", "mrzf klsv qkqa nibx");
                }
            });

            try {
                // Creación del mensaje de correo
                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(from));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
                message.setSubject(subject);

                // Crear el cuerpo del mensaje con el adjunto
                BodyPart messageBodyPart = new MimeBodyPart();
                messageBodyPart.setText(body);

                Multipart multipart = new MimeMultipart();
                multipart.addBodyPart(messageBodyPart);

                // Agregar el adjunto
                messageBodyPart = new MimeBodyPart();
                DataSource source = new FileDataSource(attachmentPath);
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(new File(attachmentPath).getName());
                multipart.addBodyPart(messageBodyPart);

                // Establecer el mensaje completo
                message.setContent(multipart);

                // Envío del correo
                Transport.send(message);
                System.out.println("Correo enviado exitosamente.");
            } catch (MessagingException e) {
                System.out.println("Error al enviar el correo: " + e.getMessage());
            }
        } else {
            System.out.println("No se seleccionó ningún archivo.");
        }
    }

}
