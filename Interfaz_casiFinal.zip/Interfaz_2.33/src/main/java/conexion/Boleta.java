/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author MINEDUCYT
 */
public class Boleta {
    private int idboleta;
    private int idEmpleado;
    private String Code;
    private String IssueDate;
    private double EarnedSalary;
    private double ISSS;
    private double AFP;
    private double Renta;
    private double OtrosDescuentos;
    private double SalaryTotal;

    public Boleta() {
    }

    public Boleta(int idboleta, int idEmpleado, String Code, String IssueDate, double EarnedSalary, double ISSS, double AFP, double Renta, double OtrosDescuentos, double SalaryTotal) {
        this.idboleta = idboleta;
        this.idEmpleado = idEmpleado;
        this.Code = Code;
        this.IssueDate = IssueDate;
        this.EarnedSalary = EarnedSalary;
        this.ISSS = ISSS;
        this.AFP = AFP;
        this.Renta = Renta;
        this.OtrosDescuentos = OtrosDescuentos;
        this.SalaryTotal = SalaryTotal;
    }

    public int getIdboleta() {
        return idboleta;
    }

    public void setIdboleta(int idboleta) {
        this.idboleta = idboleta;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String Code) {
        this.Code = Code;
    }

    public String getIssueDate() {
        return IssueDate;
    }

    public void setIssueDate(String IssueDate) {
        this.IssueDate = IssueDate;
    }

    public double getEarnedSalary() {
        return EarnedSalary;
    }

    public void setEarnedSalary(double EarnedSalary) {
        this.EarnedSalary = EarnedSalary;
    }

    public double getISSS() {
        return ISSS;
    }

    public void setISSS(double ISSS) {
        this.ISSS = ISSS;
    }

    public double getAFP() {
        return AFP;
    }

    public void setAFP(double AFP) {
        this.AFP = AFP;
    }

    public double getRenta() {
        return Renta;
    }

    public void setRenta(double Renta) {
        this.Renta = Renta;
    }

    public double getOtrosDescuentos() {
        return OtrosDescuentos;
    }

    public void setOtrosDescuentos(double OtrosDescuentos) {
        this.OtrosDescuentos = OtrosDescuentos;
    }

    public double getSalaryTotal() {
        return SalaryTotal;
    }

    public void setSalaryTotal(double SalaryTotal) {
        this.SalaryTotal = SalaryTotal;
    }
    
    
}
