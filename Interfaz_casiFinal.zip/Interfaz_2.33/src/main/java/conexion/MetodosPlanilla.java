/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author Danym
 */import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;

public class MetodosPlanilla {

    Connection con;
    conexion cn = new conexion();
    PreparedStatement ps;
    ResultSet rs;

        public void populateComboBox(JComboBox<String> comboBox) {
        try {
            String query = "SELECT DISTINCT monthP, yearP FROM worksheet ORDER BY yearP, monthP";
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            comboBox.removeAllItems(); // Limpiar el comboBox antes de poblarlo

            while (rs.next()) {
                String mes = rs.getString("mes");
                String año = rs.getString("año");
                String item = mes + " - " + año;
                comboBox.addItem(item);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<Planilla> Listar(String mes, String anio) {
    List<Planilla> lista = new ArrayList<>();
    String sql = "SELECT * FROM worksheet";
    
    
    // Modificar la consulta si se pasan parámetros para filtrar por mes y año
    if (mes != null && anio != null) {
        sql += " WHERE MonthP = ? AND YearP = ?";
    }
    
    try {
        con = cn.getConexion();
        ps = con.prepareStatement(sql);
        
        // Si se pasan parámetros, establecerlos en el PreparedStatement
        if (mes != null && anio != null) {
            ps.setString(1, mes);
            ps.setString(2, anio);
        }
        
        
        
        rs = ps.executeQuery();
        while (rs.next()) {
            Planilla au = new Planilla();
            au.setIdPaymentSheet(rs.getInt(1));
            au.setCreationDate(rs.getDate(2));
            au.setMonth(rs.getString(3));
            au.setYear(rs.getString(4));
            au.setIdEmployee(rs.getInt(5));
            au.setEmployeeName(rs.getString(6));
            au.setEmployeeLastName(rs.getString(7));
            au.setEarnedSalary(rs.getDouble(8));
            au.setDiscount(rs.getDouble(9));
            au.setIsss(rs.getDouble(10));
            au.setAfp(rs.getDouble(11));
            au.setRent(rs.getDouble(12));
            au.setOthersD(rs.getDouble(13));
            au.setSalaryTotal(rs.getDouble(14));
            lista.add(au);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    return lista;
}

        // Método para obtener la suma de SalaryTotal filtrado por mes y año
    public double getTotalSalaryByParameters(String month, String year) {
        double totalSalary = 0.0;

        // Parámetros de conexión
        String url = "jdbc:mysql://localhost:3306/tripsandtour"; // Reemplaza con tu URL de conexión
        String user = "root"; // Reemplaza con tu usuario
        String password = "12345678"; // Reemplaza con tu contraseña

        // Consulta SQL con parámetros
        String query = "SELECT SUM(SalaryTotal) AS total FROM worksheet WHERE MonthP = ? AND YearP = ?";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Establecer los valores de los parámetros
            preparedStatement.setString(1, month);
            preparedStatement.setString(2, year);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    totalSalary = resultSet.getDouble("total");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalSalary;
    }
     
    
    
}