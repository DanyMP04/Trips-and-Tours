/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author MINEDUCYT
 */
public class Usuarios {
    private int idUsuario;
    private String Nombre;
    private String Contraseña;

    public Usuarios() {
    }

    public Usuarios(int idUsuario, String Nombre, String Contraseña) {
        this.idUsuario = idUsuario;
        this.Nombre = Nombre;
        this.Contraseña = Contraseña;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }
    
    
}
