/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Principal;

import com.formdev.flatlaf.FlatClientProperties;
import conexion.Empleados;
import conexion.MetodosEmpleado;
import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author xyali
 */
public class panel_calculo_puntos extends javax.swing.JPanel {

     private List<Empleados> empleados;
    MetodosEmpleado fu = new MetodosEmpleado();
    private Map<String, EmpleadoInfo> empleadosMap = new HashMap<>();

    /**
     * Creates new form panel_calculo_puntos
     */
    public panel_calculo_puntos(List<Empleados> empleados, Map<String, EmpleadoInfo> empleadosMap) {
        initComponents();
        this.empleados = empleados;
        this.empleadosMap = empleadosMap;
        InitStyles();
        initializeKeyEventListener();
        addValidationListeners();
        addFocusListenersAndAction(paquete_1, paquete_2, paquete_3, paquete_4, paquete_5);
        actualizarComboBoxUsuarios(); // Llamar al método para llenar el JComboBox al inicio
    }

    public void actualizarComboBoxUsuarios() {
        seleccion_empleado.removeAllItems(); // Limpiar el JComboBox
        
        // Iterar sobre la lista de empleados
        for (Empleados empleado : empleados) {
            String nombreCompleto = empleado.getNombre() + " " + empleado.getApellido();
            // Agregar al JComboBox el nombre completo del empleado
            seleccion_empleado.addItem(nombreCompleto);
        }
        
        seleccion_empleado.revalidate(); // Asegurar que el JComboBox se actualice
        seleccion_empleado.repaint();
    }

// Clase interna para almacenar la información del empleado
    public static class EmpleadoInfo {

        private final int id;
        private final String nombre;
        private final String apellido;

        public EmpleadoInfo(int id, String nombre, String apellido) {
            this.id = id;
            this.nombre = nombre;
            this.apellido = apellido;
        }

        public int getId() {
            return id;
        }

        public String getNombre() {
            return nombre;
        }

        public String getApellido() {
            return apellido;
        }
    }

// Método para obtener la información del empleado seleccionado
    public EmpleadoInfo getEmpleadoInfoSeleccionado() {
        String nombreSeleccionado = (String) seleccion_empleado.getSelectedItem();
        return empleadosMap.get(nombreSeleccionado);
    }

    private boolean shakeInProgress = false;
    public int totalPuntosNacionales;
    public int totalPuntosInternacionales;

    public int getTotalPuntosN() {
        return totalPuntosNacionales;
    }

    public int getTotalPuntosI() {
        return totalPuntosInternacionales;
    }

    private void shakeComponent(JComponent component) {
        if (shakeInProgress) {
            return;
        }

        shakeInProgress = true;
        final int originalX = component.getLocation().x;
        final int originalY = component.getLocation().y;

        final int shakeDistance = 3;
        final int shakeDuration = 30;
        final int shakeCount = 3;

        new Thread(() -> {
            try {
                for (int i = 0; i < shakeCount; i++) {
                    // Movimiento hacia la izquierda
                    SwingUtilities.invokeLater(() -> component.setLocation(originalX - shakeDistance, originalY));
                    Thread.sleep(shakeDuration);
                    // Movimiento hacia la derecha
                    SwingUtilities.invokeLater(() -> component.setLocation(originalX + shakeDistance, originalY));
                    Thread.sleep(shakeDuration);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                // Restaurar la posición original
                SwingUtilities.invokeLater(() -> component.setLocation(originalX, originalY));
                shakeInProgress = false;
            }
        }).start();
    }

    private boolean enterPressedWhileEditing = false;

    private boolean isEditing = false;

    private void initializeKeyEventListener() {
        Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener() {
            @Override
            public void eventDispatched(AWTEvent event) {
                KeyEvent keyEvent = (KeyEvent) event;

                if (keyEvent.getID() == KeyEvent.KEY_RELEASED) {
                    if (keyEvent.getKeyCode() == KeyEvent.VK_ENTER) {
                        if (!isEditing) {
                            calcular.doClick();
                        }
                    }
                }
            }
        }, AWTEvent.KEY_EVENT_MASK);
    }

    private void addValidationListeners() {
        addNumericValidation(paquete_1, errorLabel1);
        addNumericValidation(paquete_2, errorLabel2);
        addNumericValidation(paquete_3, errorLabel3);
        addNumericValidation(paquete_4, errorLabel4);
        addNumericValidation(paquete_5, errorLabel5);
    }

    private void addFocusListenersAndAction(JTextField... textFields) {
        for (JTextField textField : textFields) {
            textField.addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    isEditing = true; // Indica que el campo está siendo editado
                }

                @Override
                public void focusLost(FocusEvent e) {
                    isEditing = false; // Indica que el campo ha perdido el enfoque
                }
            });

            textField.addActionListener(e -> {
                // Mueve el foco fuera del campo de texto
                textField.transferFocus();

                // Solo ejecuta la acción si el campo no está en edición
                if (!isEditing) {
                    checkAndExecuteButtonAction();
                }
            });
        }
    }

    private void checkAndExecuteButtonAction() {
        // Espera un corto periodo de tiempo para asegurar que todos los eventos de enfoque se procesen
        SwingUtilities.invokeLater(() -> {
            if (!isEditing) {
                calcular.doClick();
            }
        });
    }

    private void addNumericValidation(JTextField textField, JLabel errorLabel) {
        textField.getDocument().addDocumentListener(new DocumentListener() {
            private boolean hasShaken = false;

            @Override
            public void insertUpdate(DocumentEvent e) {
                validateField(textField, errorLabel);
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                validateField(textField, errorLabel);
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                validateField(textField, errorLabel);
            }

            private void validateField(JTextField textField, JLabel errorLabel) {
                String text = textField.getText();
                enterPressedWhileEditing = true; // Indicar que se está editando

                if (!text.matches("\\d*")) {
                    textField.setBackground(Color.PINK);
                    errorLabel.setText("Error");

                    if (!hasShaken) {
                        shakeComponent(textField);
                        hasShaken = true;
                    }
                } else {
                    textField.setBackground(Color.WHITE);
                    errorLabel.setText("");
                    hasShaken = false;
                    enterPressedWhileEditing = false;
                }
            }
        });
    }

    private void InitStyles (){
        seleccion_empleado.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        paquete_1.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        paquete_2.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        paquete_3.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        paquete_4.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        paquete_5.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        comision.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        calcular.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        Seleccion.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        generar_bol.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        fondo_interno.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondo_calculo_puntos = new javax.swing.JPanel();
        fondo_interno = new javax.swing.JPanel();
        Seleccion = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        seleccion_empleado = new javax.swing.JComboBox<>();
        jLabel40 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        paquete_1 = new javax.swing.JTextField();
        paquete_2 = new javax.swing.JTextField();
        paquete_3 = new javax.swing.JTextField();
        paquete_4 = new javax.swing.JTextField();
        paquete_5 = new javax.swing.JTextField();
        comision = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        calcular = new javax.swing.JButton();
        generar_bol = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        errorLabel1 = new javax.swing.JLabel();
        errorLabel2 = new javax.swing.JLabel();
        errorLabel3 = new javax.swing.JLabel();
        errorLabel4 = new javax.swing.JLabel();
        errorLabel5 = new javax.swing.JLabel();

        fondo_calculo_puntos.setBackground(new java.awt.Color(204, 204, 204));

        Seleccion.setBackground(new java.awt.Color(204, 204, 204));
        Seleccion.setForeground(new java.awt.Color(0, 0, 0));
        Seleccion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nacionales.", "Internacionales." }));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Juan Pedro Antonio Escobar");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Empleado seleccionado");

        seleccion_empleado.setBackground(new java.awt.Color(204, 204, 204));
        seleccion_empleado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        seleccion_empleado.setForeground(new java.awt.Color(0, 0, 0));
        seleccion_empleado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Zud sero", "Zcorpyon", "Cum liado" }));
        seleccion_empleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seleccion_empleadoActionPerformed(evt);
            }
        });

        jLabel40.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(0, 0, 0));
        jLabel40.setText("Seleccionar empleado");

        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Tipo de paquetes");

        paquete_1.setBackground(new java.awt.Color(204, 204, 204));
        paquete_1.setForeground(new java.awt.Color(0, 0, 0));

        paquete_2.setBackground(new java.awt.Color(204, 204, 204));
        paquete_2.setForeground(new java.awt.Color(0, 0, 0));

        paquete_3.setBackground(new java.awt.Color(204, 204, 204));
        paquete_3.setForeground(new java.awt.Color(0, 0, 0));

        paquete_4.setBackground(new java.awt.Color(204, 204, 204));
        paquete_4.setForeground(new java.awt.Color(0, 0, 0));

        paquete_5.setBackground(new java.awt.Color(204, 204, 204));
        paquete_5.setForeground(new java.awt.Color(0, 0, 0));

        comision.setBackground(new java.awt.Color(204, 204, 204));
        comision.setForeground(new java.awt.Color(0, 0, 0));

        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Comisión");

        calcular.setBackground(new java.awt.Color(204, 204, 204));
        calcular.setForeground(new java.awt.Color(0, 0, 0));
        calcular.setText("Calcular");
        calcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calcularActionPerformed(evt);
            }
        });

        generar_bol.setBackground(new java.awt.Color(204, 204, 204));
        generar_bol.setForeground(new java.awt.Color(0, 0, 0));
        generar_bol.setText("Generar boleta");
        generar_bol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generar_bolActionPerformed(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Paquete 1");

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Paquete 2");

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Paquete 3");

        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Paquete 4");

        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Paquete 5");

        javax.swing.GroupLayout fondo_internoLayout = new javax.swing.GroupLayout(fondo_interno);
        fondo_interno.setLayout(fondo_internoLayout);
        fondo_internoLayout.setHorizontalGroup(
            fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondo_internoLayout.createSequentialGroup()
                .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(fondo_internoLayout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel40)
                            .addComponent(seleccion_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(fondo_internoLayout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 582, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(fondo_internoLayout.createSequentialGroup()
                        .addGap(155, 155, 155)
                        .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(fondo_internoLayout.createSequentialGroup()
                                .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))
                                .addGap(18, 18, 18)
                                .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(paquete_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(paquete_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(fondo_internoLayout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(paquete_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(fondo_internoLayout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(paquete_4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(fondo_internoLayout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addComponent(paquete_5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(errorLabel1)
                            .addComponent(errorLabel3)
                            .addComponent(errorLabel2)
                            .addComponent(errorLabel4)
                            .addComponent(errorLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(Seleccion, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(comision)
                                .addComponent(jLabel2)
                                .addComponent(calcular, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(generar_bol, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap(53, Short.MAX_VALUE))
        );
        fondo_internoLayout.setVerticalGroup(
            fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondo_internoLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel40)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(seleccion_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondo_internoLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Seleccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(comision, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(calcular)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(generar_bol)
                        .addGap(8, 8, 8))
                    .addGroup(fondo_internoLayout.createSequentialGroup()
                        .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(paquete_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(errorLabel1))
                        .addGap(30, 30, 30)
                        .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(paquete_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(errorLabel2))
                        .addGap(29, 29, 29)
                        .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(paquete_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(errorLabel3))
                        .addGap(31, 31, 31)
                        .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(paquete_4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(errorLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addGroup(fondo_internoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(paquete_5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(errorLabel5))))
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout fondo_calculo_puntosLayout = new javax.swing.GroupLayout(fondo_calculo_puntos);
        fondo_calculo_puntos.setLayout(fondo_calculo_puntosLayout);
        fondo_calculo_puntosLayout.setHorizontalGroup(
            fondo_calculo_puntosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondo_calculo_puntosLayout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addComponent(fondo_interno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(126, Short.MAX_VALUE))
        );
        fondo_calculo_puntosLayout.setVerticalGroup(
            fondo_calculo_puntosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondo_calculo_puntosLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(fondo_interno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fondo_calculo_puntos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fondo_calculo_puntos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void seleccion_empleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seleccion_empleadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_seleccion_empleadoActionPerformed

    private void generar_bolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generar_bolActionPerformed
        panel_generar_boleta boleta = new panel_generar_boleta(this);
        boleta.setSize(940, 510);
        boleta.setLocation(0, 0);
        fondo_calculo_puntos.removeAll();
        fondo_calculo_puntos.add(boleta, BorderLayout.CENTER);
        fondo_calculo_puntos.revalidate();
        fondo_calculo_puntos.repaint();
    }//GEN-LAST:event_generar_bolActionPerformed

    private void calcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calcularActionPerformed
        try {
            // Obtener las cantidades de los paquetes
            int cantidadPaquete1 = obtenerCantidad(paquete_1);
            int cantidadPaquete2 = obtenerCantidad(paquete_2);
            int cantidadPaquete3 = obtenerCantidad(paquete_3);
            int cantidadPaquete4 = obtenerCantidad(paquete_4);
            int cantidadPaquete5 = obtenerCantidad(paquete_5);

            if (cantidadPaquete1 < 0 || cantidadPaquete2 < 0 || cantidadPaquete3 < 0
                    || cantidadPaquete4 < 0 || cantidadPaquete5 < 0) {
                throw new NumberFormatException("Las cantidades no pueden ser números negativos.");
            }

            // Suponiendo que tienes un JComboBox llamado tipoPaqueteComboBox
            String tipoSeleccionado = (String) Seleccion.getSelectedItem();

            int puntosPorPaquete1 = 0, puntosPorPaquete2 = 0, puntosPorPaquete3 = 0,
                    puntosPorPaquete4 = 0, puntosPorPaquete5 = 0;

            // Ajustar los puntos dependiendo del tipo de paquete seleccionado
            if ("Paquetes Nacionales".equals(tipoSeleccionado)) {
                puntosPorPaquete1 = 100;
                puntosPorPaquete2 = 100;
                puntosPorPaquete3 = 100;
                puntosPorPaquete4 = 100;
                puntosPorPaquete5 = 100;
                int puntos1 = cantidadPaquete1 * puntosPorPaquete1;
                int puntos2 = cantidadPaquete2 * puntosPorPaquete2;
                int puntos3 = cantidadPaquete3 * puntosPorPaquete3;
                int puntos4 = cantidadPaquete4 * puntosPorPaquete4;
                int puntos5 = cantidadPaquete5 * puntosPorPaquete5;

                totalPuntosNacionales = puntos1 + puntos2 + puntos3 + puntos4 + puntos5;
                System.out.println("Puntos totales: " + totalPuntosNacionales);
                double comisionTotal = totalPuntosNacionales * 0.35;
                comision.setText("$" + String.format("%.2f", comisionTotal));
            } else if ("Paquetes Internacionales".equals(tipoSeleccionado)) {
                puntosPorPaquete1 = 75;
                puntosPorPaquete2 = 75;
                puntosPorPaquete3 = 75;
                puntosPorPaquete4 = 75;
                puntosPorPaquete5 = 75;
                int puntos1 = cantidadPaquete1 * puntosPorPaquete1;
                int puntos2 = cantidadPaquete2 * puntosPorPaquete2;
                int puntos3 = cantidadPaquete3 * puntosPorPaquete3;
                int puntos4 = cantidadPaquete4 * puntosPorPaquete4;
                int puntos5 = cantidadPaquete5 * puntosPorPaquete5;

                totalPuntosInternacionales = puntos1 + puntos2 + puntos3 + puntos4 + puntos5;
                System.out.println("Puntos totales: " + totalPuntosInternacionales);
                double comisionTotal = totalPuntosInternacionales * 0.35;
                comision.setText("$" + String.format("%.2f", comisionTotal));
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                    "Por favor, ingresa números válidos en todos los campos.\n"
                    + "Asegúrate de que no haya letras u otros caracteres no numéricos.",
                    "Error de Entrada",
                    JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error inesperado: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_calcularActionPerformed

    public int obtenerCantidad(JTextField textField) {
        try {
            String text = textField.getText().trim();
            return text.isEmpty() ? 0 : Integer.parseInt(text);
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Entrada no válida");
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Seleccion;
    private javax.swing.JButton calcular;
    private javax.swing.JTextField comision;
    private javax.swing.JLabel errorLabel1;
    private javax.swing.JLabel errorLabel2;
    private javax.swing.JLabel errorLabel3;
    private javax.swing.JLabel errorLabel4;
    private javax.swing.JLabel errorLabel5;
    private javax.swing.JPanel fondo_calculo_puntos;
    private javax.swing.JPanel fondo_interno;
    private javax.swing.JButton generar_bol;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField paquete_1;
    private javax.swing.JTextField paquete_2;
    private javax.swing.JTextField paquete_3;
    private javax.swing.JTextField paquete_4;
    private javax.swing.JTextField paquete_5;
    private javax.swing.JComboBox<String> seleccion_empleado;
    // End of variables declaration//GEN-END:variables
}
