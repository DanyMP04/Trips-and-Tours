/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Principal;

import com.formdev.flatlaf.FlatClientProperties;
import conexion.MetodosBoleta;
import conexion.pdf;
import java.awt.Color;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author xyali
 */
public class panel_generar_boleta extends javax.swing.JPanel {
    
    private static final pdf PDF = new pdf();
    MetodosBoleta fu = new MetodosBoleta();
    private List<String> boleta;
    private panel_calculo_puntos instancia;
    public double descuentosTot;
    private double valorPuntos;
    private boolean shakeInProgress = false;
    private boolean primerError = true;
    public int puntosI;
    public int puntosN;
    public int puntosTot;
    public double salarioTot;
    public String IdEmpleado;

    /**
     * Creates new form panel_generar_boleta
     */
    public panel_generar_boleta(panel_calculo_puntos instancia) {
        initComponents();
        InitStyles();
        this.instancia = instancia;
        hacerAlgo();
        CalcularSalario();
        establecerPeriodoDePago();
        agregarListeners();
        mostrarInformacionEmpleado();
    }

    private void InitStyles() {
        OtrosDescuentos.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        descuento.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
        exportar.putClientProperty(FlatClientProperties.STYLE, "arc: 30");
    }

    public void mostrarInformacionEmpleado() {
        panel_calculo_puntos.EmpleadoInfo info = instancia.getEmpleadoInfoSeleccionado();
        if (info != null) {
            int id = info.getId();
            String nombre = info.getNombre();
            String apellido = info.getApellido();
            IdEmpleado = Integer.toString(id);
            identificador.setText(IdEmpleado);
            Nombre.setText(nombre);
            Apellido.setText(apellido);
        } else {
            System.out.println("No se ha seleccionado ningún empleado.");
        }
    }

    private void agregarListeners() {
        OtrosDescuentos.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void removeUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }

            public void insertUpdate(DocumentEvent e) {
                actualizarSalarioTotal();
            }
        });
    }

    private void shakeComponent(JComponent component) {
        if (shakeInProgress) {
            return;
        }

        shakeInProgress = true;
        final int originalX = component.getLocation().x;
        final int originalY = component.getLocation().y;

        final int shakeDistance = 3;
        final int shakeDuration = 30;
        final int shakeCount = 3;

        new Thread(() -> {
            try {
                for (int i = 0; i < shakeCount; i++) {
                    // Movimiento hacia la izquierda
                    SwingUtilities.invokeLater(() -> component.setLocation(originalX - shakeDistance, originalY));
                    Thread.sleep(shakeDuration);
                    // Movimiento hacia la derecha
                    SwingUtilities.invokeLater(() -> component.setLocation(originalX + shakeDistance, originalY));
                    Thread.sleep(shakeDuration);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                // Restaurar la posición original
                SwingUtilities.invokeLater(() -> component.setLocation(originalX, originalY));
                shakeInProgress = false;
            }
        }).start();
    }

    private void actualizarSalarioTotal() {
        try {
            String textoDescuento = OtrosDescuentos.getText();
            double porcentajeDescuento = 0.0;
            if (!textoDescuento.isEmpty()) {
                porcentajeDescuento = Double.parseDouble(textoDescuento);
                if (porcentajeDescuento < 0 || porcentajeDescuento > 100) {
                    throw new NumberFormatException("Porcentaje de descuento inválido");
                }
            }
            OtrosDescuentos.setBackground(Color.WHITE);
            primerError = true;
            CalcularSalario();
        } catch (NumberFormatException e) {
            SalarioTotal.setText("Error");
            if (primerError) {
                shakeComponent(OtrosDescuentos);
                OtrosDescuentos.setBackground(Color.PINK);
                primerError = false;
            }
        }
    }

    public String obtenerUltimoDiaDelMes() {
        LocalDate fechaActual = LocalDate.now();
        int ultimoDia = fechaActual.lengthOfMonth();
        LocalDate ultimoDiaDelMes = LocalDate.of(fechaActual.getYear(), fechaActual.getMonth(), ultimoDia);
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return ultimoDiaDelMes.format(formato);
    }

    private void establecerPeriodoDePago() {
        LocalDate fechaActual = LocalDate.now();
        LocalDate inicioPeriodo = fechaActual.withDayOfMonth(1);
        LocalDate finPeriodo = fechaActual.withDayOfMonth(fechaActual.lengthOfMonth());
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String periodoDePago = inicioPeriodo.format(formato) + " - " + finPeriodo.format(formato);
        PeriodoPago.setText(periodoDePago);
    }

    public class ResultadoCalculo {

        private double salarioTotal;
        private double renta;

        public ResultadoCalculo(double salarioTotal, double renta) {
            this.salarioTotal = salarioTotal;
            this.renta = renta;
        }

        public double getSalarioTotal() {
            return salarioTotal;
        }

        public double getRenta() {
            return renta;
        }
    }

    public ResultadoCalculo calcularTramo(double SalarioDevengado, double sala_sub) {
        double renta = 0;
        double sala_tot = 0;

        if (SalarioDevengado >= 0.01 && SalarioDevengado <= 472.00) {
            sala_tot = sala_sub;
        } else if (SalarioDevengado >= 472.01 && SalarioDevengado <= 895.24) {
            renta = (sala_sub - 472.00) * 0.10 + 17.67;
            sala_tot = sala_sub - renta;
        } else if (SalarioDevengado >= 895.25 && SalarioDevengado <= 2038.10) {
            renta = (sala_sub - 895.24) * 0.20 + 60.00;
            sala_tot = sala_sub - renta;
        } else if (SalarioDevengado >= 2038.11) {
            renta = (sala_sub - 2038.10) * 0.30 + 288.57;
            sala_tot = sala_sub - renta;
        }

        return new ResultadoCalculo(sala_tot, renta);
    }

    public double calcularValorPuntos(int puntosTotales, int puntosNacionales, int puntosInternacionales) {
        double valorPorPuntoNacional = 0.35;
        double valorPorPuntoInternacional = 0.10;

        double valorTotal = (puntosNacionales * valorPorPuntoNacional) + (puntosInternacionales * valorPorPuntoInternacional);

        return valorTotal;
    }

    public void CalcularSalario() {
        puntosN = instancia.getTotalPuntosN();
        puntosI = instancia.getTotalPuntosI();
        puntosTot = puntosI + puntosN;

        valorPuntos = calcularValorPuntos(puntosTot, puntosN, puntosI);
        double salarioBase = 365; // salario mínimo de base
        double SalarioDevengado = salarioBase;
        if (puntosTot <= 525) {
            SalarioDevengado = salarioBase;
        } else if (puntosTot > 525 && puntosTot <= 2500) {
            SalarioDevengado = salarioBase + valorPuntos;
        } else if (puntosTot > 2500) {
            SalarioDevengado = salarioBase + valorPuntos;
        }

        double isss = SalarioDevengado * 0.03;
        double afp = SalarioDevengado * 0.0725;
        double SalarioSubtotal = SalarioDevengado - isss - afp;
        Salariosubtotal.setText(String.format("%.2f", SalarioSubtotal));

        double porcentajeDescuento = 0.0;
        String textoDescuento = OtrosDescuentos.getText();
        if (!textoDescuento.isEmpty()) {
            try {
                porcentajeDescuento = Double.parseDouble(textoDescuento);
                OtrosDescuentos.setBackground(Color.WHITE);
                primerError = true;
            } catch (NumberFormatException e) {
                porcentajeDescuento = 0.0;
                OtrosDescuentos.setBackground(Color.PINK);
                primerError = false;
            }
        }
        double descuentoAdicional = SalarioSubtotal * (porcentajeDescuento / 100);
        SalarioSubtotal -= descuentoAdicional;

        ResultadoCalculo resultado = calcularTramo(SalarioDevengado, SalarioSubtotal);
        Descuento.setText(String.format("%.2f", descuentoAdicional));
        Salariodevengado.setText(String.format("%.2f", SalarioDevengado));
        ISSS.setText(String.format("%.2f", isss));
        AFP.setText(String.format("%.2f", afp));
        Renta.setText(String.format("%.2f", resultado.getRenta()));
        SalarioTotal.setText(String.format("%.2f", resultado.getSalarioTotal()));
        salarioTot = Double.parseDouble(String.format("%.2f", resultado.getSalarioTotal()));
        double renta = Double.parseDouble(String.format("%.2f", resultado.getRenta()));
        descuentosTot = isss + afp + renta + descuentoAdicional;
    }

    public void hacerAlgo() {
        int numero = (int) (Math.random() * 900000) + 100000;
        Codigo.setText(String.valueOf(numero));
        fechaMes.setText(obtenerUltimoDiaDelMes());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        fondo_generar_boleta16 = new javax.swing.JPanel();
        Renta = new javax.swing.JLabel();
        AFP = new javax.swing.JLabel();
        jLabel289 = new javax.swing.JLabel();
        Codigo = new javax.swing.JLabel();
        ISSS = new javax.swing.JLabel();
        exportar = new javax.swing.JButton();
        jSeparator150 = new javax.swing.JSeparator();
        jLabel290 = new javax.swing.JLabel();
        jLabel291 = new javax.swing.JLabel();
        jLabel292 = new javax.swing.JLabel();
        jSeparator151 = new javax.swing.JSeparator();
        jLabel293 = new javax.swing.JLabel();
        jLabel294 = new javax.swing.JLabel();
        jLabel295 = new javax.swing.JLabel();
        identificador = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        Apellido = new javax.swing.JLabel();
        jLabel296 = new javax.swing.JLabel();
        PeriodoPago = new javax.swing.JLabel();
        fechaMes = new javax.swing.JLabel();
        jSeparator152 = new javax.swing.JSeparator();
        jLabel297 = new javax.swing.JLabel();
        jLabel298 = new javax.swing.JLabel();
        Salariodevengado = new javax.swing.JLabel();
        jSeparator153 = new javax.swing.JSeparator();
        jLabel299 = new javax.swing.JLabel();
        jSeparator154 = new javax.swing.JSeparator();
        jLabel300 = new javax.swing.JLabel();
        jSeparator155 = new javax.swing.JSeparator();
        jLabel301 = new javax.swing.JLabel();
        jSeparator156 = new javax.swing.JSeparator();
        jLabel302 = new javax.swing.JLabel();
        jSeparator157 = new javax.swing.JSeparator();
        jLabel303 = new javax.swing.JLabel();
        jLabel304 = new javax.swing.JLabel();
        OtrosDescuentos = new javax.swing.JTextField();
        jLabel305 = new javax.swing.JLabel();
        descuento = new javax.swing.JComboBox<>();
        Descuento = new javax.swing.JLabel();
        jSeparator158 = new javax.swing.JSeparator();
        jLabel306 = new javax.swing.JLabel();
        SalarioTotal = new javax.swing.JLabel();
        Salariosubtotal = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        exportar17 = new javax.swing.JButton();

        Renta.setForeground(new java.awt.Color(0, 0, 0));
        Renta.setText("$$$.$$");

        AFP.setForeground(new java.awt.Color(0, 0, 0));
        AFP.setText("$$$.$$");

        jLabel289.setForeground(new java.awt.Color(0, 0, 0));
        jLabel289.setText("Código de boleta");

        Codigo.setForeground(new java.awt.Color(0, 0, 0));
        Codigo.setText("019201");

        ISSS.setForeground(new java.awt.Color(0, 0, 0));
        ISSS.setText("$$$.$$");

        exportar.setBackground(new java.awt.Color(204, 204, 204));
        exportar.setForeground(new java.awt.Color(0, 0, 0));
        exportar.setText("Exportar");
        exportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportarexportarActionPerformed(evt);
            }
        });

        jLabel290.setForeground(new java.awt.Color(0, 0, 0));
        jLabel290.setText("ID");

        jLabel291.setForeground(new java.awt.Color(0, 0, 0));
        jLabel291.setText("Nombre");

        jLabel292.setForeground(new java.awt.Color(0, 0, 0));
        jLabel292.setText("Apellido");

        jLabel293.setForeground(new java.awt.Color(0, 0, 0));
        jLabel293.setText("Empresa");

        jLabel294.setForeground(new java.awt.Color(0, 0, 0));
        jLabel294.setText("Periodo de pago");

        jLabel295.setForeground(new java.awt.Color(0, 0, 0));
        jLabel295.setText("Fecha emisión");

        identificador.setForeground(new java.awt.Color(0, 0, 0));
        identificador.setText("19382");

        Nombre.setForeground(new java.awt.Color(0, 0, 0));
        Nombre.setText("Susana");

        Apellido.setForeground(new java.awt.Color(0, 0, 0));
        Apellido.setText("Oria");

        jLabel296.setForeground(new java.awt.Color(0, 0, 0));
        jLabel296.setText("TRIPS & TOURS ");

        PeriodoPago.setForeground(new java.awt.Color(0, 0, 0));
        PeriodoPago.setText("23/04/2024 - 30/07/2024");

        fechaMes.setForeground(new java.awt.Color(0, 0, 0));
        fechaMes.setText("28/08/2024");

        jSeparator152.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel297.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel297.setForeground(new java.awt.Color(0, 0, 0));
        jLabel297.setText("DESCUENTOS");

        jLabel298.setForeground(new java.awt.Color(0, 0, 0));
        jLabel298.setText("Salario devengado");

        Salariodevengado.setForeground(new java.awt.Color(0, 0, 0));
        Salariodevengado.setText("$$$.$$");

        jLabel299.setForeground(new java.awt.Color(0, 0, 0));
        jLabel299.setText("ISSS");

        jLabel300.setForeground(new java.awt.Color(0, 0, 0));
        jLabel300.setText("AFP");

        jLabel301.setForeground(new java.awt.Color(0, 0, 0));
        jLabel301.setText("Renta");

        jLabel302.setForeground(new java.awt.Color(0, 0, 0));
        jLabel302.setText("Salario subtotal");

        jLabel303.setForeground(new java.awt.Color(0, 0, 0));
        jLabel303.setText("Otros descuentos");

        jLabel304.setForeground(new java.awt.Color(0, 0, 0));
        jLabel304.setText("Porcentaje en aplicar");

        OtrosDescuentos.setBackground(new java.awt.Color(204, 204, 204));
        OtrosDescuentos.setForeground(new java.awt.Color(0, 0, 0));

        jLabel305.setForeground(new java.awt.Color(0, 0, 0));
        jLabel305.setText("%");

        descuento.setBackground(new java.awt.Color(204, 204, 204));
        descuento.setForeground(new java.awt.Color(0, 0, 0));
        descuento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        Descuento.setForeground(new java.awt.Color(0, 0, 0));
        Descuento.setText("$$$.$$");

        jLabel306.setForeground(new java.awt.Color(0, 0, 0));
        jLabel306.setText("Salario total");

        SalarioTotal.setForeground(new java.awt.Color(0, 0, 0));
        SalarioTotal.setText("$$$.$$");

        Salariosubtotal.setForeground(new java.awt.Color(0, 0, 0));
        Salariosubtotal.setText("$$$.$$");

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Atrás");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        exportar17.setBackground(new java.awt.Color(204, 204, 204));
        exportar17.setForeground(new java.awt.Color(0, 0, 0));
        exportar17.setText("Guardar");
        exportar17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportar17exportarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout fondo_generar_boleta16Layout = new javax.swing.GroupLayout(fondo_generar_boleta16);
        fondo_generar_boleta16.setLayout(fondo_generar_boleta16Layout);
        fondo_generar_boleta16Layout.setHorizontalGroup(
            fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel294)
                    .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                        .addComponent(jLabel295)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(fechaMes))
                    .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                            .addComponent(jLabel293)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel296))
                        .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                            .addComponent(jLabel290)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(identificador))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_generar_boleta16Layout.createSequentialGroup()
                            .addComponent(jLabel289)
                            .addGap(18, 18, 18)
                            .addComponent(Codigo))
                        .addComponent(jSeparator150, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_generar_boleta16Layout.createSequentialGroup()
                            .addComponent(jLabel291)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Nombre))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_generar_boleta16Layout.createSequentialGroup()
                            .addComponent(jLabel292)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Apellido))
                        .addComponent(jSeparator151, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(PeriodoPago))
                .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jSeparator152, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                                .addComponent(jLabel301)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_generar_boleta16Layout.createSequentialGroup()
                                .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                                        .addComponent(jLabel303)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(Descuento))
                                    .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                                                .addComponent(jLabel300)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(AFP))
                                            .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                                                .addComponent(jLabel302)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(Salariosubtotal))
                                            .addComponent(jSeparator157, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator155, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator154, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator153)
                                            .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                                                .addComponent(jLabel298)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(Salariodevengado))
                                            .addComponent(jSeparator156, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, fondo_generar_boleta16Layout.createSequentialGroup()
                                                .addComponent(jLabel299)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(ISSS))
                                            .addComponent(Renta)
                                            .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                                                .addComponent(jLabel304)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabel305)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(OtrosDescuentos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(descuento, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jSeparator158, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(53, 53, 53))))
                    .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                        .addGap(142, 142, 142)
                        .addComponent(jLabel306)
                        .addGap(18, 18, 18)
                        .addComponent(SalarioTotal)
                        .addGap(330, 330, 330))))
            .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_generar_boleta16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_generar_boleta16Layout.createSequentialGroup()
                        .addComponent(jLabel297)
                        .addGap(192, 192, 192))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fondo_generar_boleta16Layout.createSequentialGroup()
                        .addComponent(exportar17)
                        .addGap(18, 18, 18)
                        .addComponent(exportar)
                        .addGap(16, 16, 16))))
        );
        fondo_generar_boleta16Layout.setVerticalGroup(
            fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jButton1)
                .addGap(9, 9, 9)
                .addComponent(jLabel297)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel289)
                            .addComponent(Codigo, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator150, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel290)
                            .addComponent(identificador))
                        .addGap(18, 18, 18)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel291)
                            .addComponent(Nombre))
                        .addGap(18, 18, 18)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel292)
                            .addComponent(Apellido))
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator151, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel293)
                            .addComponent(jLabel296))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel294)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PeriodoPago)
                        .addGap(26, 26, 26)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel295)
                            .addComponent(fechaMes)))
                    .addComponent(jSeparator152, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(fondo_generar_boleta16Layout.createSequentialGroup()
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel298)
                            .addComponent(Salariodevengado))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator153, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel299)
                            .addComponent(ISSS))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator154, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel300)
                            .addComponent(AFP))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator155, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Renta)
                            .addComponent(jLabel301, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator156, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel302)
                            .addComponent(Salariosubtotal))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator157, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Descuento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel303))
                        .addGap(18, 18, 18)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel304)
                            .addComponent(OtrosDescuentos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel305)
                            .addComponent(descuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addComponent(jSeparator158, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel306)
                            .addComponent(SalarioTotal))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(fondo_generar_boleta16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exportar)
                    .addComponent(exportar17))
                .addGap(15, 15, 15))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addComponent(fondo_generar_boleta16, javax.swing.GroupLayout.PREFERRED_SIZE, 819, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(60, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(fondo_generar_boleta16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void exportarexportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportarexportarActionPerformed
        Object[] options = {"Descargar en PDF", "Enviar por correo", "Cancelar"};
        int seleccion = JOptionPane.showOptionDialog(null, "¿Cómo lo desea exportar?", "Exportar", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[2]);

        if (seleccion == JOptionPane.YES_OPTION) {
            System.out.println("PDF");
            String textoDescuento = OtrosDescuentos.getText();
            double porcentajeDescuento = 0.0;

            if (!textoDescuento.isEmpty()) {
                try {
                    // Verificar si es un número entero
                    int descuentoEntero = Integer.parseInt(textoDescuento);

                    // Verificar si el número está dentro del rango permitido
                    if (descuentoEntero < 0 || descuentoEntero > 100) {
                        throw new NumberFormatException("El descuento debe estar entre 0 y 100.");
                    }

                    porcentajeDescuento = descuentoEntero;
                } catch (NumberFormatException e) {
                    porcentajeDescuento = 0.0;
                    JOptionPane.showMessageDialog(this, "El valor de otros descuentos no es válido. Debe ser un número entero entre 0 y 100.");
                    return;
                }
            }
            String nombreEmpleado = Nombre.getText();
            String idEmpleado = identificador.getText();
            String posicion = "Vendedor";
            String fechaPago = fechaMes.getText();
            double salarioBase = 365;
            double bonificaciones = calcularValorPuntos(puntosTot, puntosN, puntosI);
            double total = Double.parseDouble(SalarioTotal.getText());
            if (puntosTot <= 525) {
                PDF.convertHtmlToPdf(nombreEmpleado, idEmpleado, posicion, fechaPago, salarioBase, 0, descuentosTot, total);
            } else if (puntosTot > 525) {
                PDF.convertHtmlToPdf(nombreEmpleado, idEmpleado, posicion, fechaPago, salarioBase, bonificaciones, descuentosTot, total);
            }
            exportar.setEnabled(true);

        } else if (seleccion == JOptionPane.NO_OPTION) {
            System.out.println("Correo");

            //Enviar por correo
        } else if (seleccion == JOptionPane.CANCEL_OPTION || seleccion == JOptionPane.CLOSED_OPTION) {
            System.out.println("Cancelar");

            //Cerrar pestaña
        }
    }//GEN-LAST:event_exportarexportarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void exportar17exportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportar17exportarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_exportar17exportarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AFP;
    private javax.swing.JLabel Apellido;
    private javax.swing.JLabel Codigo;
    private javax.swing.JLabel Descuento;
    private javax.swing.JLabel ISSS;
    private javax.swing.JLabel Nombre;
    private javax.swing.JTextField OtrosDescuentos;
    private javax.swing.JLabel PeriodoPago;
    private javax.swing.JLabel Renta;
    private javax.swing.JLabel SalarioTotal;
    private javax.swing.JLabel Salariodevengado;
    private javax.swing.JLabel Salariosubtotal;
    private javax.swing.JComboBox<String> descuento;
    private javax.swing.JButton exportar;
    private javax.swing.JButton exportar17;
    private javax.swing.JLabel fechaMes;
    private javax.swing.JPanel fondo_generar_boleta16;
    private javax.swing.JLabel identificador;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel289;
    private javax.swing.JLabel jLabel290;
    private javax.swing.JLabel jLabel291;
    private javax.swing.JLabel jLabel292;
    private javax.swing.JLabel jLabel293;
    private javax.swing.JLabel jLabel294;
    private javax.swing.JLabel jLabel295;
    private javax.swing.JLabel jLabel296;
    private javax.swing.JLabel jLabel297;
    private javax.swing.JLabel jLabel298;
    private javax.swing.JLabel jLabel299;
    private javax.swing.JLabel jLabel300;
    private javax.swing.JLabel jLabel301;
    private javax.swing.JLabel jLabel302;
    private javax.swing.JLabel jLabel303;
    private javax.swing.JLabel jLabel304;
    private javax.swing.JLabel jLabel305;
    private javax.swing.JLabel jLabel306;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator150;
    private javax.swing.JSeparator jSeparator151;
    private javax.swing.JSeparator jSeparator152;
    private javax.swing.JSeparator jSeparator153;
    private javax.swing.JSeparator jSeparator154;
    private javax.swing.JSeparator jSeparator155;
    private javax.swing.JSeparator jSeparator156;
    private javax.swing.JSeparator jSeparator157;
    private javax.swing.JSeparator jSeparator158;
    // End of variables declaration//GEN-END:variables
}
