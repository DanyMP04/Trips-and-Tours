import javax.swing.*;
import java.io.*;
import java.nio.file.*;

public class MostrarPlanilla {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Planilla de Pago");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);

            JEditorPane editorPane = new JEditorPane();
            editorPane.setEditable(false);
            editorPane.setContentType("text/html");

            try {
                String htmlContent = new String(Files.readAllBytes(Paths.get("C:\\Users\\MINEDUCYT\\Documents\\ejemplo\\planilla.html")));
                editorPane.setText(htmlContent);
            } catch (IOException e) {
                e.printStackTrace();
            }

            JScrollPane scrollPane = new JScrollPane(editorPane);
            frame.add(scrollPane);
            frame.setVisible(true);
        });
    }
}
