import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnimatedHamburgerMenu extends JFrame {

    private JPanel menuPanel;
    private JButton menuButton;
    private boolean menuVisible = false;
    private Timer animationTimer;
    private int menuWidth = 200;

    public AnimatedHamburgerMenu() {
        initUI();
    }

    private void initUI() {
        setTitle("Menú Hamburguesa Animado");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Crear el panel del menú
        menuPanel = new JPanel();
        menuPanel.setLayout(new BorderLayout());
        menuPanel.setBackground(new Color(50, 50, 50));
        menuPanel.setPreferredSize(new Dimension(menuWidth, getHeight()));
        menuPanel.setBounds(-menuWidth, 0, menuWidth, getHeight()); // Inicialmente oculto

        // Crear el botón del menú
        menuButton = new JButton("☰");
        menuButton.setFont(new Font("Arial", Font.BOLD, 24));
        menuButton.setBackground(new Color(50, 50, 50));
        menuButton.setForeground(Color.WHITE);
        menuButton.setFocusPainted(false);
        menuButton.addActionListener(new MenuButtonActionListener());

        // Añadir componentes al JFrame
        add(menuButton, BorderLayout.WEST);
        add(menuPanel, BorderLayout.CENTER);

        // Configurar el temporizador para la animación
        animationTimer = new Timer(10, new AnimationTimerActionListener());
    }

    private void toggleMenu() {
        if (menuVisible) {
            // Ocultar el menú
            animationTimer.start();
        } else {
            // Mostrar el menú
            menuPanel.setBounds(-menuWidth, 0, menuWidth, getHeight());
            animationTimer.start();
        }
        menuVisible = !menuVisible;
    }

    private class MenuButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            toggleMenu();
        }
    }

    private class AnimationTimerActionListener implements ActionListener {
        private int currentPosition = -menuWidth;

        @Override
        public void actionPerformed(ActionEvent e) {
            if (menuVisible) {
                // Animar la aparición del menú
                if (currentPosition < 0) {
                    currentPosition += 10;
                    if (currentPosition > 0) {
                        currentPosition = 0;
                        animationTimer.stop();
                    }
                }
            } else {
                // Animar el deslizamiento del menú hacia fuera
                if (currentPosition > -menuWidth) {
                    currentPosition -= 10;
                    if (currentPosition < -menuWidth) {
                        currentPosition = -menuWidth;
                        animationTimer.stop();
                    }
                }
            }
            menuPanel.setBounds(currentPosition, 0, menuWidth, getHeight());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AnimatedHamburgerMenu ex = new AnimatedHamburgerMenu();
            ex.setVisible(true);
        });
    }
}
